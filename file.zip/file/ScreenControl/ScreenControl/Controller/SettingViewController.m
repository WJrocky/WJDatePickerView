//
//  SettingViewController.m
//  ScreenControl
//
//  Created by wangjian on 12/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"
#import "UIView+Toast.h"
#import "RuntimeData.h"
#import "VtronSession.h"
#import "MBProgressHUD.h"
#import "PopListController.h"
#import "VtronSocket+Protocol.h"
#import "SettingViewController.h"

@interface SettingViewController ()<UITextFieldDelegate, VtronSessionDelegate, PopListControllerDelegate>

@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) NSMutableArray *walls;
@property (weak, nonatomic) IBOutlet UIButton *systemCodeButton;
@property (weak, nonatomic) IBOutlet UIButton *vwasWallButton;
@property (weak, nonatomic) IBOutlet UITextField *hostTextField;
@property (weak, nonatomic) IBOutlet UILabel *lineLabel;
@property (weak, nonatomic) IBOutlet UILabel *rowLabel;

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);
    
    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;
    
    self.walls = [NSMutableArray array];
    
    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;
    
    [self.session.socket sendObtainVWASWallNameMessage];
    
    //    [self.session.socket sendCloseAllWatchWallMachineMessage];
    //    [self.session.socket sendOpenAllWatchWallMachineMessage];

    NSString *host = [RuntimeData sharedInstance].host;

    self.hostTextField.text = host.length == 0 ? @"127.0.0.1":host;
    
    NSData *systemCodeLengthData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
    NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
    
    [self.systemCodeButton setTitle:[NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength] forState:UIControlStateNormal];
    
    NSData *lineData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(4, 4)];
    NSUInteger line = [lineData valueOfBigUint32_t];
    
    self.lineLabel.text = [NSString stringWithFormat:@"行数：%ld", (unsigned long)line];
    
    NSData *rowData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(4, 4)];
    NSUInteger row = [rowData valueOfBigUint32_t];
    self.rowLabel.text = [NSString stringWithFormat:@"列数：%ld", (unsigned long)row];
    
    self.vwasWallButton.titleLabel.text = @"";
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)popListControllerAction:(UIButton *)sender {
    if (self.walls.count) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle:nil];
        PopListController *popListController = [storyboard instantiateViewControllerWithIdentifier:@"PopListController"];
        popListController.delegate = self;
        if (1024 == sender.tag) {
            NSMutableArray *systemCodeArray = [NSMutableArray array];
            for (NSData *systemCodeData in [RuntimeData sharedInstance].systemDataList) {
                NSData *systemCodeLengthData = [systemCodeData subdataWithRange:NSMakeRange(0, 4)];
                NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
                NSString *systemCodeString = [NSString stringWithFormat:@"%lu",(unsigned long)systemCodeLength];
                [systemCodeArray addObject:systemCodeString];
            }
            [popListController loadData:systemCodeArray type:@"系统号"];
        } else if (1025 == sender.tag) {
            [popListController loadData:self.walls type:@"Vwas墙"];
        }

        UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
        popListController.view.frame = [UIScreen mainScreen].bounds;

        [keyWindow addSubview:popListController.view];
        [self addChildViewController:popListController];
    }
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidSendData:(NSData *)data
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"获取显示墙名称";
}

- (void)sessionDidReceivedData:(NSData *)data
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];

    if (data.length >= 12) {
        if ([[data subdataWithRange:NSMakeRange(10, 2)] isEqualToData:[NSData dataFromHexString:@"0000"]]) {
            NSData *messageBody = [data subdataWithRange:NSMakeRange(10, data.length - 10)];

            //回应号
            NSData *respondCode = [messageBody subdataWithRange:NSMakeRange(14, 1)];
            if ([respondCode isEqualToData:[NSData dataFromHexString:@"15"]]) {
                //结果(可选)
                NSData *result = [messageBody subdataWithRange:NSMakeRange(16, messageBody.length - 16 - 4)];

                NSData *screenCountData = [result subdataWithRange:NSMakeRange(0, 4)];
                NSUInteger screenCount = [screenCountData valueOfUint32_t];

                NSData *screenListData = [result subdataWithRange:NSMakeRange(4, result.length - 4)];
                NSUInteger count = 0;
                for (int i = 0; i < screenCount; i++) {
                    NSData *screenNameLengthData = [screenListData subdataWithRange:NSMakeRange(count, 4)];
                    count += 4;
                    NSUInteger screenNameLength = [screenNameLengthData valueOfUint32_t];
                    NSData *screenNameData = [screenListData subdataWithRange:NSMakeRange(count, screenNameLength)];
                    count += screenNameLength;
                    NSString *screenName = [[NSString alloc] initWithData:screenNameData encoding:NSUTF8StringEncoding];
                    NSLog(@"screenName = %@", screenName);
                    [self.walls addObject:screenNameData];
                }
                NSData *wallData = [self.walls firstObject];
                NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
                NSString *name = [[NSString alloc] initWithData:wallData encoding:enc];
                [self.vwasWallButton setTitle:name forState:UIControlStateNormal];
            } else {
                [self.view makeToast:@"获取显示墙名称失败！"];
            }
        } 
    }
}

#pragma mark - delegate
- (void)PopListController:(PopListController *)controller didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.session.delegate = self;
    if ([controller.type isEqualToString:@"系统号"]) {
        //选择系统号
        NSData *systemCodeData = [[RuntimeData sharedInstance].systemDataList objectAtIndex:indexPath.row];
        [RuntimeData sharedInstance].selectedSystemData = systemCodeData;
        
        NSData *systemCodeLengthData = [systemCodeData subdataWithRange:NSMakeRange(0, 4)];
        NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];

        [self.systemCodeButton setTitle:[NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength] forState:UIControlStateNormal];

        NSData *lineData = [systemCodeData subdataWithRange:NSMakeRange(4, 4)];
        NSUInteger line = [lineData valueOfBigUint32_t];

        self.lineLabel.text = [NSString stringWithFormat:@"行数：%ld", (unsigned long)line];

        NSData *rowData = [systemCodeData subdataWithRange:NSMakeRange(8, 4)];
        NSUInteger row = [rowData valueOfBigUint32_t];
        self.rowLabel.text = [NSString stringWithFormat:@"列数：%ld", (unsigned long)row];

    } else if ([controller.type isEqualToString:@"Vwas墙"]) {
        //VWAS墙
        NSData *wallData = [self.walls objectAtIndex:indexPath.row];
        [self.session.socket sendChooseShowWallMessage:wallData];
        NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        NSString *name = [[NSString alloc] initWithData:wallData encoding:enc];
        [self.vwasWallButton setTitle:name forState:UIControlStateNormal];
    }
}

@end
