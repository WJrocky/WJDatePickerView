//
//  MoreViewController.m
//  ScreenControl
//
//  Created by wangjian on 11/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "UIView+Toast.h"
#import "HomeItemCell.h"
#import "MagicalRecord.h"
#import "Icon+CoreDataClass.h"
#import "MoreViewController.h"
#import "Icon+CoreDataClass.h"
#import "MoreTitleReusableView.h"

@interface MoreViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *editBarButtonItem;
@property (nonatomic, strong) NSMutableArray *sectionArray;
@property (nonatomic, strong) NSMutableArray *frequentlyFunctions;
@property (nonatomic, copy) FunctionsChangeSuccess functionChangeSuccess;
@property (nonatomic, assign) BOOL isEditing;

@end

@implementation MoreViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);

    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;

    NSDictionary *attributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:15.0],NSForegroundColorAttributeName:[UIColor whiteColor]};

    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:attributes forState:UIControlStateNormal];
    
    self.sectionArray = [NSMutableArray array];
    NSArray *frequentlyUsedFunctions = [Icon MR_findByAttribute:@"isFrequentlyUsed" withValue:[NSNumber numberWithBool:YES]];
    frequentlyUsedFunctions = [frequentlyUsedFunctions sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"serialnumber" ascending:YES]]];

    [self.sectionArray addObject:[NSMutableArray arrayWithArray:frequentlyUsedFunctions]];
    [self.sectionArray addObject:[NSMutableArray arrayWithArray:[Icon MR_findByAttribute:@"functionType" withValue:@"设置桌面"]]];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
    if (isReleaseVersion) {
        [self.sectionArray addObject:[NSMutableArray arrayWithArray:[Icon MR_findByAttribute:@"functionType" withValue:@"光学模式"]]];
        [self.sectionArray addObject:[NSMutableArray arrayWithArray:[Icon MR_findByAttribute:@"functionType" withValue:@"VWAS模式"]]];
    }
}

- (void)backAction
{
    if (self.isEditing) {
        [self.view makeToast:@"请先完成编辑！"];
        return;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return self.sectionArray.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSArray *icons = [self.sectionArray objectAtIndex:section];
    return [icons count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
    NSArray *icons = [self.sectionArray objectAtIndex:indexPath.section];
    Icon *subModel = [icons objectAtIndex:indexPath.item];
    [cell loadData:subModel];
    if (self.isEditing) {
        if (indexPath.section > 0) {
            NSArray *frequentlyUsedFunctions = [self.sectionArray firstObject];
            if ([frequentlyUsedFunctions containsObject:subModel]) {
                cell.stateImageView.image = nil;
            } else {
                cell.stateImageView.image = [UIImage imageNamed:subModel.stateImageName];
            }
        } else {
            cell.stateImageView.image = [UIImage imageNamed:subModel.stateImageName];
        }
    } else {
        cell.stateImageView.image = nil;
    }
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    MoreTitleReusableView *titleView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"MoreTitleReusableView" forIndexPath:indexPath];
    Icon *model = [[self.sectionArray objectAtIndex:indexPath.section] firstObject];
    [titleView loadData:model];
    return titleView;
}

#pragma mark - UICollectionViewDelegateFlowLayout

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isEditing) {
        NSMutableArray *icons = [self.sectionArray firstObject];
        NSArray *tapedIcons = [self.sectionArray objectAtIndex:indexPath.section];
        Icon *icon = [tapedIcons objectAtIndex:indexPath.row];
        if (indexPath.section > 0) {
            
            NSIndexPath *lastIndexPath = [NSIndexPath indexPathForItem:icons.count inSection:0];
            if (![icons containsObject:icon]) {
                [icons addObject:icon];
                icon.isFrequentlyUsed = YES;
                icon.serialnumber = lastIndexPath.row;
                icon.stateImageName = @"function_remove";
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                if (self.functionChangeSuccess) {
                    self.functionChangeSuccess();
                }
                [collectionView reloadData];
            }
        } else {
            if (icon.canRemove) {
                icon.isFrequentlyUsed = NO;
                icon.serialnumber = 0;
                icon.stateImageName = @"function_add";
                NSArray *files = [Icon MR_findByAttribute:@"fileName" withValue:icon.fileName];
                if (1 == files.count) {
                    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                    [userDefaults removeObjectForKey:@"filename"];
                }
                icon.fileName = nil;
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                [icons removeObjectAtIndex:indexPath.item];
                if (self.functionChangeSuccess) {
                    self.functionChangeSuccess();
                }
                [collectionView reloadData];
            }
        }
    }
}

- (IBAction)editBarButtonAction:(UIBarButtonItem *)sender {
    self.isEditing = !self.isEditing;
    sender.title = self.isEditing ? @"完成":@"编辑";
    [self.functionCollectionView reloadData];
}

@end
