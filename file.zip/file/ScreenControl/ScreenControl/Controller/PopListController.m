//
//  PopListController.m
//  ScreenControl
//
//  Created by 王健 on 2017/9/27.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "ChangeIPCell.h"
#import "VtronSession.h"
#import "PopListController.h"
#import "VtronSocket+Protocol.h"

@interface PopListController ()<UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate, VtronSessionDelegate, ChangeIPCellDelegate>

@property (weak, nonatomic) IBOutlet UIView *containerView;
@property (weak, nonatomic) IBOutlet UITableView *listTableView;
@property (weak, nonatomic) IBOutlet UIView *backgroundView;
@property (nonatomic, strong) NSMutableArray *array;
@property (nonatomic, strong) VtronSession *session;

@end

@implementation PopListController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;
}

- (void)loadData:(NSMutableArray *)data type:(NSString *)type
{
    self.array = data;
    self.type = type;
    [self.listTableView reloadData];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.array.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.type isEqualToString:@"PPT翻页"]) {
        return tableView.bounds.size.height;
    }
    return 44;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    if ([self.type isEqualToString:@"系统号"]) {
        NSString *systemCode = [self.array objectAtIndex:indexPath.row];
        cell.textLabel.text = systemCode;
        return cell;
    } else if ([self.type isEqualToString:@"Vwas墙"]) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"changeIP"];
        NSData *wallData = [self.array objectAtIndex:indexPath.row];
        NSString *wallName = [[NSString alloc] initWithData:wallData encoding:NSUTF8StringEncoding];
        cell.textLabel.text = wallName;
        return cell;
    } else {
        ChangeIPCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ChangeIPCell"];
        cell.delegate = self;
        return cell;
    }
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (![self.type isEqualToString:@"PPT翻页"]) {
        if ([self.delegate respondsToSelector:@selector(PopListController:didSelectRowAtIndexPath:)]) {
            [self.delegate PopListController:self didSelectRowAtIndexPath:indexPath];
            [self dismissSelf];
        }
    }
}

- (void)ChangeIPCellDidTapAction
{
    if ([self.delegate respondsToSelector:@selector(PopListController:didSelectRowAtIndexPath:)]) {
        [self.delegate PopListController:self didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
        [self dismissSelf];
    }
}

#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if (![touch.view isEqual:self.backgroundView]) {
        return NO;
    }
    return YES;
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidReceivedData:(NSData *)data
{

}

- (IBAction)backgroundViewTapGesture:(UITapGestureRecognizer *)sender {
    [self dismissSelf];
}

- (void)dismissSelf
{
    [self.view removeFromSuperview];
    [self removeFromParentViewController];
}

@end
