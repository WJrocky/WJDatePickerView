//
//  DetailViewController.m
//  ScreenControl
//
//  Created by wangjian on 13/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"
#import "UIView+Toast.h"
#import "RuntimeData.h"
#import "VtronSession.h"
#import "MBProgressHUD.h"
#import "HomeItemCell.h"
#import "MagicalRecord.h"
#import "DetailViewController.h"
#import "VtronSocket+Protocol.h"

@interface DetailViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, VtronSessionDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (nonatomic, strong) NSArray *icons;
@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) NSUserDefaults *userDefaults;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);

    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;

    self.userDefaults = [NSUserDefaults standardUserDefaults];
    
    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;
    
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSString *name = [[NSString alloc] initWithData:self.model.iconMenuName encoding:enc];
    
    self.title = name;
    
    self.icons = [[Icon MR_findByAttribute:@"functionType" withValue:name] mutableCopy];
    self.icons = [self.icons sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"serialnumber" ascending:YES]]];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
    
    if (isReleaseVersion) {
        if ([name isEqualToString:@"VWAS模式"]) {
            self.icons = [RuntimeData sharedInstance].VWASList;
        } else if ([name isEqualToString:@"光学模式"]) {
            self.icons = [RuntimeData sharedInstance].lightDataList;
        }
    }
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.icons.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
    [cell loadData:[self.icons objectAtIndex:indexPath.item]];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSString *name = [[NSString alloc] initWithData:self.model.iconMenuName encoding:enc];
    
    if ([name isEqualToString:@"VWAS模式"]) {
        
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
        
        if (isReleaseVersion) {
            Icon *model = [self.icons objectAtIndex:indexPath.row];
            [self.session.socket sendStartVWASModelMessage:model.iconMenuName];
        }
    } else if ([name isEqualToString:@"光学模式"]) {
        [self.session.socket sendStartlightModelMessage:indexPath.row];
    } else if ([name isEqualToString:@"设置桌面"]) {
        [self.session.socket sendSettingDesktopMessage:indexPath.row];
    }
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidReceivedData:(NSData *)data
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    if (data.length > 6) {
        NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
        if ([orderData isEqualToData:[NSData dataFromHexString:@"0310"]]) {
            NSLog(@"VWAS调用成功!");
        } else if ([orderData isEqualToData:[NSData dataFromHexString:@"0b10"]]) {
            NSLog(@"操作成功!");
        } else {
            [self.view makeToast:@"操作失败！"];
        }
    }
}

- (void)sessionDidSendData:(NSData *)data
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"loading";
}

@end
