//
//  ChangeIPCell.h
//  ScreenControl
//
//  Created by 王健 on 2017/10/10.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ChangeIPCellDelegate <NSObject>

- (void)ChangeIPCellDidTapAction;

@end

@interface ChangeIPCell : UITableViewCell

@property (nonatomic, assign) id<ChangeIPCellDelegate> delegate;

@end
