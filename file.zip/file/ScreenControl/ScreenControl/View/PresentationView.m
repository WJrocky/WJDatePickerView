//
//  PresentationView.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "PresentationView.h"

@interface PresentationView ()<UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UIView *containerView;

@end

@implementation PresentationView

+ (id)popAlertView
{
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    if ([[[keyWindow subviews] lastObject] isKindOfClass:[self class]]) {
        return nil;
    }

    PresentationView *presentationView = [[[NSBundle mainBundle] loadNibNamed:@"PresentationView"
                                                                        owner:nil
                                                                      options:nil] firstObject];

    presentationView.frame = [UIScreen mainScreen].bounds;

    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:presentationView action:@selector(dismissSelf)];
    tapGesture.delegate = presentationView;
    [presentationView addGestureRecognizer:tapGesture];

    [keyWindow addSubview:presentationView];

    return presentationView;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isEqual:self.containerView]) {
        return NO;
    }
    return YES;
}

- (void)dismissSelf
{
    [self removeFromSuperview];
}

- (IBAction)cancelButtonAction:(UIButton *)sender {
    [self removeFromSuperview];
}

- (IBAction)confirmButtonAction:(UIButton *)sender {
    if ([self.delegate respondsToSelector:@selector(presentationView:didTapConfirmButton:)]) {
        [self.delegate presentationView:self didTapConfirmButton:sender];
    }
    [self removeFromSuperview];
}

@end
