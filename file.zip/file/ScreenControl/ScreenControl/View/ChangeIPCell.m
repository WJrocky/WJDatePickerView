//
//  ChangeIPCell.m
//  ScreenControl
//
//  Created by 王健 on 2017/10/10.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "RuntimeData.h"
#import "ChangeIPCell.h"

@interface ChangeIPCell ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *IPTextField;

@end

@implementation ChangeIPCell

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)changeIPButtonAction:(UIButton *)sender {
    if ([self.delegate respondsToSelector:@selector(ChangeIPCellDidTapAction)]) {
        [RuntimeData sharedInstance].host = self.IPTextField.text;
        [self.delegate ChangeIPCellDidTapAction];
    }
}

@end
