//
//  MoreTitleReusableView.m
//  ScreenControl
//
//  Created by wangjian on 11/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "Icon+CoreDataClass.h"
#import "MoreTitleReusableView.h"

@interface MoreTitleReusableView ()

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

@implementation MoreTitleReusableView

- (void)loadData:(Icon *)data
{
    self.titleLabel.text = data.functionType;
}

@end
