//
//  PresentationView.h
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PresentationView;
@protocol PresentationViewDelegate <NSObject>

- (void)presentationView:(PresentationView *)view didTapConfirmButton:(UIButton *)sender;

@end

@interface PresentationView : UIView

@property (nonatomic, assign) id<PresentationViewDelegate> delegate;
+ (id)popAlertView;

@end
