//
//  VtronSocket.m
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"
#import <sys/socket.h>
#import "VtronSocket.h"
#import <arpa/inet.h>

@interface VtronSocket ()<NSStreamDelegate>

@property (nonatomic, strong) NSInputStream *inputStream;
@property (nonatomic, strong) NSOutputStream *outputStream;

@end

@implementation VtronSocket

- (void)tcpConnectToHost:(NSString *)host port:(UInt32)port
{
    if (0 == host.length) {
        return;
    } else if (0 == port) {
        return;
    }

    //输入流,用来读取数据
    CFReadStreamRef readStream;
    //输出流,用来发送数据
    CFWriteStreamRef writeStream;

    //建立socket连接
    CFStreamCreatePairWithSocketToHost(NULL, (__bridge CFStringRef)(host), port, &readStream, &writeStream);

    //注意__bridge_transfer,转移对象的内存管理权
    self.inputStream = (__bridge_transfer NSInputStream *)(readStream);
    self.outputStream = (__bridge_transfer NSOutputStream *)(writeStream);

    self.inputStream.delegate = self;
    self.outputStream.delegate = self;

    [self.outputStream scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    [self.inputStream scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];

    [self.outputStream open];
    [self.inputStream open];
}

- (void)udpConnection:(NSString *)hostText port:(int)port
{
    /**
     参数
     domain:    协议域，AF_INET（IPV4的网络开发）
     type:      Socket 类型，SOCK_STREAM(TCP)/SOCK_DGRAM(UDP，报文)
     protocol:  IPPROTO_TCP，协议，如果输入0，可以根据第二个参数，自动选择协议

     返回值
     socket，如果 > 0 就表示成功
     */
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        NSLog(@"socket create failure");
    }

    //connection 连接到“服务器”
    /**
     参数
     1> 客户端socket
     2> 指向数据结构sockaddr的指针，其中包括目的端口和IP地址
     服务器的"结构体"地址，C语言没有对象
     3> 结构体数据长度
     返回值
     0 成功/其他 错误代号，非0即真
     */
    struct sockaddr_in serverAddress;
    // IPV4 - 协议
    serverAddress.sin_family = AF_INET;
    memset(&serverAddress, 0, sizeof(struct sockaddr_in));
    // inet_addr函数可以把ip地址转换成一个整数
    serverAddress.sin_addr.s_addr = inet_addr(hostText.UTF8String);
    // 端口小端存储
    serverAddress.sin_port = htons(port);

    int result = connect(sock, (const struct sockaddr *)&serverAddress, sizeof(serverAddress));

    if (0 == result) {
        NSLog(@"connect success!");
    }
}

#pragma mark NSStreamDelegate
- (void)stream:(NSStream *)aStream handleEvent:(NSStreamEvent)eventCode
{
    if ([self.delegate respondsToSelector:@selector(VtronSocket:didChangeStatus:)]) {
        [self.delegate VtronSocket:self didChangeStatus:eventCode];
    }
}

- (NSData *)readData
{
    //缓存区设置为4K
    uint8_t buff[4096];

    NSUInteger len = [self.inputStream read:buff maxLength:sizeof(buff)];

    NSData *data = nil;

    if (len < sizeof(buff) && (_outputStream.hasSpaceAvailable)) {
        data = [NSData dataWithBytes:buff length:len];
    }
    NSLog(@"receive data = %@", data);

    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];

    NSString *filePath = [path stringByAppendingString:@"/data.txt"];

    NSFileHandle *handle = [NSFileHandle fileHandleForUpdatingAtPath:filePath];

    [handle seekToEndOfFile];

    //保存接口名称
    NSString *nameString = [NSString stringWithFormat:@"\n%@\n", [self responseDataProtocolName:data]];
    NSData *nameData = [nameString dataUsingEncoding:NSUTF8StringEncoding];

    NSMutableData *saveData = [NSMutableData data];
    [saveData appendData:nameData];

    //保存接口数据
    NSMutableString *tempString = [NSMutableString string];
    for (int i = 0; i < data.length; i += 2) {
        NSData *tempData = nil;
        if (data.length - i > 1) {
            tempData = [data subdataWithRange:NSMakeRange(i, 2)];
            [tempString appendString:[tempData convertDataToHexStr]];
            [tempString appendString:@" "];
        } else {
            tempData = [data subdataWithRange:NSMakeRange(i, data.length - i)];
            [tempString appendString:[tempData convertDataToHexStr]];
        }
    }

    NSData *converterData = [tempString dataUsingEncoding:NSUTF8StringEncoding];
    [saveData appendData:converterData];

    [handle writeData:saveData];

    return data;
}

- (NSInteger)writeData:(NSData *)data
{
    if (0 == data.length) {
        return 0;
    }

    NSInteger ret = 0;

    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
    if (isReleaseVersion) {
        ret = [_outputStream write:data.bytes maxLength:data.length];
    } else {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self stream:_outputStream handleEvent:NSStreamEventHasBytesAvailable];
        });
    }
    if ([self.delegate respondsToSelector:@selector(VtronSocket:didSendData:)]) {
        [self.delegate VtronSocket:self didSendData:data];
    }

    NSLog(@"write data = %@", data);

    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];

    NSString *filePath = [path stringByAppendingString:@"/data.txt"];

    NSFileManager *manger = [NSFileManager defaultManager];

    if (![manger fileExistsAtPath:filePath]) {
        NSString *str = @"开始";
        [str writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }

    NSFileHandle *handle = [NSFileHandle fileHandleForUpdatingAtPath:filePath];

    [handle seekToEndOfFile];

    //保存接口名称
    NSString *nameString = [NSString stringWithFormat:@"\n%@\n", [self requestDataProtocolName:data]];
    NSData *nameData = [nameString dataUsingEncoding:NSUTF8StringEncoding];

    NSMutableData *saveData = [NSMutableData data];
    [saveData appendData:nameData];

    //保存接口数据
    NSMutableString *tempString = [NSMutableString string];
    for (int i = 0; i < data.length; i += 2) {
        NSData *tempData = nil;
        if (data.length - i > 1) {
            tempData = [data subdataWithRange:NSMakeRange(i, 2)];
            [tempString appendString:[tempData convertDataToHexStr]];
            [tempString appendString:@" "];
        } else {
            tempData = [data subdataWithRange:NSMakeRange(i, data.length - i)];
            [tempString appendString:[tempData convertDataToHexStr]];
        }
    }

    NSData *converterData = [tempString dataUsingEncoding:NSUTF8StringEncoding];
    [saveData appendData:converterData];

    [handle writeData:saveData];
//    if (0 == ret) {
//        [self.delegate VtronSocket:self didChangeStatus:NSStreamEventHasBytesAvailable];
//    }
    return ret;
}

- (NSString *)responseDataProtocolName:(NSData *)data
{
    NSString *name = nil;
    if (data.length >= 10) {
        NSData *orderID = [data subdataWithRange:NSMakeRange(4, 2)];
        if ([orderID isEqualToData:[NSData dataFromHexString:@"0110"]]) {
            name = @"手机授权";
        } else if ([orderID isEqualToData:[NSData dataFromHexString:@"0310"]]) {
            if (data.length >= 19) {
                NSData *ID = [data subdataWithRange:NSMakeRange(24, 1)];
                if ([ID isEqualToData:[NSData dataFromHexString:@"01"]]) {
                    name = @"选择显示墙";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"03"]]) {
                    name = @"打开显示墙所有机芯";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"05"]]) {
                    name = @"关闭显示墙所有机芯";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"06"]]) {
                    name = @"获取VWAS模式列表";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"3e"]]) {
                    name = @"调用VWAS模式";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"15"]]) {
                    name = @"枚举显示墙名称";
                }
            }
        }  else if ([orderID isEqualToData:[NSData dataFromHexString:@"0510"]]) {
            name = @"查询系统配置信息";
        } else if ([orderID isEqualToData:[NSData dataFromHexString:@"0710"]]) {
            if (data.length >= 18) {
                NSData *ID = [data subdataWithRange:NSMakeRange(10, 2)];
                if ([ID isEqualToData:[NSData dataFromHexString:@"8971"]]) {
                    name = @"PPT翻页";
                } else {
                    name = @"获取光学模式名称";
                }
            }
        } else if ([orderID isEqualToData:[NSData dataFromHexString:@"0910"]]) {
            name = @"开关机";
        } else if ([orderID isEqualToData:[NSData dataFromHexString:@"0b10"]]) {
            if (data.length >= 16) {
                NSData *orderID = [data subdataWithRange:NSMakeRange(14, 2)];
                if ([orderID isEqualToData:[NSData dataFromHexString:@"1b60"]]) {
                    name = @"设置桌面";
                } else if ([orderID isEqualToData:[NSData dataFromHexString:@"2b60"]]) {
                    name = @"调用光学模式";
                }
            }
        }
    }
    return name;
}

- (NSString *)requestDataProtocolName:(NSData *)data
{
    NSString *name = nil;
    if (data.length >= 10) {
        NSData *orderID = [data subdataWithRange:NSMakeRange(4, 2)];
        if ([orderID isEqualToData:[NSData dataFromHexString:@"0010"]]) {
            name = @"手机授权";
        } else if ([orderID isEqualToData:[NSData dataFromHexString:@"0210"]]) {
            if (data.length >= 19) {
                NSData *ID = [data subdataWithRange:NSMakeRange(18, 1)];
                if ([ID isEqualToData:[NSData dataFromHexString:@"01"]]) {
                    name = @"选择显示墙";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"03"]]) {
                    name = @"打开显示墙所有机芯";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"05"]]) {
                    name = @"关闭显示墙所有机芯";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"06"]]) {
                    name = @"获取VWAS模式列表";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"3e"]]) {
                    name = @"调用VWAS模式";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"15"]]) {
                    name = @"枚举显示墙名称";
                }
            }
        }  else if ([orderID isEqualToData:[NSData dataFromHexString:@"0410"]]) {
            name = @"查询系统配置信息";
        } else if ([orderID isEqualToData:[NSData dataFromHexString:@"0610"]]) {
            if (data.length >= 18) {
                NSData *ID = [data subdataWithRange:NSMakeRange(16, 2)];
                if ([ID isEqualToData:[NSData dataFromHexString:@"c866"]]) {
                    name = @"获取光学模式名称";
                } else if ([ID isEqualToData:[NSData dataFromHexString:@"8871"]]) {
                    NSData *systemCode = [data subdataWithRange:NSMakeRange(10, 4)];
                    if (19 == [systemCode valueOfBigUint32_t]) {
                        name = @"PPT上一页";
                    } else {
                        name = @"PPT下一页";
                    }
                }
            }
        } else if ([orderID isEqualToData:[NSData dataFromHexString:@"0810"]]) {
            if (data.length >= 14) {
                NSData *type = [data subdataWithRange:NSMakeRange(10, 4)];
                if (1 == [type valueOfBigUint32_t]) {
                    name = @"开机";
                } else {
                    name = @"关机";
                }
            }
        } else if ([orderID isEqualToData:[NSData dataFromHexString:@"0a10"]]) {
            if (data.length >= 16) {
                NSData *orderID = [data subdataWithRange:NSMakeRange(14, 2)];
                if ([orderID isEqualToData:[NSData dataFromHexString:@"1a60"]]) {
                    name = @"设置桌面";
                } else if ([orderID isEqualToData:[NSData dataFromHexString:@"2a60"]]) {
                    name = @"调用光学模式";
                }
            }
        }
    }
    return name;
}

- (void)close
{
    [_inputStream close];
    [_outputStream close];
    [_inputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
    [_outputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
    _inputStream.delegate = nil;
    _outputStream.delegate = nil;
    _inputStream = nil;
    _outputStream = nil;
}

@end
