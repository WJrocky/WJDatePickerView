//
//  NSData+Vtron.m
//  ScreenControl
//
//  Created by wangjian on 29/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"

@implementation NSData (Vtron)

//大端字节
- (int)valueOfBigUint32_t
{
    uint8_t *value = (uint8_t *)self.bytes;
    return ((value[0] & 0xff)| ((value[1] & 0xff) << 8) | ((value[2] & 0xff) << 16) | ((value[3] & 0xff) << 24));
}

//小端字节
- (int)valueOfUint32_t
{
    uint8_t *value = (uint8_t *)self.bytes;
    return ((value[0] & 0xff) << 24) | ((value[1] & 0xff) << 16) | ((value[2] & 0xff) << 8) | (value[3] & 0xff);
}

//将字符串转化为data
+ (NSData *)dataFromHexString:(NSString *)str
{
    const char *chars = [str UTF8String];
    NSUInteger i = 0, len = str.length;

    NSMutableData *data = [NSMutableData dataWithCapacity:len / 2];
    char byteChars[3] = {'\0','\0','\0'};
    unsigned long wholeByte;

    while (i < len) {
        byteChars[0] = chars[i++];
        byteChars[1] = chars[i++];
        wholeByte = strtoul(byteChars, NULL, 16);
        [data appendBytes:&wholeByte length:1];
    }

    return data;
}

- (NSString *)convertDataToHexStr
{
    if (!self || [self length] == 0) {
        return @"";
    }
    NSMutableString *string = [[NSMutableString alloc] initWithCapacity:[self length]];

    [self enumerateByteRangesUsingBlock:^(const void *bytes, NSRange byteRange, BOOL *stop) {
        unsigned char *dataBytes = (unsigned char*)bytes;
        for (NSInteger i = 0; i < byteRange.length; i++) {
            NSString *hexStr = [NSString stringWithFormat:@"%x", (dataBytes[i]) & 0xff];
            if ([hexStr length] == 2) {
                [string appendString:hexStr];
            } else {
                [string appendFormat:@"0%@", hexStr];
            }
        }
    }];

    return string;
}

@end
