//
//  RuntimeData.h
//  ScreenControl
//
//  Created by 王健 on 2017/9/23.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RuntimeData : NSObject

@property (nonatomic, strong) NSString *host;
@property (nonatomic, strong) NSArray *systemDataList;
@property (nonatomic, strong) NSArray *VWASList;
@property (nonatomic, strong) NSArray *lightDataList;
@property (nonatomic, strong) NSData *selectedSystemData;
@property (nonatomic, strong) NSMutableArray *allFunctions;
@property (nonatomic, strong) NSMutableArray *frequentlyFunctions;

+ (instancetype)sharedInstance;
- (void)initAllFunctionArray;
- (void)initFrequentlyFunctions;
- (NSString *)getIPAddress:(BOOL)preferIPv4;

@end
