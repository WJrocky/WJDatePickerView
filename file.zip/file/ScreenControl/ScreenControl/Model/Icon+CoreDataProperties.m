//
//  Icon+CoreDataProperties.m
//  ScreenControl
//
//  Created by 王健 on 2017/9/28.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "Icon+CoreDataProperties.h"

@implementation Icon (CoreDataProperties)

+ (NSFetchRequest<Icon *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Icon"];
}

@dynamic canRemove;
@dynamic fileName;
@dynamic functionType;
@dynamic iconImageName;
@dynamic iconMenuName;
@dynamic isFrequentlyUsed;
@dynamic segueIdentifier;
@dynamic serialnumber;
@dynamic stateImageName;
@dynamic index;

@end
