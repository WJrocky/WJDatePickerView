//
//  HWPreviewViewController.h
//  GDMobileESOP
//
//  Created by wangjian on 16/6/2.
//  Copyright © 2016年 huawei. All rights reserved.
//

#import "BaseViewController.h"

@interface HWPreviewViewController : BaseViewController

@property (copy, nonatomic) NSString *filePath;

@end
