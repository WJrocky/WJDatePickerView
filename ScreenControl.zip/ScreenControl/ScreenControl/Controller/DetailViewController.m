//
//  DetailViewController.m
//  ScreenControl
//
//  Created by wangjian on 13/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"
#import "UIView+Toast.h"
#import "RuntimeData.h"
#import "VtronSession.h"
#import "MBProgressHUD.h"
#import "HomeItemCell.h"
#import "MagicalRecord.h"
#import "UIButton+EnlargeEdge.h"
#import "DetailViewController.h"
#import "VtronSocket+Protocol.h"

@interface DetailViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, VtronSessionDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (nonatomic, strong) NSArray *icons;
@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) NSUserDefaults *userDefaults;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);
    [myButton setEnlargeEdgeWithTop:15 bottom:4 left:15 right:4];
    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;

    self.userDefaults = [NSUserDefaults standardUserDefaults];
    
    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;

    NSString *name = [self.model.iconMenuName convertDataToStr];
    
    self.title = [self.model.iconMenuName convertDataToStr];
    
//    self.icons = [[Icon MR_findByAttribute:@"functionType" withValue:name] mutableCopy];
    NSString *version = NSLocalizedString(@"version", nil);
    NSPredicate *predicate = [NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(version == '%@') AND (functionType == '%@')", version, name]];
    self.icons = [[Icon MR_findAllWithPredicate:predicate] mutableCopy];
    self.icons = [self.icons sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"serialnumber" ascending:YES]]];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];

    NSString *light_model = NSLocalizedString(@"light model", nil);
    NSString *VWAS_model = NSLocalizedString(@"VWAS model", nil);

    if (isReleaseVersion) {
        if ([name isEqualToString:VWAS_model]) {
            self.icons = [RuntimeData sharedInstance].VWASList;
        } else if ([name isEqualToString:light_model]) {
            self.icons = [RuntimeData sharedInstance].lightDataList;
        }
    }
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.icons.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
    [cell loadData:[self.icons objectAtIndex:indexPath.item]];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *name = [self.model.iconMenuName convertDataToStr];
    NSString *desktop_settings = NSLocalizedString(@"desktop settings", nil);
    NSString *light_model = NSLocalizedString(@"light model", nil);
    NSString *VWAS_model = NSLocalizedString(@"VWAS model", nil);

    if ([name isEqualToString:VWAS_model]) {

        Icon *model = [self.icons objectAtIndex:indexPath.row];
        [self.session.socket sendStartVWASModelMessage:model.iconMenuName];

    } else if ([name isEqualToString:light_model]) {
        [self.session.socket sendStartlightModelMessage:indexPath.row];
    } else if ([name isEqualToString:desktop_settings]) {
        [self.session.socket sendSettingDesktopMessage:self.model.index];
    }
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidReceivedData:(NSData *)data
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    if (data.length > 6) {
        NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
        if ([orderData isEqualToData:[NSData dataFromHexString:@"0310"]]) {
            NSLog(@"VWAS调用成功!");
        } else if ([orderData isEqualToData:[NSData dataFromHexString:@"0b10"]]) {
            NSLog(@"操作成功!");
        } else {
            NSString *message = NSLocalizedString(@"operation_failed", nil);
            [self.view makeToast:message];
            
        }
    }
}

- (void)sessionDidSendData:(NSData *)data
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSString *message = NSLocalizedString(@"action", nil);
    hud.labelText = message;
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
}

@end
