//
//  Icon+CoreDataProperties.m
//  ScreenControl
//
//  Created by wangjian on 13/10/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "Icon+CoreDataProperties.h"

@implementation Icon (CoreDataProperties)

+ (NSFetchRequest<Icon *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Icon"];
}

@dynamic canRemove;
@dynamic fileName;
@dynamic functionType;
@dynamic iconImageName;
@dynamic iconMenuName;
@dynamic index;
@dynamic isFrequentlyUsed;
@dynamic isStub;
@dynamic segueIdentifier;
@dynamic serialnumber;
@dynamic stateImageName;
@dynamic version;

@end
