//
//  Icon+CoreDataProperties.h
//  ScreenControl
//
//  Created by wangjian on 13/10/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "Icon+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Icon (CoreDataProperties)

+ (NSFetchRequest<Icon *> *)fetchRequest;

@property (nonatomic) BOOL canRemove;
@property (nullable, nonatomic, copy) NSString *fileName;
@property (nullable, nonatomic, copy) NSString *functionType;
@property (nullable, nonatomic, copy) NSString *iconImageName;
@property (nullable, nonatomic, retain) NSData *iconMenuName;
@property (nonatomic) int16_t index;
@property (nonatomic) BOOL isFrequentlyUsed;
@property (nonatomic) BOOL isStub;
@property (nullable, nonatomic, copy) NSString *segueIdentifier;
@property (nonatomic) int16_t serialnumber;
@property (nullable, nonatomic, copy) NSString *stateImageName;
@property (nullable, nonatomic, copy) NSString *version;

@end

NS_ASSUME_NONNULL_END
