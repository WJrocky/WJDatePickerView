//
//  SmallItemCell.m
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "SmallItemCell.h"
#import "IconInformationModel.h"

@interface SmallItemCell ()

@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;

@end

@implementation SmallItemCell

- (void)loadData:(IconInformationModel *)data
{
    self.iconImageView.image = [UIImage imageNamed:data.iconImageName];
}

@end
