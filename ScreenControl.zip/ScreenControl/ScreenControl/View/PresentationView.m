//
//  PresentationView.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "PresentationView.h"

@interface PresentationView ()<UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UIView *containerView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;

@end

@implementation PresentationView

- (void)awakeFromNib
{
    [super awakeFromNib];
    self.titleLabel.text = NSLocalizedString(@"confirm_close", nil);
    self.contentLabel.text = NSLocalizedString(@"confirm_close_message", nil);
    [self.cancelButton setTitle:NSLocalizedString(@"confirm_close_no", nil) forState:UIControlStateNormal];
    [self.confirmButton setTitle:NSLocalizedString(@"confirm_close_yes", nil) forState:UIControlStateNormal];
}

+ (id)popAlertView
{
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    if ([[[keyWindow subviews] lastObject] isKindOfClass:[self class]]) {
        return nil;
    }

    PresentationView *presentationView = [[[NSBundle mainBundle] loadNibNamed:@"PresentationView"
                                                                        owner:nil
                                                                      options:nil] firstObject];

    presentationView.frame = [UIScreen mainScreen].bounds;

    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:presentationView action:@selector(dismissSelf)];
    tapGesture.delegate = presentationView;
    [presentationView addGestureRecognizer:tapGesture];

    [keyWindow addSubview:presentationView];

    return presentationView;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isEqual:self.containerView]) {
        return NO;
    }
    return YES;
}

- (void)dismissSelf
{
    [self removeFromSuperview];
}

- (IBAction)cancelButtonAction:(UIButton *)sender {
    [self removeFromSuperview];
}

- (IBAction)confirmButtonAction:(UIButton *)sender {
    if ([self.delegate respondsToSelector:@selector(presentationView:didTapConfirmButton:)]) {
        [self.delegate presentationView:self didTapConfirmButton:sender];
    }
    [self removeFromSuperview];
}

@end
