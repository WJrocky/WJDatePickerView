//
//  HomeItemCell.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"
#import "HomeItemCell.h"
#import "Icon+CoreDataClass.h"

@interface HomeItemCell ()

@property (nonatomic, strong) UIImageView *iconImageView;
@property (nonatomic, strong) UILabel *nameLabel;

@end

@implementation HomeItemCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    for (UIView *subview in [self.contentView subviews]) {
        if ([subview isKindOfClass:[UIImageView class]]) {
            if (subview.frame.size.width == 70 && subview.frame.size.height == 70) {
                self.iconImageView = (UIImageView *)subview;
            } else {
                self.stateImageView = (UIImageView *)subview;
            }
        } else if ([subview isKindOfClass:[UILabel class]]) {
            self.nameLabel = (UILabel *)subview;
        } else {
            NSLog(@"HomeItemCell subviews error!");
        }
    }
}

- (void)loadData:(Icon *)data
{
    NSString *name = nil;
    if ([data.functionType isEqualToString:@"光学模式"]) {
        name = [data.iconMenuName convertDataToStr];
    } else {
        NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        name = [[NSString alloc] initWithData:data.iconMenuName encoding:enc];
    }
    NSString *message = NSLocalizedString(@"default_model", nil);
    self.nameLabel.text = name.length != 0 ? name:message;
    self.iconImageView.image = [UIImage imageNamed:data.iconImageName];
}

@end
