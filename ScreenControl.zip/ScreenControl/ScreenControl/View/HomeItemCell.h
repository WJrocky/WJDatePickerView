//
//  HomeItemCell.h
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Icon;
@interface HomeItemCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *stateImageView;
- (void)loadData:(Icon *)data;

@end
