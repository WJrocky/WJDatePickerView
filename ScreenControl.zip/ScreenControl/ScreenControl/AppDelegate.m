//
//  AppDelegate.m
//  ScreenControl
//
//  Created by wangjian on 07/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "VtronSession.h"
#import "NSData+Vtron.h"
#import "AppDelegate.h"
#import "RuntimeData.h"
#import "MagicalRecord.h"
#import "Icon+CoreDataClass.h"
#import "Reachability.h"
#import "UIView+Toast.h"
#import "AsyncUdpSocket.h"
#import "MBProgressHUD.h"

@interface AppDelegate ()<AsyncUdpSocketDelegate>

@property (nonatomic, strong) AsyncUdpSocket *socket;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    NSDictionary *colorAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};

//    NSArray *temp = @[@"Light model"];
//    for (NSString *name in temp) {
//        NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
//        NSData *data = [name dataUsingEncoding:enc];
//        NSLog(@"name = %@ data === %@", name, data);
//    }

    [[UINavigationBar appearance] setTitleTextAttributes:colorAttributes];
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    
    [MagicalRecord setupCoreDataStackWithStoreNamed:@"PersistentData.sqlite"];
    
#warning 设置版本号
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isReleaseVersion"];
    
    //只需要实例化设置桌面部分即可
//    if (0 == [Icon MR_findAll].count) {
        NSString *resourceName = NSLocalizedString(@"plist_name", nil);

        NSString *path = [[NSBundle mainBundle] pathForResource:resourceName ofType:@"plist"];
        NSArray *functions = [NSArray arrayWithContentsOfFile:path];

        NSString *desktop_settings = NSLocalizedString(@"desktop settings", nil);
        NSString *common_functions = NSLocalizedString(@"common functions", nil);
        NSString *other_functions = NSLocalizedString(@"other functions", nil);
        NSString *light_model = NSLocalizedString(@"light model", nil);
        NSString *VWAS_model = NSLocalizedString(@"VWAS model", nil);
        NSString *more_function = NSLocalizedString(@"more_function", nil);

        for (NSDictionary *iconDictionary in functions) {
            if ([[iconDictionary valueForKey:@"functionType"] isEqualToString:desktop_settings]||
                [[iconDictionary valueForKey:@"functionType"] isEqualToString:common_functions]||
                [[iconDictionary valueForKey:@"functionType"] isEqualToString:other_functions]||
                [[iconDictionary valueForKey:@"functionType"] isEqualToString:VWAS_model]||
                [[iconDictionary valueForKey:@"functionType"] isEqualToString:light_model]||
                [[iconDictionary valueForKey:@"functionType"] isEqualToString:more_function]) {
                Icon *icon = [[Icon MR_findByAttribute:@"iconMenuName" withValue:[iconDictionary valueForKey:@"iconMenuName"]] firstObject];
                if (!icon) {
                    icon = [Icon MR_createEntity];
                    [icon setValuesForKeysWithDictionary:iconDictionary];
                    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                }
            }
        }
//    }

    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus status = [reach currentReachabilityStatus];

    if (ReachableViaWiFi != status) {
        NSString *message = NSLocalizedString(@"wifi_fail", nil);
        [self.window makeToast:message];
    } else {
        //创建socket(UDP)
        self.socket = [[AsyncUdpSocket alloc] initWithDelegate:self];

        //允许广播形式
        [self.socket enableBroadcast:YES error:nil];

        //监听的端口(绑定端口)和发送到的目的端口要一致。
        //要进行广播数据，可以绑定ip地址和端口或者只绑定端口
        [self.socket bindToAddress:[[RuntimeData sharedInstance] getIPAddress:YES] port:12000 error:nil];

        char body[10] = {0x01,0x00,0x01,0x00,0x00,0x10,0x00,0x00,0x00,0x00};

        NSData *data = [NSData dataWithBytes:body length:10];

        //启动接收线程
        [self.socket receiveWithTimeout:2 tag:0];

        [self.socket sendData:data toHost:@"255.255.255.255" port:12000 withTimeout:-1 tag:0];

        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.window.rootViewController.view animated:YES];
        NSString *message = NSLocalizedString(@"broadcast", nil);
        hud.labelText = message;
    }
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    /*
     _client = [[AsyncUdpSocket alloc]initWithDelegate:self];
     NSError *err = nil;
     [_client bindToPort:PORT error:&err];
     if (err) {
     NSLog(@"error:%@",err);
     }
     
     [_client enableBroadcast:YES error:&err];
     char send[5] = {0x69,0x68,0x16,0x17};
     
     NSString *msg = [[NSString alloc]initWithUTF8String:&send];
     NSData *senddata = [msg dataUsingEncoding:NSUTF8StringEncoding];
     
     [_client sendData:senddata toHost:IP port:PORT withTimeout:-1 tag:0];
     [_client receiveWithTimeout:-1 tag:0];
    */
}

- (void)applicationWillTerminate:(UIApplication *)application {
    [MagicalRecord cleanUp];
}

#pragma mark - AsyncUdpSocketDelegate
//已接收消息
- (BOOL)onUdpSocket:(AsyncUdpSocket *)sock
     didReceiveData:(NSData *)data
            withTag:(long)tag
           fromHost:(NSString *)host
               port:(UInt16)port
{
    [MBProgressHUD hideHUDForView:self.window.rootViewController.view animated:YES];
    if (data.length > 6) {
        NSData *orderID = [data subdataWithRange:NSMakeRange(4, 2)];
        if ([orderID isEqualToData:[NSData dataFromHexString:@"0110"]]) {
            //这里做一下验证，确定命令ID是0110
            [RuntimeData sharedInstance].host = host;
            [RuntimeData sharedInstance].pptHost = host;
            NSLog(@"获取IP:%@", host);
        }
    }
    [sock close];
    return YES;
}

- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotReceiveDataWithTag:(long)tag dueToError:(NSError *)error
{
    [MBProgressHUD hideHUDForView:self.window.rootViewController.view animated:YES];
    [sock close];
    NSString *message = NSLocalizedString(@"ip_fail", nil);
    [self.window makeToast:message];
}

@end
