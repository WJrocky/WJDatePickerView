//
//  VtronSession.m
//  ScreenControl
//
//  Created by wangjian on 25/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "RuntimeData.h"
#import "VtronSocket.h"
#import "NSData+Vtron.h"
#import "VtronSession.h"
#import "VtronSocket+Protocol.h"

@interface VtronSession ()<VtronSocketDelegate>

@property (nonatomic, strong) VtronSocket *socket;

@end

@implementation VtronSession

+ (instancetype)sharedInstance
{

    static VtronSession *session = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        session = [[VtronSession alloc] init];
        session.socket = [[VtronSocket alloc] init];
        session.socket.delegate = session;
        NSString *host = [RuntimeData sharedInstance].host;
        if (!session.isConnected && host.length != 0) {
            [session.socket tcpConnectToHost:host port:12001];
        }
    });
    return session;
}

#pragma mark - VtronSocketDelegate
- (void)VtronSocket:(VtronSocket *)socket didChangeStatus:(NSStreamEvent)streamStatus
{
    switch (streamStatus) {
        case NSStreamEventNone:
            break;
        case NSStreamEventOpenCompleted:      //建立连接
            self.isConnected = YES;
            break;
        case NSStreamEventHasBytesAvailable:  //有字节可读
            if ([self.delegate respondsToSelector:@selector(sessionDidReceivedData:)]) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self.delegate sessionDidReceivedData:[self.socket readData]];
                });
            }
            break;
        case NSStreamEventHasSpaceAvailable:  //有字节可写
            if ([self.delegate respondsToSelector:@selector(sessionPreparedForWrite)]) {
                [self.delegate sessionPreparedForWrite];
            }
            break;
        case NSStreamEventErrorOccurred:      //连接出错

            break;
        case NSStreamEventEndEncountered:     //连接结束
            self.isConnected = NO;
            break;
        default:
            break;
    }
}

- (void)VtronSocket:(VtronSocket *)socket didSendData:(NSData *)data
{
    if ([_delegate respondsToSelector:@selector(sessionDidSendData:)]) {
        [_delegate sessionDidSendData:data];
    }
}

@end
