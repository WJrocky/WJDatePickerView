//
//  HomeViewController.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "HomeItemCell.h"
#import "FoldItemsCell.h"
#import "PresentationView.h"
#import "PopViewController.h"
#import "HomeViewController.h"
#import "MoreViewController.h"
#import "DetailViewController.h"
#import "IconInformationModel.h"
#import "PresentationController.h"
#import "BlurContainerController.h"

@interface HomeViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;

@property (nonatomic, assign) BOOL isPop;
@property (nonatomic, assign) CGPoint center;
@property (nonatomic, assign) CGPoint startPoint;
@property (nonatomic, weak) HomeItemCell *selectedCell;
@property (nonatomic, strong) NSMutableArray *iconDataArray;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
    [self.functionCollectionView addGestureRecognizer:longPressGesture];

    NSString *path = [[NSBundle mainBundle] pathForResource:@"HomeFunction" ofType:@"plist"];

    NSArray<NSDictionary *> *homeFunctions = [NSArray arrayWithContentsOfFile:path];

    self.iconDataArray = [NSMutableArray array];

    for (NSDictionary *dictionary in homeFunctions) {

        IconInformationModel *model = [[IconInformationModel alloc] init];
        for (NSDictionary *subDictionary in [dictionary valueForKey:@"subFunctions"]) {
            IconInformationModel *subModel = [[IconInformationModel alloc] init];
            [subModel setValuesForKeysWithDictionary:subDictionary];
            [model.subIconModels addObject:subModel];
        }
        [model setValuesForKeysWithDictionary:dictionary];
        [self.iconDataArray addObject:model];
        
    }
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.iconDataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    id model = [self.iconDataArray objectAtIndex:indexPath.item];
    if ([model isKindOfClass:[IconInformationModel class]]) {
        HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
        [cell loadData:model];
        return cell;
    } else  {
        FoldItemsCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"FoldItemsCell" forIndexPath:indexPath];
        NSArray *keys = [model allKeys];
        [cell loadData:[model valueForKey:[keys firstObject]]];
        return cell;
    }
}

- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{
    [self.iconDataArray exchangeObjectAtIndex:sourceIndexPath.item withObjectAtIndex:destinationIndexPath.item];
}

#pragma mark - UICollectionViewDelegateFlowLayout

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    id model = [self.iconDataArray objectAtIndex:indexPath.item];
    if ([model isKindOfClass:[IconInformationModel class]]) {
        if (((IconInformationModel *)model).segueIdentifier.length != 0) {
            [self performSegueWithIdentifier:((IconInformationModel *)model).segueIdentifier sender:model];
        }
    } else {

        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle:nil];
        PopViewController *popViewController = [storyboard instantiateViewControllerWithIdentifier:@"PopViewController"];

        [popViewController view];

        UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
        
        [keyWindow addSubview:popViewController.view];
        [self addChildViewController:popViewController];

        popViewController.view.alpha = 0.0;

        [popViewController loadData:model];

        [UIView animateWithDuration:0.3 animations:^{
            popViewController.view.alpha = 1.0;
        }];
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    IconInformationModel *model = sender;
    UIViewController *controller = segue.destinationViewController;
    if ([controller isKindOfClass:[DetailViewController class]]) {
        ((DetailViewController *)controller).model = model;
    }
}

- (void)longPressAction:(UILongPressGestureRecognizer *)gesture
{
    CGPoint point = [gesture locationInView:self.functionCollectionView];

    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            if (!indexPath) {
                break;
            }
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];
            self.center = cell.center;
            self.startPoint = point;
            point = cell.center;
            [self.functionCollectionView beginInteractiveMovementForItemAtIndexPath:indexPath];
            self.selectedCell = cell;
        }
            break;

        case UIGestureRecognizerStateChanged:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];

            point = CGPointMake(self.center.x + point.x - self.startPoint.x, self.center.y + point.y - self.startPoint.y);
            CGRect rect = CGRectMake(cell.center.x - 8, cell.center.y - 8, 16, 16);
            if (CGRectContainsPoint(rect, point) && (self.selectedCell != cell)) {
                //弹出遮幕
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (CGRectContainsPoint(rect, point)) {
                        if (!self.isPop) {
                            self.isPop = YES;

//                            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
//                                                                                 bundle:nil];
//                            BlurContainerController *blurContainerController = [storyboard instantiateViewControllerWithIdentifier:@"BlurContainerController"];
//
//                            [blurContainerController view];
//                            CGRect cellframe = [cell convertRect:cell.bounds
//                                                          toView:nil];
//                            [blurContainerController setBlurContainerViewOriginalFrame:cellframe
//                                                                        originalCenter:cell.center];
//
//                            [blurContainerController setCellRemovedBlock:^{
//                                self.isPop = NO;
//                            }];
//                            UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
//                            [keyWindow addSubview:blurContainerController.view];
//                            [self addChildViewController:blurContainerController];
                            
                            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                                                 bundle:nil];
                            PopViewController *popViewController = [storyboard instantiateViewControllerWithIdentifier:@"PopViewController"];
                            
                            [popViewController view];
                            
                            UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
                            
                            [keyWindow addSubview:popViewController.view];
                            [self addChildViewController:popViewController];
                            
                            popViewController.view.alpha = 0.0;
                            
                            [UIView animateWithDuration:0.3 animations:^{
                                popViewController.view.alpha = 1.0;
                            }];

                            NSIndexPath *selectedIndexPath = [self.functionCollectionView indexPathForCell:self.selectedCell];
                            
                            id model = [self.iconDataArray objectAtIndex:indexPath.row];
                            NSMutableArray *models;
                            if ([model isKindOfClass:[IconInformationModel class]]) {
                                
                                NSMutableDictionary *multipleModel = [NSMutableDictionary dictionary];
                                
                                models = [NSMutableArray array];
                                IconInformationModel *selectedModel = [self.iconDataArray objectAtIndex:selectedIndexPath.row];
                                [models addObject:selectedModel];
                                [models addObject:[self.iconDataArray objectAtIndex:indexPath.row]];
                                
                                [multipleModel setValue:models forKey:selectedModel.iconMenuName];
                                
                                [self.iconDataArray replaceObjectAtIndex:indexPath.row withObject:multipleModel];
                            } else {
                                NSArray *keys = [model allKeys];
                                models = [model valueForKey:[keys firstObject]];
                                
                                [models addObject:[self.iconDataArray objectAtIndex:indexPath.row]];
                                
                                [self.iconDataArray replaceObjectAtIndex:indexPath.row withObject:model];
                            }
                            
                            [popViewController loadData:models];
                            
                            [self.iconDataArray removeObjectAtIndex:selectedIndexPath.row];
                            [self.functionCollectionView deleteItemsAtIndexPaths:@[selectedIndexPath]];
                        }
                    }
                });
            }
            [self.functionCollectionView updateInteractiveMovementTargetPosition:point];
        }
            break;
        case UIGestureRecognizerStateEnded:
            [self.functionCollectionView endInteractiveMovement];
            break;
        default:
            [self.functionCollectionView cancelInteractiveMovement];
            break;
    }
}

- (NSIndexPath *)collectionView:(UICollectionView *)collectionView targetIndexPathForMoveFromItemAtIndexPath:(NSIndexPath *)originalIndexPath toProposedIndexPath:(NSIndexPath *)proposedIndexPath
{
    UICollectionViewCell *originalCell = [collectionView cellForItemAtIndexPath:originalIndexPath];
    UICollectionViewCell *proposedCell = [collectionView cellForItemAtIndexPath:proposedIndexPath];
    if ((originalCell.center.x > proposedCell.center.x + 10.0) ||(originalCell.center.y > proposedCell.center.y + 10)) {
        return proposedIndexPath;
    }
    return  originalIndexPath;
}

- (IBAction)moreBarButtonItemAction:(UIBarButtonItem *)sender {
    [self performSegueWithIdentifier:@"ShowMoreViewController" sender:nil];
}

@end
