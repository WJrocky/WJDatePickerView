//
//  PopViewController.h
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^cellRemovedBlock)();
@interface PopViewController : UIViewController

- (void)loadData:(NSMutableArray *)dataArray;
- (void)setCellRemovedBlock:(cellRemovedBlock)cellRemovedBlock;

@end
