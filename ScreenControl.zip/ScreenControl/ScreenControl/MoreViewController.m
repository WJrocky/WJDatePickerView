//
//  MoreViewController.m
//  ScreenControl
//
//  Created by wangjian on 11/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "HomeItemCell.h"
#import "MoreViewController.h"
#import "IconInformationModel.h"
#import "MoreTitleReusableView.h"

@interface MoreViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *editBarButtonItem;
@property (nonatomic, strong) NSMutableArray *sectionArray;
@property (nonatomic, assign) NSUInteger count;
@property (nonatomic, assign) BOOL isEditing;

@end

@implementation MoreViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);

    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;

    NSDictionary *attributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:15.0],NSForegroundColorAttributeName:[UIColor whiteColor]};

    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:attributes forState:UIControlStateNormal];
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"MoreFunction" ofType:@"plist"];
    NSArray *allFunctionArray = [NSArray arrayWithContentsOfFile:plistPath];

    self.sectionArray = [NSMutableArray array];
    for (NSDictionary *dictionary in allFunctionArray) {
        IconInformationModel *model = [[IconInformationModel alloc] init];
        for (NSDictionary *subDictionary in [dictionary valueForKey:@"subFunctions"]) {
            IconInformationModel *subModel = [[IconInformationModel alloc] init];
            [subModel setValuesForKeysWithDictionary:subDictionary];
            [model.subIconModels addObject:subModel];
        }
        [model setValuesForKeysWithDictionary:dictionary];
        [self.sectionArray addObject:model];
    }
    [self.functionCollectionView reloadData];

    IconInformationModel *firstModel = [self.sectionArray firstObject];
    self.count = firstModel.subIconModels.count;
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return self.sectionArray.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    IconInformationModel *model = [self.sectionArray objectAtIndex:section];
    return [model.subIconModels count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
    IconInformationModel *model = [self.sectionArray objectAtIndex:indexPath.section];
    IconInformationModel *subModel = [model.subIconModels objectAtIndex:indexPath.item];
    [cell loadData:subModel];
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    MoreTitleReusableView *titleView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"MoreTitleReusableView" forIndexPath:indexPath];
    IconInformationModel *model = [self.sectionArray objectAtIndex:indexPath.section];
    [titleView loadData:model];
    return titleView;
}

#pragma mark - UICollectionViewDelegateFlowLayout

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isEditing) {
        IconInformationModel *model = [self.sectionArray firstObject];
        if (indexPath.section > 0) {
            NSIndexPath *lastIndexPath = [NSIndexPath indexPathForItem:model.subIconModels.count inSection:0];
            IconInformationModel *tapedModel = [self.sectionArray objectAtIndex:indexPath.section];
            if (![model.subIconModels containsObject:[tapedModel.subIconModels objectAtIndex:indexPath.item]]) {
                [model.subIconModels addObject:[tapedModel.subIconModels objectAtIndex:indexPath.item]];
                [collectionView insertItemsAtIndexPaths:@[lastIndexPath]];
            }
        } else {
            if (indexPath.item >= self.count) {
                [model.subIconModels removeObjectAtIndex:indexPath.item];
                [collectionView deleteItemsAtIndexPaths:@[indexPath]];
            }
        }
    }
}

- (IBAction)editBarButtonAction:(UIBarButtonItem *)sender {
    self.isEditing = !self.isEditing;
    sender.title = self.isEditing ? @"完成":@"编辑";
}

@end
