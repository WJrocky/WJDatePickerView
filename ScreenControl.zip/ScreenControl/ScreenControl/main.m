//
//  main.m
//  ScreenControl
//
//  Created by wangjian on 07/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
