//
//  LoginViewController.m
//  ScreenControl
//
//  Created by wangjian on 07/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "AsyncUdpSocket.h"
#import "HomeViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD/MBProgressHUD.h"

@interface LoginViewController ()<UITextFieldDelegate, AsyncUdpSocketDelegate>

@property (weak, nonatomic) IBOutlet UITextField *accountTextField;
@property (weak, nonatomic) IBOutlet UITextField *mobileTextField;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIButton *savePasswordButton;

@property (nonatomic, strong) NSUserDefaults *userDefaults;

@end

@implementation LoginViewController

- (void)customizeAppearance
{
    NSDictionary *colorAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};

    NSAttributedString *accountPlaceholder = [[NSAttributedString alloc] initWithString:@"账号" attributes:colorAttributes];
    self.accountTextField.attributedPlaceholder = accountPlaceholder;

    NSAttributedString *mobilePlaceholder = [[NSAttributedString alloc] initWithString:@"手机" attributes:colorAttributes];
    self.mobileTextField.attributedPlaceholder = mobilePlaceholder;

    self.userDefaults = [NSUserDefaults standardUserDefaults];

    BOOL isSavedPassword = [self.userDefaults boolForKey:@"isSavedPassword"];
    NSString *username = [self.userDefaults valueForKey:@"username"];
    NSString *password = [self.userDefaults valueForKey:@"password"];
    if (10 == password.length) {
        self.loginButton.backgroundColor = [UIColor colorWithRed:190.0 / 255.0
                                                           green:58.0 / 255.0
                                                            blue:58.0 / 255.0
                                                           alpha:1.0];
    }

    [self.savePasswordButton setSelected:isSavedPassword];
    self.accountTextField.text = username;
    self.mobileTextField.text = password;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self customizeAppearance];
}


#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (10 == textField.text.length) {
        //改变button颜色
        self.loginButton.backgroundColor = [UIColor colorWithRed:190.0 / 255.0
                                                           green:58.0 / 255.0
                                                            blue:58.0 / 255.0
                                                           alpha:1.0];
    } else if (textField.text.length > 10) {
        //这里可以做一个toast
        NSLog(@"手机号长度不能超出11位！");
        return NO;
    }
    return YES;
}

- (IBAction)savePasswordButtonAction:(UIButton *)sender {
    sender.selected = !sender.selected;
    [self.userDefaults setBool:sender.selected forKey:@"isSavedPassword"];
}

- (IBAction)loginButtonAction:(UIButton *)sender {

    [self.userDefaults setValue:self.accountTextField.text forKey:@"username"];

    BOOL isSavedPassword = [self.userDefaults boolForKey:@"isSavedPassword"];

    if (isSavedPassword) {
        [self.userDefaults setValue:self.mobileTextField.text forKey:@"password"];
    } else {
        [self.userDefaults setValue:@"" forKey:@"password"];
    }

    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"loading";

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle:nil];
        HomeViewController *homeViewController = [storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [self.navigationController setViewControllers:@[homeViewController]];
    });

//    AsyncUdpSocket *socket = [[AsyncUdpSocket alloc] initWithDelegate:self];
//
//    NSError *err = nil;
//    [socket enableBroadcast:YES error:&err];
//    [socket bindToPort:9527 error:&err];
//
//    NSString *str = @"谁是服务器？我的IP是：192.168.80.103";
//    NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
//
//    [socket sendData:data toHost:@"255.255.255.255" port:9527 withTimeout:-1 tag:0];
}

- (IBAction)changePasswordStateAction:(UIButton *)sender {
    self.mobileTextField.secureTextEntry = !self.mobileTextField.secureTextEntry;
    sender.selected = !sender.selected;
}

#pragma mark - AsyncUdpSocketDelegate
//已接收消息
- (BOOL)onUdpSocket:(AsyncUdpSocket *)sock
     didReceiveData:(NSData *)data
            withTag:(long)tag
           fromHost:(NSString *)host
               port:(UInt16)port
{
    return YES;
}

//没有接受消息
- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotReceiveDataWithTag:(long)tag dueToError:(NSError *)error
{

}

//没有发出消息
- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotSendDataWithTag:(long)tag dueToError:(NSError *)error
{

}

//已发出消息
- (void)onUdpSocket:(AsyncUdpSocket *)sock didSendDataWithTag:(long)tag
{

}

//断开连接
- (void)onUdpSocketDidClose:(AsyncUdpSocket *)sock
{

}

@end
