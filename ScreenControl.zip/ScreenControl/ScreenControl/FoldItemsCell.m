//
//  FoldItemsCell.m
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "FoldItemsCell.h"
#import "SmallItemCell.h"
#import "IconInformationModel.h"

@interface FoldItemsCell ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (nonatomic, strong) NSArray *iconDataArray;

@end

@implementation FoldItemsCell

- (void)loadData:(NSArray *)iconDataArray
{
    self.iconDataArray = iconDataArray;
    IconInformationModel *model = [iconDataArray firstObject];
    self.titleLabel.text = model.iconMenuName;
    [self.functionCollectionView reloadData];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.iconDataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    SmallItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SmallItemCell" forIndexPath:indexPath];
    IconInformationModel *model = [self.iconDataArray objectAtIndex:indexPath.item];
    [cell loadData:model];
    return cell;
}

#pragma mark - UICollectionViewDelegateFlowLayout

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{

}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    UIView *view = [super hitTest:point withEvent:event];
    if (view == self.functionCollectionView) {
        return self;
    }
    return view;
}

@end
