//
//  BlurContainerController.h
//  ScreenControl
//
//  Created by wangjian on 11/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^cellRemovedBlock)();
@interface BlurContainerController : UIViewController

@property (weak, nonatomic) IBOutlet UIVisualEffectView *blurBackgroundView;

- (void)setBlurContainerViewOriginalFrame:(CGRect)frame
                           originalCenter:(CGPoint)originalCenter;
- (void)setCellRemovedBlock:(cellRemovedBlock)cellRemovedBlock;

@end
