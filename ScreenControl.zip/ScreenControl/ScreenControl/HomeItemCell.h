//
//  HomeItemCell.h
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IconInformationModel;
@interface HomeItemCell : UICollectionViewCell

- (void)loadData:(IconInformationModel *)data;

@end
