//
//  NSData+Vtron.h
//  ScreenControl
//
//  Created by wangjian on 29/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (Vtron)

//大端字节
- (int)valueOfBigUint32_t;

//小端字节
- (int)valueOfUint32_t;

//将字符串转化为data
+ (NSData *)dataFromHexString:(NSString *)str;

//将data转换为十六进制字符串
- (NSString *)convertDataToHexStr;

//将data转换为字符
- (NSString *)convertDataToStr;

@end
