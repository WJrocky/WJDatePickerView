//
//  AppDelegate.m
//  ScreenControl
//
//  Created by wangjian on 07/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "VtronSession.h"
#import "NSData+Vtron.h"
#import "AppDelegate.h"
#import "RuntimeData.h"
#import "MagicalRecord.h"
#import "Icon+CoreDataClass.h"
#import "Reachability.h"
#import "UIView+Toast.h"
#import "AsyncUdpSocket.h"
#import "MBProgressHUD.h"

@interface AppDelegate ()<AsyncUdpSocketDelegate>

@property (nonatomic, strong) AsyncUdpSocket *socket;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    NSDictionary *colorAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};

    [[UINavigationBar appearance] setTitleTextAttributes:colorAttributes];
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    
    [MagicalRecord setupCoreDataStackWithStoreNamed:@"PersistentData.sqlite"];
    
#warning 设置版本号
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"isReleaseVersion"];
    
    //只需要实例化设置桌面部分即可
    NSString *resourceName = NSLocalizedString(@"plist_name", nil);

    NSString *path = [[NSBundle mainBundle] pathForResource:resourceName ofType:@"plist"];
    NSArray *functions = [NSArray arrayWithContentsOfFile:path];

    NSString *desktop_settings = NSLocalizedString(@"desktop settings", nil);
    NSString *common_functions = NSLocalizedString(@"common functions", nil);
    NSString *other_functions = NSLocalizedString(@"other functions", nil);
    NSString *light_model = NSLocalizedString(@"light model", nil);
    NSString *VWAS_model = NSLocalizedString(@"VWAS model", nil);
    NSString *more_function = NSLocalizedString(@"more_function", nil);

    for (NSDictionary *iconDictionary in functions) {
        if ([[iconDictionary valueForKey:@"functionType"] isEqualToString:desktop_settings]||
            [[iconDictionary valueForKey:@"functionType"] isEqualToString:common_functions]||
            [[iconDictionary valueForKey:@"functionType"] isEqualToString:other_functions]||
            [[iconDictionary valueForKey:@"functionType"] isEqualToString:VWAS_model]||
            [[iconDictionary valueForKey:@"functionType"] isEqualToString:light_model]||
            [[iconDictionary valueForKey:@"functionType"] isEqualToString:more_function]) {
            Icon *icon = [[Icon MR_findByAttribute:@"iconMenuName" withValue:[iconDictionary valueForKey:@"iconMenuName"]] firstObject];
            if (!icon) {
                icon = [Icon MR_createEntity];
                [icon setValuesForKeysWithDictionary:iconDictionary];
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
            }
            NSString *version = NSLocalizedString(@"version", nil);
            icon.version = version;
            icon.functionType = [iconDictionary valueForKey:@"functionType"];
            NSLog(@"modle = %@", icon);
        }
    }
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    /*
     _client = [[AsyncUdpSocket alloc]initWithDelegate:self];
     NSError *err = nil;
     [_client bindToPort:PORT error:&err];
     if (err) {
     NSLog(@"error:%@",err);
     }
     
     [_client enableBroadcast:YES error:&err];
     char send[5] = {0x69,0x68,0x16,0x17};
     
     NSString *msg = [[NSString alloc]initWithUTF8String:&send];
     NSData *senddata = [msg dataUsingEncoding:NSUTF8StringEncoding];
     
     [_client sendData:senddata toHost:IP port:PORT withTimeout:-1 tag:0];
     [_client receiveWithTimeout:-1 tag:0];
    */
}

- (void)applicationWillTerminate:(UIApplication *)application {
    [MagicalRecord cleanUp];
}

@end
