//
//  PopViewController.h
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "BaseViewController.h"

@class Icon;
typedef void(^cellRemovedBlock)(Icon *removedModel, NSMutableDictionary *dictionary);
@interface PopViewController : BaseViewController

- (void)loadData:(NSMutableDictionary *)dataDictionary;
- (void)setCellRemovedBlock:(cellRemovedBlock)cellRemovedBlock;

@end
