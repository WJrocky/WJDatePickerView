//
//  PPtTurnPageController.m
//  ScreenControl
//
//  Created by wangjian on 19/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"
#import "VtronSession.h"
#import "UIView+Toast.h"
#import "RuntimeData.h"
#import "PopListController.h"
#import "VtronSocket+Protocol.h"
#import "PPtTurnPageController.h"
#import "UIButton+EnlargeEdge.h"

@interface PPtTurnPageController ()<VtronSocketDelegate>

@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) VtronSocket *socket;
@property (weak, nonatomic) IBOutlet UIButton *changeIPButton;
@property (weak, nonatomic) IBOutlet UILabel *IPLabel;
@property (nonatomic, assign) BOOL isConnected;
@property (nonatomic, assign) BOOL isWarning;

@end

@implementation PPtTurnPageController

- (void)dealloc
{
    [_socket close];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);
    [myButton setEnlargeEdge:4];
    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;
    
    self.socket = [[VtronSocket alloc] init];
    self.socket.delegate = self;
//
//    [self.socket tcpConnectToHost:[RuntimeData sharedInstance].pptHost port:12008];
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)turnLastPageAction:(UIButton *)sender {
//    if (self.isConnected) {
//        [self.socket sendTurnPPTLastPageMessage];
//    } else {
//        self.isWarning = NO;
//        [self.socket tcpConnectToHost:[RuntimeData sharedInstance].pptHost port:12008];
//    }
}

- (IBAction)turnNextPageAction:(UIButton *)sender {
//    if (self.isConnected) {
//        [self.socket sendTurnPPTNextPageMessage];
//    } else {
//        self.isWarning = NO;
//        [self.socket tcpConnectToHost:[RuntimeData sharedInstance].pptHost port:12008];
//    }
}

#pragma mark - VtronSocketDelegate
- (void)VtronSocket:(VtronSocket *)socket didChangeStatus:(NSStreamEvent)streamStatus
{
    if (NSStreamEventHasBytesAvailable == streamStatus) {
        NSData *data = [socket readData];
        if (data.length > 6) {
            NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
            if ([orderData isEqualToData:[NSData dataFromHexString:@"0710"]]) {
                NSData *result = [data subdataWithRange:NSMakeRange(12, 2)];
                if (![result isEqualToData:[NSData dataFromHexString:@"0000"]]) {
                    NSString *message = NSLocalizedString(@"turn_page_fail", nil);
                    [self.view makeToast:message];
                }
            } else {
                NSString *message = NSLocalizedString(@"turn_page_fail", nil);
                [self.view makeToast:message];
            }
        }
    } else if (NSStreamEventOpenCompleted == streamStatus) {
        self.isConnected = YES;
    } else if (NSStreamEventErrorOccurred == streamStatus) {
        if (!self.isWarning) {
            NSString *message = NSLocalizedString(@"net_waring", nil);
            [self.view makeToast:message];
            self.isWarning = YES;
        }
    }
}

- (IBAction)changeIPButtonAction:(UIButton *)sender {
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
//                                                         bundle:nil];
//    PopListController *popListController = [storyboard instantiateViewControllerWithIdentifier:@"PopListController"];
//    popListController.delegate = self;
//    NSMutableArray *dataSource = [NSMutableArray arrayWithArray:@[[RuntimeData sharedInstance].pptHost]];
//    [popListController loadData:dataSource type:@"PPT翻页"];
//    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
//    popListController.view.frame = [UIScreen mainScreen].bounds;
//    
//    [keyWindow addSubview:popListController.view];
//    [self addChildViewController:popListController];
}

@end
