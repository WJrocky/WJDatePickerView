//
//  PopListController.h
//  ScreenControl
//
//  Created by 王健 on 2017/9/27.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "BaseViewController.h"
@class PopListController;
@protocol PopListControllerDelegate <NSObject>

- (void)PopListController:(PopListController *)controller didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface PopListController : BaseViewController

@property (nonatomic, strong) NSString *type;
@property (nonatomic, assign) id<PopListControllerDelegate>delegate;
- (void)loadData:(NSMutableArray *)data type:(NSString *)type;

@end
