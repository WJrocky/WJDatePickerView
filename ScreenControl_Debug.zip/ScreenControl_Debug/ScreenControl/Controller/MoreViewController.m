//
//  MoreViewController.m
//  ScreenControl
//
//  Created by wangjian on 11/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "UIView+Toast.h"
#import "HomeItemCell.h"
#import "MagicalRecord.h"
#import "Icon+CoreDataClass.h"
#import "MoreViewController.h"
#import "Icon+CoreDataClass.h"
#import "MoreTitleReusableView.h"
#import "UIButton+EnlargeEdge.h"

@interface MoreViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *editBarButtonItem;
@property (nonatomic, strong) NSMutableArray *sectionArray;
@property (nonatomic, strong) NSMutableArray *frequentlyFunctions;
@property (nonatomic, copy) FunctionsChangeSuccess functionChangeSuccess;
@property (nonatomic, assign) BOOL isEditing;
@property (nonatomic, strong) NSMutableArray *tempArray;

@end

@implementation MoreViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);
    [myButton setEnlargeEdge:4];
    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;

    NSDictionary *attributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:15.0],NSForegroundColorAttributeName:[UIColor whiteColor]};

    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:attributes forState:UIControlStateNormal];
    
    self.sectionArray = [NSMutableArray array];
//    NSArray *frequentlyUsedFunctions = [Icon MR_findByAttribute:@"isFrequentlyUsed" withValue:[NSNumber numberWithBool:YES]];
    NSString *version = NSLocalizedString(@"version", nil);
    NSPredicate *predicate = [NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(version == '%@') AND (isFrequentlyUsed == YES)", version]];
    NSArray *frequentlyUsedFunctions = [[Icon MR_findAllWithPredicate:predicate] mutableCopy];

    frequentlyUsedFunctions = [frequentlyUsedFunctions sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"serialnumber" ascending:YES]]];

    NSString *desktop_settings = NSLocalizedString(@"desktop settings", nil);
    NSString *other_functions = NSLocalizedString(@"other functions", nil);
    NSString *light_model = NSLocalizedString(@"light model", nil);
    NSString *VWAS_model = NSLocalizedString(@"VWAS model", nil);


    [self.sectionArray addObject:[NSMutableArray arrayWithArray:frequentlyUsedFunctions]];
    [self.sectionArray addObject:[NSMutableArray arrayWithArray:[Icon MR_findByAttribute:@"functionType" withValue:other_functions]]];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
    NSArray *vwasArray = nil;
    NSArray *lightModelArray = nil;
    
    if (isReleaseVersion) {
        vwasArray = [Icon MR_findAllWithPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(functionType == '%@') AND (isStub == NO)", VWAS_model]]];
        lightModelArray = [Icon MR_findAllWithPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(functionType == '%@') AND (isStub == NO)", light_model]]];
    } else {
        vwasArray = [Icon MR_findAllWithPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(functionType == '%@') AND (isStub == YES)", VWAS_model]]];
        lightModelArray = [Icon MR_findAllWithPredicate:[NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(functionType == '%@') AND (isStub == YES)", light_model]]];
    }

    [self.sectionArray addObject:[NSMutableArray arrayWithArray:vwasArray]];
    [self.sectionArray addObject:[NSMutableArray arrayWithArray:lightModelArray]];
    [self.sectionArray addObject:[NSMutableArray arrayWithArray:[Icon MR_findByAttribute:@"functionType" withValue:desktop_settings]]];
}

- (void)backAction
{
    if (self.isEditing) {
        NSString *message = NSLocalizedString(@"edit_warning", nil);
        [self.view makeToast:message];
        return;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return self.sectionArray.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSArray *icons = [self.sectionArray objectAtIndex:section];
    return [icons count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
    NSArray *icons = [self.sectionArray objectAtIndex:indexPath.section];
    Icon *subModel = [icons objectAtIndex:indexPath.item];
    [cell loadData:subModel];
    if (self.isEditing) {
        if (indexPath.section > 0) {
            NSArray *frequentlyUsedFunctions = [self.sectionArray firstObject];
            if ([frequentlyUsedFunctions containsObject:subModel]) {
                cell.stateImageView.image = nil;
            } else {
                cell.stateImageView.image = [UIImage imageNamed:subModel.stateImageName];
            }
        } else {
            cell.stateImageView.image = [UIImage imageNamed:subModel.stateImageName];
        }
    } else {
        cell.stateImageView.image = nil;
    }
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    MoreTitleReusableView *titleView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"MoreTitleReusableView" forIndexPath:indexPath];
    Icon *model = [[self.sectionArray objectAtIndex:indexPath.section] firstObject];
    [titleView loadData:model];
    return titleView;
}

#pragma mark - UICollectionViewDelegateFlowLayout

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isEditing) {
        NSMutableArray *icons = [self.sectionArray firstObject];
        NSArray *tapedIcons = [self.sectionArray objectAtIndex:indexPath.section];
        Icon *icon = [tapedIcons objectAtIndex:indexPath.row];
        if (indexPath.section > 0) {
            
            NSIndexPath *lastIndexPath = [NSIndexPath indexPathForItem:icons.count inSection:0];
            if (![icons containsObject:icon]) {
                [icons addObject:icon];
                icon.isFrequentlyUsed = YES;
                icon.serialnumber = lastIndexPath.row;
                icon.stateImageName = @"function_remove";
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                if (self.functionChangeSuccess) {
                    self.functionChangeSuccess();
                }
                [collectionView reloadData];
            }
        } else {
            if (icon.canRemove) {
                icon.isFrequentlyUsed = NO;
                icon.serialnumber = 0;
                icon.stateImageName = @"function_add";
                NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
                NSString *savedFileName = isReleaseVersion ? @"release_filename":@"stub_filename";
                NSArray *files = [Icon MR_findByAttribute:@"fileName" withValue:icon.fileName];
                if (1 == files.count) {
                    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                    [userDefaults removeObjectForKey:savedFileName];
                }
                icon.fileName = nil;
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                [icons removeObjectAtIndex:indexPath.item];
                if (self.functionChangeSuccess) {
                    self.functionChangeSuccess();
                }
                [collectionView reloadData];
            }
        }
    }
}

- (IBAction)editBarButtonAction:(UIBarButtonItem *)sender {
    self.isEditing = !self.isEditing;
    NSString *edit = NSLocalizedString(@"edit", nil);
    NSString *finish = NSLocalizedString(@"finish", nil);
    sender.title = self.isEditing ? finish:edit;
    [self.functionCollectionView reloadData];
}

@end
