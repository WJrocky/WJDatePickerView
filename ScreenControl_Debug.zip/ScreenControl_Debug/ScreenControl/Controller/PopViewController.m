//
//  PopViewController.m
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "UIView+Toast.h"
#import "NSData+Vtron.h"
#import "VtronSession.h"
#import "HomeItemCell.h"
#import "PresentationView.h"
#import "PopViewController.h"
#import "Icon+CoreDataClass.h"
#import "DetailViewController.h"
#import "VtronSocket+Protocol.h"

@interface PopViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UIGestureRecognizerDelegate,PresentationViewDelegate, VtronSessionDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (nonatomic, copy) cellRemovedBlock cellRemovedBlock;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableDictionary *dataDictionary;
@property (nonatomic, assign) CGPoint center;
@property (nonatomic, assign) CGPoint startPoint;
@property (nonatomic, weak) HomeItemCell *selectedCell;
@property (nonatomic, strong) Icon *selectedModel;
@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) NSString *titleName;

@end

@implementation PopViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
    longPressGesture.delegate = self;
    [self.functionCollectionView addGestureRecognizer:longPressGesture];
}

- (void)loadData:(NSMutableDictionary *)dataDictionary
{
    self.dataDictionary = dataDictionary;
    NSArray *keys = [dataDictionary allKeys];
    self.dataArray = [dataDictionary valueForKey:[keys firstObject]];
    self.titleName = [keys firstObject];
    self.nameTextField.text = [keys firstObject];
    [self.functionCollectionView reloadData];
    
    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];

    [cell loadData:[self.dataArray objectAtIndex:indexPath.row]];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{

}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *desktop_settings = NSLocalizedString(@"desktop settings", nil);
    NSString *light_model = NSLocalizedString(@"light model", nil);
    NSString *VWAS_model = NSLocalizedString(@"VWAS model", nil);
    NSString *turn_on = NSLocalizedString(@"turn_on", nil);
    NSString *turn_off = NSLocalizedString(@"turn_off", nil);

    Icon *model = [self.dataArray objectAtIndex:indexPath.item];
    if (model.segueIdentifier.length != 0) {
        [self performSegueWithIdentifier:model.segueIdentifier sender:model];
        self.selectedModel = nil;
        [self dismissSelf];
    } else if ([model.iconMenuName isEqualToData:[NSData dataFromHexString:turn_on]]) {
        
        //开机
        [self.session.socket sendStartOrShutDownMessage:0];
        
    } else if ([model.iconMenuName isEqualToData:[NSData dataFromHexString:turn_off]]) {
        
        //关机
        PresentationView *view = [PresentationView popAlertView];
        view.delegate = self;
    } else if ([model.functionType isEqualToString:VWAS_model]) {
        
        //VWAS模式传名称
        [self.session.socket sendStartVWASModelMessage:model.iconMenuName];
        
    } else if ([model.functionType isEqualToString:light_model]) {
        
        //光学模式传编号
        [self.session.socket sendStartlightModelMessage:model.index];
        
    } else if ([model.functionType isEqualToString:desktop_settings]) {
        //设置桌面传编号
        [self.session.socket sendSettingDesktopMessage:model.index];
    }
}

- (void)longPressAction:(UILongPressGestureRecognizer *)gesture
{
    CGPoint point = [gesture locationInView:self.functionCollectionView];

    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            if (!indexPath) {
                break;
            }
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];
            self.center = cell.center;
            self.startPoint = point;
            point = cell.center;
            [self.functionCollectionView beginInteractiveMovementForItemAtIndexPath:indexPath];
            self.selectedCell = cell;
            self.selectedModel = [self.dataArray objectAtIndex:indexPath.row];
        }
            break;

        case UIGestureRecognizerStateChanged:
        {
            point = CGPointMake(self.center.x + point.x - self.startPoint.x, self.center.y + point.y - self.startPoint.y);
            //先把坐标换算到同一坐标系中，nil默认为window，下面集中方法等效
            //[self.blurContainerView.superview convertRect:self.blurContainerView.frame toView:nil];
            //[Window convertRect:self.blurContainerView.frame fromView:self.blurContainerView.superview];
            //[Window convertRect:self.blurContainerView.bounds fromView:self.blurContainerView];
            CGRect containerViewRect = [self.functionCollectionView convertRect:self.functionCollectionView.bounds toView:nil];
            CGRect selectedCellRect = [self.selectedCell convertRect:self.selectedCell.bounds toView:nil];
            if (CGRectIntersectsRect(containerViewRect, selectedCellRect)) {
                [self.functionCollectionView updateInteractiveMovementTargetPosition:point];
            } else {
                if ([self.dataArray containsObject:self.selectedModel]) {
                    NSLog(@"已经移除视图！");
                    [self.dataArray removeObject:self.selectedModel];
                    [self dismissSelf];
                }
            }
        }
            break;
        case UIGestureRecognizerStateEnded:
            [self.functionCollectionView endInteractiveMovement];
            break;
        default:
            [self.functionCollectionView cancelInteractiveMovement];
            break;
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([gestureRecognizer isKindOfClass:[UITapGestureRecognizer class]]) {
        if ([touch.view isKindOfClass:[UICollectionView class]] || (touch.view.frame.size.width == 70)) {
            return NO;
        }
    }
    return YES;
}

- (void)presentationView:(PresentationView *)view didTapConfirmButton:(UIButton *)sender
{
    [self.session.socket sendStartOrShutDownMessage:1];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    Icon *model = sender;
    UIViewController *controller = segue.destinationViewController;
    if ([controller isKindOfClass:[DetailViewController class]]) {
        ((DetailViewController *)controller).model = model;
    } 
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)backgroundViewTapGesture:(UITapGestureRecognizer *)sender {
    if (self.nameTextField.text.length != 0 && (![self.titleName isEqualToString:self.nameTextField.text])) {
        NSArray *keys = [self.dataDictionary allKeys];
        NSArray *models = [self.dataDictionary valueForKey:[keys firstObject]];
        for (Icon *icon in models) {
            icon.fileName = self.nameTextField.text;
        }
        [self.dataDictionary removeAllObjects];
        [self.dataDictionary setValue:models forKey:self.nameTextField.text];

        //更新缓存的文件夹名
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
        NSString *savedFileName = isReleaseVersion ? @"release_filename":@"stub_filename";
        NSString *fileName = [userDefaults valueForKey:savedFileName];
        NSMutableArray *fileNames = [[fileName componentsSeparatedByString:@"-"] mutableCopy];
        [fileNames removeObject:self.titleName];
        if ([fileNames containsObject:self.nameTextField.text]) {
            NSString *message = NSLocalizedString(@"files_name_error", nil);
            [self.view makeToast:message];
            return;
        } else {
            [fileNames addObject:self.nameTextField.text];
            [userDefaults setValue:[fileNames componentsJoinedByString:@"-"] forKey:savedFileName];
        }
    }
    self.selectedModel = nil;
    [self dismissSelf];
}

- (IBAction)clearNameTextFieldAction:(UIButton *)sender {
    self.nameTextField.text = @"";
}

- (void)dismissSelf
{
    [UIView animateWithDuration:0.3 animations:^{
        self.view.alpha = 0.0;
    } completion:^(BOOL finished) {
        if (self.cellRemovedBlock) {
            self.cellRemovedBlock(self.selectedModel, self.dataDictionary);
        }
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}

@end
