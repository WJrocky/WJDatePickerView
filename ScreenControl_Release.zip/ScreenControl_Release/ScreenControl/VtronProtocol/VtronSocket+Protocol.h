//
//  VtronSocket+Protocol.h
//  ScreenControl
//
//  Created by wangjian on 25/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "VtronSocket.h"

#pragma pack(push, 1)

typedef struct {
    uint32_t sectionID;
    uint16_t orderID;
    uint32_t datalength;
} Data_Header;

#pragma pack(pop)

typedef NS_ENUM(NSInteger, OrderID){
    OrderID_Login                     = 0x1001,
    OrderID_VWAS                      = 0x1003,
    OrderID_ObtainSystemConfiguration = 0x1005,
    OrderID_Unit                      = 0x1007,
    OrderID_StartOrShutDown           = 0x1009,
    OrderID_Wall                      = 0x100b
};

@interface VtronSocket (Protocol)

- (void)sendLoginMessage:(NSString *)message;
- (void)sendChooseShowWallMessage:(NSData *)message;
- (void)sendOpenAllWatchWallMachineMessage;
- (void)sendCloseAllWatchWallMachineMessage;
- (void)sendObtainVWASModelListMessage;
- (void)sendStartVWASModelMessage:(NSData *)message;
- (void)sendObtainVWASWallNameMessage;
- (void)sendObtainSystemConfigurationMessage;
- (void)sendObtainLightModelMessage:(NSUInteger)index;
- (void)sendTurnPPTLastPageMessage;
- (void)sendTurnPPTNextPageMessage;
- (void)sendStartOrShutDownMessage:(NSUInteger)type;
- (void)sendSettingDesktopMessage:(NSUInteger)number;
- (void)sendStartlightModelMessage:(NSUInteger)index;

@end
