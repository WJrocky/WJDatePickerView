//
//  VtronSocket.h
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@class VtronSocket;
@protocol VtronSocketDelegate <NSObject>

@optional
- (void)VtronSocket:(VtronSocket *)socket didChangeStatus:(NSStreamEvent)streamStatus;
- (void)VtronSocket:(VtronSocket *)socket didSendData:(NSData *)data;

@end

@interface VtronSocket : NSObject

@property (nonatomic, assign) id<VtronSocketDelegate> delegate;

- (void)tcpConnectToHost:(NSString *)host port:(UInt32)port;
- (void)udpConnection:(NSString *)hostText port:(int)port;
- (NSData *)readData;
- (NSInteger)writeData:(NSData *)data;
- (void)close;

@end
