//
//  FoldItemsCell.h
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FoldItemsCell;
@protocol FoldItemsCellDelegate <NSObject>

- (void)foldItemsCell:(FoldItemsCell *)cell didTapedAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface FoldItemsCell : UICollectionViewCell

@property (nonatomic, assign) id<FoldItemsCellDelegate> delegate;
- (void)loadData:(NSMutableDictionary *)iconDictionary
       indexPath:(NSIndexPath *)indexPath;

@end
