//
//  ChangeIPCell.m
//  ScreenControl
//
//  Created by 王健 on 2017/10/10.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "RuntimeData.h"
#import "ChangeIPCell.h"
#import "UIView+Toast.h"

@interface ChangeIPCell ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *IPTextField;

@end

@implementation ChangeIPCell

- (void)loadData:(NSString *)data
{
    self.IPTextField.text = data;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)changeIPButtonAction:(UIButton *)sender {
    if ([self.delegate respondsToSelector:@selector(ChangeIPCellDidTapAction)]) {
        if ([[RuntimeData sharedInstance] isValidatIP:self.IPTextField.text]) {
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setValue:self.IPTextField.text forKey:@"pptHost"];
//            [RuntimeData sharedInstance].pptHost = self.IPTextField.text;
            [self.delegate ChangeIPCellDidTapAction];
        } else {
            NSString *message = NSLocalizedString(@"ip_error", nil);
            [[UIApplication sharedApplication].delegate.window makeToast:message];
        }
    }
}

@end
