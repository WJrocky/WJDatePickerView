//
//  AboutViewController.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "AboutViewController.h"
#import "UIButton+EnlargeEdge.h"

@interface AboutViewController ()

@property (weak, nonatomic) IBOutlet UIView *phoneContainerView;
@property (weak, nonatomic) IBOutlet UIView *emailContainerView;

@end

@implementation AboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.phoneContainerView.layer.borderColor = [UIColor whiteColor].CGColor;
    self.emailContainerView.layer.borderColor = [UIColor whiteColor].CGColor;

    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);
    [myButton setEnlargeEdge:4];
    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
