//
//  HomeViewController.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"
#import "AppDelegate.h"
#import "RuntimeData.h"
#import "VtronSession.h"
#import "HomeItemCell.h"
#import "MBProgressHUD.h"
#import "FoldItemsCell.h"
#import "MagicalRecord.h"
#import "PresentationView.h"
#import "PopViewController.h"
#import "Icon+CoreDataClass.h"
#import "HomeViewController.h"
#import "MoreViewController.h"
#import "VtronSocket+Protocol.h"
#import "DetailViewController.h"
#import "UIView+Toast.h"

@interface HomeViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, VtronSessionDelegate, PresentationViewDelegate, FoldItemsCellDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *rightBarButtonItem;

@property (nonatomic, assign) BOOL isPop;
@property (nonatomic, assign) CGPoint center;
@property (nonatomic, assign) CGPoint startPoint;
@property (nonatomic, weak) HomeItemCell *selectedCell;
@property (nonatomic, strong) NSMutableArray *iconDataArray;
@property (nonatomic, assign) BOOL isContain;
@property (nonatomic, strong) NSUserDefaults *userDefaults;
@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, assign) BOOL canExchange;
@property (nonatomic, assign) BOOL isServiceBack;
@property (nonatomic, strong) NSTimer *overTimer;

@end

@implementation HomeViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    self.session.delegate = self;

    NSData *systemCodeData = [RuntimeData sharedInstance].selectedSystemData;
    NSString *title = nil;
    NSString *name = NSLocalizedString(@"system", nil);
    if (systemCodeData.length >= 12) {
        NSData *systemCodeLengthData = [systemCodeData subdataWithRange:NSMakeRange(0, 4)];
        NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];

        NSData *lineData = [systemCodeData subdataWithRange:NSMakeRange(4, 4)];
        NSUInteger line = [lineData valueOfBigUint32_t];

        NSData *rowData = [systemCodeData subdataWithRange:NSMakeRange(8, 4)];
        NSUInteger row = [rowData valueOfBigUint32_t];

        title = [NSString stringWithFormat:@"%@%ld:%ld*%ld", name, systemCodeLength, line, row];
    } else {
        title = [NSString stringWithFormat:@"%@1:1*4", name];
    }

    self.title = title;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.isContain = NO;
    self.canExchange = YES;

    NSDictionary *attributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:14.0],NSForegroundColorAttributeName:[UIColor whiteColor]};

    [self.rightBarButtonItem setTitleTextAttributes:attributes forState:UIControlStateNormal];

    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
    [self.functionCollectionView addGestureRecognizer:longPressGesture];

    self.userDefaults = [NSUserDefaults standardUserDefaults];

    [self initDataSourece];

    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(initDataSourece)
                                                 name:@"updateDataSource"
                                               object:nil];
}

- (void)initDataSourece
{
    NSData *systemCodeLengthData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
    NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
    NSString *systemCode = [NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength];
    
    NSString *light_model = NSLocalizedString(@"light model", nil);
    
    NSString *version = NSLocalizedString(@"version", nil);
    NSPredicate *predicate = nil;
    
    predicate = [NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(version == '%@') AND (isFrequentlyUsed == YES)", version]];
    self.iconDataArray = [NSMutableArray array];

    NSMutableArray *frequentlyUsedFunctions = [[Icon MR_findAllWithPredicate:predicate] mutableCopy];
    
    NSMutableArray *needRemveArray = [NSMutableArray array];
    for (Icon *icon in frequentlyUsedFunctions) {
        NSString *type = icon.functionType;
        if ([type isEqualToString:light_model] && ![icon.systemCode isEqualToString:systemCode]) {
            [needRemveArray addObject:icon];
        }
    }
    [frequentlyUsedFunctions removeObjectsInArray:needRemveArray];
    
    [self.iconDataArray addObjectsFromArray:frequentlyUsedFunctions];
    
    [self.iconDataArray sortUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"serialnumber" ascending:YES]]];
    
    //搜索的时候需要加上系统号，存储的格式如下1-文件夹名
    NSString *fileName = [self.userDefaults valueForKey:systemCode];
    NSArray *fileNames = [fileName componentsSeparatedByString:@"-"];
    
    for (NSString *name in fileNames) {
        if ([name isEqualToString:systemCode]) {
            continue;
        }
        
        NSPredicate *filesPredicate = nil;
        
        filesPredicate = [NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(fileName == '%@') AND (systemCode == '%@')", fileName, systemCode]];
        NSMutableArray *files = [[Icon MR_findAllWithPredicate:filesPredicate] mutableCopy];
        
        if (files.count != 0) {
            NSMutableDictionary *dictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:files, name, nil];
            [self.iconDataArray removeObjectsInArray:files];
            Icon *model = [files firstObject];
            if (0 == self.iconDataArray.count) {
                [self.iconDataArray addObject:dictionary];
            } else {
                if (self.iconDataArray.count > model.serialnumber) {
                    [self.iconDataArray insertObject:dictionary atIndex:model.serialnumber];
                } else {
                    [self.iconDataArray addObject:dictionary];
                }
            }
        }
    }

    NSString *more = NSLocalizedString(@"more_function", nil);
    Icon *moreIcon = [[Icon MR_findByAttribute:@"functionType" withValue:more] firstObject];

    [self.iconDataArray addObject:moreIcon];
    
    [self.functionCollectionView reloadData];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    //追加一个常用功能
    return self.iconDataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    id model = [self.iconDataArray objectAtIndex:indexPath.item];
    if ([model isKindOfClass:[Icon class]]) {
        HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
        [cell loadData:model];
        return cell;
    } else  {
        FoldItemsCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"FoldItemsCell" forIndexPath:indexPath];
        cell.delegate = self;
        [cell loadData:model indexPath:indexPath];
        return cell;
    }
}

- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{

}

#pragma mark - UICollectionViewDelegateFlowLayout
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *desktop_settings = NSLocalizedString(@"desktop settings", nil);
    NSString *light_model = NSLocalizedString(@"light model", nil);
    NSString *VWAS_model = NSLocalizedString(@"VWAS model", nil);

    NSString *turn_on = NSLocalizedString(@"turn_on", nil);
    NSString *turn_off = NSLocalizedString(@"turn_off", nil);
    id model = [self.iconDataArray objectAtIndex:indexPath.item];
    if ([model isKindOfClass:[Icon class]]) {
        if (((Icon *)model).segueIdentifier.length != 0) {
            [self performSegueWithIdentifier:((Icon *)model).segueIdentifier sender:model];
        } else if ([((Icon *)model).iconMenuName isEqualToData:[NSData dataFromHexString:turn_on]]) {

            //如果没有查询到系统号，则用vwas模式开关机
            if ([RuntimeData sharedInstance].systemDataList.count > 0) {
                //开机
                [self.session.socket sendStartOrShutDownMessage:0];
            } else {
                //    [self.session.socket sendCloseAllWatchWallMachineMessage];
                [self.session.socket sendOpenAllWatchWallMachineMessage];
            }

        } else if ([((Icon *)model).iconMenuName isEqualToData:[NSData dataFromHexString:turn_off]]) {

            //关机
            PresentationView *view = [PresentationView popAlertView];
            view.delegate = self;
        } else if ([((Icon *)model).functionType isEqualToString:VWAS_model]) {
            
            //VWAS模式传名称
            [self.session.socket sendStartVWASModelMessage:((Icon *)model).iconMenuName];
            
        } else if ([((Icon *)model).functionType isEqualToString:light_model]) {
            
            //光学模式传编号
            [self.session.socket sendStartlightModelMessage:((Icon *)model).index];
            
        } else if ([((Icon *)model).functionType isEqualToString:desktop_settings]) {
            //设置桌面传编号
            [self.session.socket sendSettingDesktopMessage:((Icon *)model).index];
        }
    } else {
        PopViewController *popViewController = [self addPopViewController:indexPath];

        [popViewController loadData:model];
    }
}

- (void)foldItemsCell:(FoldItemsCell *)cell didTapedAtIndexPath:(NSIndexPath *)indexPath
{
    PopViewController *popViewController = [self addPopViewController:indexPath];
    id model = [self.iconDataArray objectAtIndex:indexPath.item];
    [popViewController loadData:model];
}

- (PopViewController *)addPopViewController:(NSIndexPath *)indexPath
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                         bundle:nil];
    PopViewController *popViewController = [storyboard instantiateViewControllerWithIdentifier:@"PopViewController"];

    [popViewController view];

    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];

    [keyWindow addSubview:popViewController.view];
    [self addChildViewController:popViewController];

    [popViewController setCellRemovedBlock:^(Icon *removedModel, NSMutableDictionary *dictionary) {
        self.isPop = NO;
        self.isContain = NO;

        NSArray *keys = [dictionary allKeys];

        if (removedModel) {
            NSArray *models = [dictionary valueForKey:[keys firstObject]];
            if (0 == models.count) {
                BOOL isReleaseVersion = [self.userDefaults boolForKey:@"isReleaseVersion"];
                NSString *savedFileName = isReleaseVersion ? @"release_filename":@"stub_filename";
                [self.userDefaults removeObjectForKey:savedFileName];
                [self.iconDataArray removeObjectAtIndex:indexPath.row];
            }

            removedModel.fileName = nil;
            
            [self.iconDataArray insertObject:removedModel atIndex:self.iconDataArray.count - 1];
        }

        [UIView performWithoutAnimation:^{
            [self.functionCollectionView reloadData];
        }];

//        self.session.delegate = self;
    }];

    popViewController.view.alpha = 0.0;

    [UIView animateWithDuration:0.3 animations:^{
        popViewController.view.alpha = 1.0;
    }];

    return popViewController;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    Icon *model = sender;
    UIViewController *controller = segue.destinationViewController;
    if ([controller isKindOfClass:[DetailViewController class]]) {
        ((DetailViewController *)controller).model = model;
    } else if ([controller isKindOfClass:[MoreViewController class]]) {
        [((MoreViewController *)controller) setFunctionChangeSuccess:^{
            //更新数据源
            [self initDataSourece];
            [self.functionCollectionView reloadData];
        }];
    }
}

- (void)longPressAction:(UILongPressGestureRecognizer *)gesture
{
    CGPoint point = [gesture locationInView:self.functionCollectionView];

    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            id model = [self.iconDataArray objectAtIndex:indexPath.row];
            if (!indexPath || (indexPath.row == self.iconDataArray.count - 1) || ![model isKindOfClass:[Icon class]]) {
                break;
            }
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];
            //创建动画
            CAKeyframeAnimation * keyAnimaion = [CAKeyframeAnimation animation];
            keyAnimaion.keyPath = @"transform.rotation";
            keyAnimaion.values = @[@(-10 / 180.0 * M_PI),@(10 /180.0 * M_PI),@(-10/ 180.0 * M_PI)];//度数转弧度
            
            keyAnimaion.removedOnCompletion = NO;
            keyAnimaion.fillMode = kCAFillModeForwards;
            keyAnimaion.duration = 0.2;
            keyAnimaion.repeatCount = MAXFLOAT;
            [cell.layer addAnimation:keyAnimaion forKey:@"rotation"];
 
            self.center = cell.center;
            self.startPoint = point;
            point = cell.center;
            [self.functionCollectionView beginInteractiveMovementForItemAtIndexPath:indexPath];
            //需要在数据交换的时候交换选中的cell
            self.selectedCell = cell;
        }
            break;

        case UIGestureRecognizerStateChanged:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];
            point = CGPointMake(self.center.x + point.x - self.startPoint.x, self.center.y + point.y - self.startPoint.y);
            CGRect rect = CGRectMake(cell.center.x - 8, cell.center.y - 8, 16, 16);
            if (CGRectContainsPoint(rect, point) && (self.selectedCell != cell)) {
                //弹出遮幕
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (CGRectContainsPoint(rect, point)) {
                        if (!self.isPop && self.isContain && indexPath != [self.functionCollectionView indexPathForCell:self.selectedCell]) {
                            self.isPop = YES;
                            self.canExchange = NO;
                            PopViewController *popViewController = [self addPopViewController:indexPath];

                            NSIndexPath *selectedIndexPath = [self.functionCollectionView indexPathForCell:self.selectedCell];

                            id model = [self.iconDataArray objectAtIndex:indexPath.row];
                            if ([model isKindOfClass:[Icon class]]) {

                                NSMutableDictionary *multipleModel = [NSMutableDictionary dictionary];

                                NSMutableArray *models = [NSMutableArray array];
                                Icon *selectedModel = [self.iconDataArray objectAtIndex:selectedIndexPath.row];
                                Icon *model = [self.iconDataArray objectAtIndex:indexPath.row];
                                if (0 == model.fileName.length) {
                                    NSString *name = [model.iconMenuName convertDataToStr];
                                    model.fileName = name;
                                }
                                selectedModel.fileName = model.fileName;
                                model.serialnumber = indexPath.row;
                                selectedModel.serialnumber = indexPath.row;

                                [models addObject:selectedModel];
                                [models addObject:[self.iconDataArray objectAtIndex:indexPath.row]];

                                [multipleModel setValue:models forKey:model.fileName];
                                
                                NSData *systemCodeLengthData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
                                NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
                                NSString *savedFileName = [NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength];
                                NSString *fileName = [self.userDefaults valueForKey:savedFileName];

                                //userDefault里面存储的是系统号-文件夹名
                                if (fileName.length != 0) {
                                    fileName = [NSString stringWithFormat:@"%@-%@",fileName,model.fileName];
                                } else {
                                    fileName = model.fileName;
                                }
                                [self.userDefaults setValue:fileName forKey:savedFileName];

                                [popViewController loadData:multipleModel];

                                [self.iconDataArray replaceObjectAtIndex:indexPath.row withObject:multipleModel];

                                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                            } else {
                                NSArray *keys = [model allKeys];
                                NSString *fileName = [keys firstObject];
                                NSMutableArray *models = [model valueForKey:fileName];

                                Icon *selectedModel = [self.iconDataArray objectAtIndex:selectedIndexPath.row];

                                selectedModel.fileName = fileName;
                                selectedModel.serialnumber = indexPath.row;

                                [models addObject:selectedModel];

                                [popViewController loadData:model];

                                [self.iconDataArray replaceObjectAtIndex:indexPath.row withObject:model];

                                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                            }

                            [self.iconDataArray removeObjectAtIndex:selectedIndexPath.row];
                            [self.functionCollectionView deleteItemsAtIndexPaths:@[selectedIndexPath]];

                            [self.functionCollectionView reloadItemsAtIndexPaths:@[indexPath]];

                            [self.functionCollectionView endInteractiveMovement];
                        }
                    }
                });
            }
            [self.functionCollectionView updateInteractiveMovementTargetPosition:point];
        }
            break;
        case UIGestureRecognizerStateEnded:
            [self.selectedCell.layer removeAnimationForKey:@"rotation"];
            point = CGPointZero;
            [self.functionCollectionView endInteractiveMovement];
            break;
        default:
            [self.selectedCell.layer removeAnimationForKey:@"rotation"];
            point = CGPointZero;
            [self.functionCollectionView cancelInteractiveMovement];
            break;
    }
}

- (NSIndexPath *)collectionView:(UICollectionView *)collectionView targetIndexPathForMoveFromItemAtIndexPath:(NSIndexPath *)originalIndexPath toProposedIndexPath:(NSIndexPath *)proposedIndexPath
{
    UICollectionViewCell *originalCell = [collectionView cellForItemAtIndexPath:originalIndexPath];
    UICollectionViewCell *proposedCell = [collectionView cellForItemAtIndexPath:proposedIndexPath];

    if (originalIndexPath != proposedIndexPath) {
        CGRect rect = CGRectMake(proposedCell.center.x - 6, proposedCell.center.y - 6, 12, 12);
        if (CGRectContainsPoint(rect, originalCell.center)) {
            self.isContain = YES;
        }

        if (self.isContain && !CGRectContainsPoint(rect, originalCell.center)) {
            self.isContain = NO;
            if (proposedIndexPath.item == self.iconDataArray.count -1) {
                return originalIndexPath;
            }

//            if (self.canExchange) {
                if (originalIndexPath.row < self.iconDataArray.count - 1 && proposedIndexPath.row < self.iconDataArray.count - 1) {
                    id sourceModel = [self.iconDataArray objectAtIndex:originalIndexPath.row];
                    id destinationModel = [self.iconDataArray objectAtIndex:proposedIndexPath.row];
                    NSInteger sourceRow = originalIndexPath.row;
                    NSInteger destinationRow = proposedIndexPath.row;
                    if ([sourceModel isKindOfClass:[Icon class]]) {
        
                        if ([destinationModel isKindOfClass:[NSDictionary class]]) {
                            NSArray *destinationkeys = [destinationModel allKeys];
                            NSArray *destinationicons = [destinationModel objectForKey:[destinationkeys firstObject]];
                            for (Icon *icon in destinationicons) {
                                icon.serialnumber = sourceRow;
                            }
                        } else {
                            ((Icon *)destinationModel).serialnumber = sourceRow;
                        }
                        ((Icon *)sourceModel).serialnumber = destinationRow;
                    } else {
                        NSArray *sourcekeys = [sourceModel allKeys];
                        NSArray *sourceIcons = [sourceModel objectForKey:[sourcekeys firstObject]];
        
                        if ([destinationModel isKindOfClass:[NSDictionary class]]) {
                            NSArray *destinationKeys = [destinationModel allKeys];
                            NSArray *destinationIcons = [destinationModel objectForKey:[destinationKeys firstObject]];
                            for (Icon *icon in destinationIcons) {
                                icon.serialnumber = sourceRow;
                            }
                        } else {
                            ((Icon *)destinationModel).serialnumber = sourceRow;
                        }
        
                        for (Icon *icon in sourceIcons) {
                            icon.serialnumber = destinationRow;
                        }
                    }
        
                    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                    [self.iconDataArray exchangeObjectAtIndex:originalIndexPath.item withObjectAtIndex:proposedIndexPath.item];
//                    self.selectedCell = (HomeItemCell)[collectionView cellForItemAtIndexPath:proposedIndexPath];
                }
//            }
//            self.canExchange = YES;

            //可以移动
            return proposedIndexPath;
        }
    }
    //不可以移动
    return  originalIndexPath;
}

- (IBAction)moreBarButtonItemAction:(UIBarButtonItem *)sender {
    [self performSegueWithIdentifier:@"ShowMoreViewController" sender:nil];
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidReceivedData:(NSData *)data
{
    [_overTimer invalidate];
    _overTimer = nil;
    self.isServiceBack = YES;
    [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];

    if (data.length > 6) {
        NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
        if ([orderData isEqualToData:[NSData dataFromHexString:@"0510"]]) {
            NSData *messageData = [data subdataWithRange:NSMakeRange(10, data.length - 10)];
            NSData *systemCountData = [messageData subdataWithRange:NSMakeRange(2, 4)];
            NSData *systemListData = [messageData subdataWithRange:NSMakeRange(6, messageData.length - 6)];
            NSUInteger systemCount = [systemCountData valueOfBigUint32_t];
            NSUInteger index = 0;
            NSMutableArray *tempArray = [NSMutableArray array];
            for (int i = 0; i < systemCount; i++) {
                NSData *systemInformationData = [systemListData subdataWithRange:NSMakeRange(index, 12)];
                [tempArray addObject:systemInformationData];
                NSData *systemCodeData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
                NSLog(@"systemCode = %d", [systemCodeData valueOfBigUint32_t]);
                index += 4;
                NSData *lineData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
                NSLog(@"line = %d", [lineData valueOfBigUint32_t]);
                index += 4;
                NSData *rowData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
                NSLog(@"row = %d", [rowData valueOfBigUint32_t]);
                index += 4;
            }
            [RuntimeData sharedInstance].systemDataList = [tempArray copy];
            [RuntimeData sharedInstance].selectedSystemData = [tempArray firstObject];
        }
    } else {
        if (!self.session.isConnected) {
            NSString *message = NSLocalizedString(@"connection_failed", nil);
            [self.view makeToast:message];

            [self.session.socket close];
            self.session.isConnected = NO;
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle:nil];
            LoginViewController *loginViewController = [storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
            loginViewController.isReadForWrite = NO;
            [self.navigationController setViewControllers:@[loginViewController]];

        } else {
            NSString *message = NSLocalizedString(@"operation_failed", nil);
            [self.view makeToast:message];
        }
    }
}

- (void)sessionDidSendData:(NSData *)data
{
    self.isServiceBack = NO;
//    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self windowOfApplication] animated:YES];
    NSString *message = NSLocalizedString(@"action", nil);
    hud.labelText = message;

    self.overTimer = [NSTimer scheduledTimerWithTimeInterval:60
                                                      target:self
                                                    selector:@selector(overTimerAction)
                                                    userInfo:nil
                                                     repeats:NO];
}

- (void)overTimerAction
{
    if (!self.isServiceBack) {
        [self sessionDidReceivedData:nil];
    }
}

- (IBAction)quitAction:(UIBarButtonItem *)sender {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self windowOfApplication] animated:YES];

    NSString *message = NSLocalizedString(@"quit", nil);
    hud.labelText = message;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

        [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
        [self.session.socket close];
        self.session.isConnected = NO;
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle:nil];
        LoginViewController *loginViewController = [storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
        loginViewController.isReadForWrite = NO;
        [self.navigationController setViewControllers:@[loginViewController]];
    });
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ClearData" object:nil];
}

- (void)presentationView:(PresentationView *)view didTapConfirmButton:(UIButton *)sender
{
    //如果没有查询到系统号，则用vwas模式开关机
    if ([RuntimeData sharedInstance].systemDataList.count > 0) {
        //关机
        [self.session.socket sendStartOrShutDownMessage:1];
    } else {
        [self.session.socket sendCloseAllWatchWallMachineMessage];
    }
}

@end
