//
//  BaseViewController.m
//  ScreenControl
//
//  Created by wangjian on 28/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (UIWindow *)windowOfApplication
{
    return [UIApplication sharedApplication].delegate.window;
}

@end
