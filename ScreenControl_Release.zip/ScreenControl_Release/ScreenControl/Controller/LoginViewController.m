//
//  LoginViewController.m
//  ScreenControl
//
//  Created by wangjian on 07/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"
#import "MagicalRecord.h"
#import "Icon+CoreDataClass.h"
#import "UIView+Toast.h"
#import "RuntimeData.h"
#import "VtronSocket.h"
#import "VtronSession.h"
#import "MBProgressHUD.h"
#import "HomeViewController.h"
#import "LoginViewController.h"
#import "VtronSocket+Protocol.h"
#import "HWPreviewViewController.h"
#import <QuickLook/QuickLook.h>
#import "AsyncUdpSocket.h"
#import "UIButton+EnlargeEdge.h"

@interface LoginViewController ()<UITextFieldDelegate, VtronSessionDelegate,
                                  QLPreviewControllerDelegate, QLPreviewControllerDataSource,
                                  AsyncUdpSocketDelegate>

@property (weak, nonatomic) IBOutlet UITextField *accountTextField;
@property (weak, nonatomic) IBOutlet UITextField *mobileTextField;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIButton *savePasswordButton;
@property (weak, nonatomic) IBOutlet UIButton *isStubButton;
@property (weak, nonatomic) IBOutlet UILabel *versionLabel;

@property (nonatomic, strong) NSUserDefaults *userDefaults;
@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) NSMutableArray *lightModelList;
@property (nonatomic, strong) UIDocumentInteractionController *documentController;
@property (nonatomic, strong) NSString *filePath;
@property (nonatomic, strong) NSArray *savedArray;
@property (nonatomic, assign) BOOL isServiceBack;
@property (nonatomic, assign) BOOL isShowHud;
@property (nonatomic, assign) BOOL connectFail;
@property (nonatomic, strong) NSTimer *overTimer;
@property (nonatomic, strong) NSTimer *lightModeTimer;

@end

@implementation LoginViewController

- (void)customizeAppearance
{
    NSDictionary *colorAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};

    NSAttributedString *accountPlaceholder = [[NSAttributedString alloc] initWithString:self.accountTextField.placeholder attributes:colorAttributes];
    self.accountTextField.attributedPlaceholder = accountPlaceholder;

    NSAttributedString *mobilePlaceholder = [[NSAttributedString alloc] initWithString:self.mobileTextField.placeholder attributes:colorAttributes];
    self.mobileTextField.attributedPlaceholder = mobilePlaceholder;

    self.userDefaults = [NSUserDefaults standardUserDefaults];

    BOOL isSavedPassword = [self.userDefaults boolForKey:@"isSavedPassword"];
    NSString *username = [self.userDefaults valueForKey:@"username"];
    NSString *password = [self.userDefaults valueForKey:@"password"];
    if (11 == password.length) {
        self.loginButton.backgroundColor = [UIColor colorWithRed:190.0 / 255.0
                                                           green:58.0 / 255.0
                                                            blue:58.0 / 255.0
                                                           alpha:1.0];
    }

    [self.savePasswordButton setSelected:isSavedPassword];
    self.accountTextField.text = username;
    self.mobileTextField.text = password;

    BOOL isReleaseVersion = [self.userDefaults boolForKey:@"isReleaseVersion"];
    [self.versionLabel setHidden:isReleaseVersion];
    
    self.lightModelList = [NSMutableArray array];
}

- (void)viewWillAppear:(BOOL)animated
{
    NSString *light_model = NSLocalizedString(@"light model", nil);
    
    NSData *systemCodeLengthData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
    NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
    NSString *systemCode = [NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(functionType == '%@') AND (isStub == NO) AND (systemCode == '%@')", light_model, systemCode]];
    self.savedArray = [Icon MR_findAllWithPredicate:predicate];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self customizeAppearance];

    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;

    [self.savePasswordButton setEnlargeEdge:10];
    [self.isStubButton setEnlargeEdge:10];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ClearData) name:@"ClearData" object:nil];
}

- (void)ClearData
{
    [self.lightModelList removeAllObjects];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@""]) {
        if (textField.text.length == 11) {
            self.loginButton.backgroundColor = [UIColor colorWithRed:216.0 / 255.0
                                                               green:186.0 / 255.0
                                                                blue:186.0 / 255.0
                                                               alpha:1.0];
        }
    } else {
        if (10 == textField.text.length) {
            //改变button颜色
            self.loginButton.backgroundColor = [UIColor colorWithRed:190.0 / 255.0
                                                               green:58.0 / 255.0
                                                                blue:58.0 / 255.0
                                                               alpha:1.0];
        } else if (textField.text.length > 10) {
            if (string.length != 0) {
                //这里可以做一个toast
                NSString *message = NSLocalizedString(@"number_fail", nil);
                [self.view makeToast:message];
                return NO;
            } else {
                return YES;
            }
        }
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)savePasswordButtonAction:(UIButton *)sender {
    sender.selected = !sender.selected;
    [self.userDefaults setBool:sender.selected forKey:@"isSavedPassword"];
}

- (IBAction)loginButtonAction:(UIButton *)sender {

    [self.view endEditing:YES];
    
    [self.lightModelList removeAllObjects];
    
    [self.userDefaults setValue:self.accountTextField.text forKey:@"username"];

    BOOL isSavedPassword = [self.userDefaults boolForKey:@"isSavedPassword"];

    if (isSavedPassword) {
        [self.userDefaults setValue:self.mobileTextField.text forKey:@"password"];
    } else {
        [self.userDefaults setValue:@"" forKey:@"password"];
    }
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
    if (!isReleaseVersion) {
        if ([self.mobileTextField.text isEqualToString:@"83903249123"]) {

            MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self windowOfApplication] animated:YES];
            self.isShowHud = YES;
            NSString *message = NSLocalizedString(@"login", nil);
            hud.labelText = message;

            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.isShowHud = NO;

                [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
                [self showHomeViewController];
            });
        } else {
            return;
        }
    }

    if (self.session.isConnected) {
        [self.session.socket sendLoginMessage:self.mobileTextField.text];
    } else {
        if (0 == [RuntimeData sharedInstance].host.length) {
            //创建socket(UDP)
            AsyncUdpSocket *broadSocket = [[AsyncUdpSocket alloc] initWithDelegate:self];

            //允许广播形式
            [broadSocket enableBroadcast:YES error:nil];

            //监听的端口(绑定端口)和发送到的目的端口要一致。
            //要进行广播数据，可以绑定ip地址和端口或者只绑定端口
            [broadSocket bindToAddress:[[RuntimeData sharedInstance] getIPAddress:YES] port:12000 error:nil];

            char body[10] = {0x01,0x00,0x01,0x00,0x00,0x10,0x00,0x00,0x00,0x00};

            NSData *data = [NSData dataWithBytes:body length:10];

            //启动接收线程
            [broadSocket receiveWithTimeout:2 tag:0];

            [broadSocket sendData:data toHost:@"255.255.255.255" port:12000 withTimeout:-1 tag:0];

            MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self windowOfApplication] animated:YES];
            self.isShowHud = YES;
            NSString *message = NSLocalizedString(@"broadcast", nil);
            hud.labelText = message;

        } else {
            [self.session.socket tcpConnectToHost:[RuntimeData sharedInstance].host port:12001];
        }
    }
}

- (IBAction)changePasswordStateAction:(UIButton *)sender {
    self.mobileTextField.secureTextEntry = !self.mobileTextField.secureTextEntry;
    sender.selected = !sender.selected;
}

- (IBAction)changeVersionAction:(UIButton *)sender {
    sender.selected = !sender.selected;
    [self.userDefaults setBool:sender.selected forKey:@"isReleaseVersion"];
}

#pragma mark - AsyncUdpSocketDelegate
//已接收消息
- (BOOL)onUdpSocket:(AsyncUdpSocket *)sock
     didReceiveData:(NSData *)data
            withTag:(long)tag
           fromHost:(NSString *)host
               port:(UInt16)port
{
    [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
    self.isShowHud = NO;

    if (data.length > 6) {
        NSData *orderID = [data subdataWithRange:NSMakeRange(4, 2)];
        if ([orderID isEqualToData:[NSData dataFromHexString:@"0110"]]) {
            //这里做一下验证，确定命令ID是0110
            [RuntimeData sharedInstance].host = host;
//            [RuntimeData sharedInstance].pptHost = host;
            [self.session.socket tcpConnectToHost:host port:12001];
        }
    }
    [sock close];
    return YES;
}

- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotReceiveDataWithTag:(long)tag dueToError:(NSError *)error
{
    [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
    self.isShowHud = NO;
    [sock close];
    NSString *message = NSLocalizedString(@"ip_fail", nil);
    [self.view makeToast:message];
}

- (void)onUdpSocketDidClose:(AsyncUdpSocket *)sock
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
    if (!isReleaseVersion) {
        [self showHomeViewController];
    }
}

#pragma mark - VtronSessionDelegate

- (void)sessionConnectFailure
{
    if (!self.connectFail) {
        self.connectFail = YES;
        NSString *message = NSLocalizedString(@"net_waring", nil);
        [self.view makeToast:message];
    }
}

- (void)sessionPreparedForWrite
{
    if (!self.isReadForWrite) {
        self.isReadForWrite = YES;
        [self.session.socket sendLoginMessage:self.mobileTextField.text];
    }
}

- (void)sessionDidReceivedData:(NSData *)data
{
    self.isServiceBack = YES;

    if (data.length >= 12) {
        NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
        //授权返回报文
        if ([orderData isEqualToData:[NSData dataFromHexString:@"0110"]]) {

            [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
            self.isShowHud = NO;

            NSData *result = [data subdataWithRange:NSMakeRange(10, 2)];
            if ([result isEqualToData:[NSData dataFromHexString:@"0000"]]) {
                //查询系统配置
                [self.session.socket sendObtainSystemConfigurationMessage];
            } else {
                NSString *message = NSLocalizedString(@"login_fail", nil);
                [self.view makeToast:message];
            }

        //查询系统配置返回报文
        } else if ([orderData isEqualToData:[NSData dataFromHexString:@"0510"]]) {

            [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
            self.isShowHud = NO;

            [self parseObtainSystemConfigurationRespondData:data];

        //获取VWAS模式列表返回报文
        } else if ([orderData isEqualToData:[NSData dataFromHexString:@"0310"]]) {

            [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
            self.isShowHud = NO;
            
            NSData *responderData = [data subdataWithRange:NSMakeRange(24, 1)];
            if ([responderData isEqualToData:[NSData dataFromHexString:@"06"]]) {
                    [self parseObtainVWASModelListData:data];
            } else if ([responderData isEqualToData:[NSData dataFromHexString:@"15"]]) {
                [self parseObtainVwasWallName:data];
            } else if ([responderData isEqualToData:[NSData dataFromHexString:@"01"]]) {
                NSData *statusData = [data subdataWithRange:NSMakeRange(25, 1)];
                if (![statusData isEqualToData:[NSData dataFromHexString:@"00"]]) {
                    NSString *message = NSLocalizedString(@"screen_selected_fail", nil);
                    [self.view makeToast:message];
                }
                [self showHomeViewController];
            }

        //获取光学模式名称返回报文
        } else if ([orderData isEqualToData:[NSData dataFromHexString:@"0710"]]) {
        
            [self parseObtainLightModelListData:data];
            return;
        }
    } else {

        [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
        self.isShowHud = NO;
        NSString *message = NSLocalizedString(@"operation_failed", nil);
        [self.view makeToast:message];

    }

    [_overTimer invalidate];
    _overTimer = nil;

    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];

    if (!isReleaseVersion) {
        [self showHomeViewController];
    }
}

- (void)sessionDidSendData:(NSData *)data
{
    NSString *message = nil;
    self.isServiceBack = NO;

    if (data.length >= 6) {
        NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
        if ([orderData isEqualToData:[NSData dataFromHexString:@"0010"]]) {
            message = NSLocalizedString(@"login", nil);
        } else if ([orderData isEqualToData:[NSData dataFromHexString:@"0410"]]) {
            message = NSLocalizedString(@"system_config", nil);
        } else if ([orderData isEqualToData:[NSData dataFromHexString:@"0210"]]) {
            NSData *IDData = [data subdataWithRange:NSMakeRange(18, 1)];
            if ([IDData isEqualToData:[NSData dataFromHexString:@"06"]]) {
                message = NSLocalizedString(@"vwas_list", nil);
            } else if ([IDData isEqualToData:[NSData dataFromHexString:@"15"]]) {
                message = NSLocalizedString(@"screen_name", nil);
            } else if ([IDData isEqualToData:[NSData dataFromHexString:@"01"]]) {
                message = NSLocalizedString(@"screen_select", nil);
            }
        } else if ([orderData isEqualToData:[NSData dataFromHexString:@"0610"]]) {
            message = NSLocalizedString(@"light_model", nil);
            self.isServiceBack = YES;
            [self showMBProgressHUDWithMessage:message];
            return;
        }
    }

    [self showMBProgressHUDWithMessage:message];

    self.overTimer = [NSTimer scheduledTimerWithTimeInterval:30
                                                      target:self
                                                    selector:@selector(overTimerAction)
                                                    userInfo:nil
                                                     repeats:NO];
}

- (void)showMBProgressHUDWithMessage:(NSString *)message
{
    if (!self.isShowHud) {

        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self windowOfApplication] animated:YES];
        self.isShowHud = YES;
        hud.labelText = message;

    } else {

        MBProgressHUD *hud = [MBProgressHUD HUDForView:[self windowOfApplication]];
        hud.labelText = message;
    }
}

- (void)overTimerAction
{
    if (!self.isServiceBack) {
        [self sessionDidReceivedData:nil];
    }
}

- (void)lightModelListOverTimerAction
{
    [_lightModeTimer invalidate];
    _lightModeTimer = nil;

    [RuntimeData sharedInstance].lightDataList = [self.lightModelList copy];

    [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
    NSString *message = NSLocalizedString(@"operation_failed", nil);
    [self.view makeToast:message];
    self.isShowHud = NO;
    
    NSLog(@"获取光学模式超时");
}

- (void)showHomeViewController
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                         bundle:nil];
    HomeViewController *homeViewController = [storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    [self.navigationController setViewControllers:@[homeViewController]];
}

#pragma mark - 数据解析
- (void)parseObtainSystemConfigurationRespondData:(NSData *)data
{
    if (data.length > 10) {
        NSData *messageData = [data subdataWithRange:NSMakeRange(10, data.length - 10)];
        if ([[messageData subdataWithRange:NSMakeRange(0, 2)] isEqualToData:[NSData dataFromHexString:@"0000"]]) {
            NSData *systemCountData = [messageData subdataWithRange:NSMakeRange(2, 4)];
            NSData *systemListData = [messageData subdataWithRange:NSMakeRange(6, messageData.length - 6)];
            NSUInteger systemCount = [systemCountData valueOfBigUint32_t];
            NSUInteger index = 0;
            NSMutableArray *tempArray = [NSMutableArray array];
            NSMutableArray *totalLightModels = [NSMutableArray array];
            for (int i = 0; i < systemCount; i++) {
                NSData *systemInformationData = [systemListData subdataWithRange:NSMakeRange(index, 12)];
                [tempArray addObject:systemInformationData];
                [totalLightModels addObject:[NSMutableArray array]];
                NSData *systemCodeData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
                NSLog(@"systemCode = %d", [systemCodeData valueOfBigUint32_t]);
                index += 4;
                NSData *lineData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
                NSLog(@"line = %d", [lineData valueOfBigUint32_t]);
                index += 4;
                NSData *rowData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
                NSLog(@"row = %d", [rowData valueOfBigUint32_t]);
                index += 4;
            }

            [RuntimeData sharedInstance].systemDataList = [tempArray copy];
            [RuntimeData sharedInstance].selectedSystemData = [tempArray firstObject];
            [RuntimeData sharedInstance].lightDataList = [totalLightModels copy];
            //获取VWAS模式列表
            [self.session.socket sendObtainVWASModelListMessage];

        } else {
            NSString *message = NSLocalizedString(@"system_config_fail", nil);
            [self.view makeToast:message];
            [self.session.socket sendObtainVWASModelListMessage];
        }
    }
}

- (void)parseObtainVWASModelListData:(NSData *)data
{
    NSString *VWAS_model = NSLocalizedString(@"VWAS model", nil);

    NSPredicate *predicate = [NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(functionType == '%@') AND (isStub == NO)", VWAS_model]];
    NSArray *savedArray = [Icon MR_findAllWithPredicate:predicate];
    if ([[data subdataWithRange:NSMakeRange(10, 2)] isEqualToData:[NSData dataFromHexString:@"0000"]]) {
        NSData *messageBody = [data subdataWithRange:NSMakeRange(10, data.length - 10)];

        //结果(可选)
        NSData *result = [messageBody subdataWithRange:NSMakeRange(16, messageBody.length - 16 - 4)];

        NSData *listCountData = [result subdataWithRange:NSMakeRange(0, 4)];
        NSUInteger listCount = [listCountData valueOfUint32_t];

        NSData *modelListData = [result subdataWithRange:NSMakeRange(4, result.length - 4)];
        NSUInteger count = 0;

        NSMutableArray *tempArray = [NSMutableArray array];
        //VWAS_DEFAULT_CLEARWALL,VWAS_DEFAULT_POWEROFF,VWAS_DEFAULT_POWERON需排除
        for (int i = 0; i < listCount; i++) {
            NSData *modelNameLengthData = [modelListData subdataWithRange:NSMakeRange(count, 4)];
            count += 4;
            NSUInteger modelNameLength = [modelNameLengthData valueOfUint32_t];
            NSData *modelNameData = [modelListData subdataWithRange:NSMakeRange(count, modelNameLength)];
            count += modelNameLength;
            NSString *vwasName = [modelNameData convertDataToStr];
            NSLog(@"vwasName = %@", vwasName);
            if ([vwasName isEqualToString:@"VWAS_DEFAULT_CLEARWALL"]||
                [vwasName isEqualToString:@"VWAS_DEFAULT_POWEROFF"]||
                [vwasName isEqualToString:@"VWAS_DEFAULT_POWERON"]) {
                continue;
            }

            Icon *icon = [[Icon MR_findByAttribute:@"iconMenuName" withValue:modelNameData] firstObject];
            if (!icon) {
                icon = [Icon MR_createEntity];
                icon.isStub = NO;
                icon.index = i;
                icon.canRemove = YES;
                icon.stateImageName = @"function_add";
                icon.serialnumber = i + 34;
                icon.isFrequentlyUsed = NO;
                icon.iconImageName = @"awsa_cnime";
                icon.iconMenuName = modelNameData;
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
            }

            NSString *version = NSLocalizedString(@"version", nil);
            icon.version = version;
            icon.functionType = NSLocalizedString(@"VWAS model", nil);

            NSLog(@"tempArray = %@", tempArray);
            NSLog(@"icon = %@", icon);
            [tempArray addObject:icon];
        }
        [self removeSavedIconFromSavedArray:savedArray receivedArray:tempArray];

        [RuntimeData sharedInstance].VWASList = [tempArray copy];

        if ([RuntimeData sharedInstance].systemDataList.count != 0) {
            //获取光学模式名称
            for (int i = 0; i < 11; i++) {
                [self.session.socket sendObtainLightModelMessage:i];
            }

            self.lightModeTimer = [NSTimer scheduledTimerWithTimeInterval:30
                                                              target:self
                                                            selector:@selector(lightModelListOverTimerAction)
                                                            userInfo:nil
                                                             repeats:NO];
        } else {
            //查完并选择显示墙后才进入
            [self.session.socket sendObtainVWASWallNameMessage];
//            [self showHomeViewController];
        }
    } else {
        NSString *message = NSLocalizedString(@"vwas_list_fail", nil);
        [self.view makeToast:message];
        
        if ([RuntimeData sharedInstance].systemDataList.count != 0) {
            //获取光学模式名称
            for (int i = 0; i < 11; i++) {
                [self.session.socket sendObtainLightModelMessage:i];
            }
            
            self.overTimer = [NSTimer scheduledTimerWithTimeInterval:30
                                                              target:self
                                                            selector:@selector(lightModelListOverTimerAction)
                                                            userInfo:nil
                                                             repeats:NO];
        } else {
            [self showHomeViewController];
        }
    }
}

- (void)removeSavedIconFromSavedArray:(NSArray *)savedArray
                        receivedArray:(NSArray *)receivedArray
{
    if (receivedArray.count != 0) {
        for (Icon *savedIcon in savedArray) {
            BOOL shouldRemove = YES;
            for (Icon *icon in receivedArray) {
                if ([savedIcon.iconMenuName isEqualToData:icon.iconMenuName]) {
                    shouldRemove = NO;
                    break;
                }
            }
            if (shouldRemove) {
                [savedIcon MR_deleteEntity];
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
            }
        }
    }
}

- (void)parseObtainVwasWallName:(NSData *)data
{
    if (data.length >= 12) {
        if ([[data subdataWithRange:NSMakeRange(10, 2)] isEqualToData:[NSData dataFromHexString:@"0000"]]) {
            NSData *messageBody = [data subdataWithRange:NSMakeRange(10, data.length - 10)];
            
            //回应号
            NSData *respondCode = [messageBody subdataWithRange:NSMakeRange(14, 1)];
            if ([respondCode isEqualToData:[NSData dataFromHexString:@"15"]]) {
                //结果(可选)
                NSData *result = [messageBody subdataWithRange:NSMakeRange(16, messageBody.length - 16 - 4)];
                
                NSData *screenCountData = [result subdataWithRange:NSMakeRange(0, 4)];
                NSUInteger screenCount = [screenCountData valueOfUint32_t];
                
                NSData *screenListData = [result subdataWithRange:NSMakeRange(4, result.length - 4)];
                NSUInteger count = 0;
                NSMutableArray *tempArray = [NSMutableArray array];
                for (int i = 0; i < screenCount; i++) {
                    NSData *screenNameLengthData = [screenListData subdataWithRange:NSMakeRange(count, 4)];
                    count += 4;
                    NSUInteger screenNameLength = [screenNameLengthData valueOfUint32_t];
                    NSData *screenNameData = [screenListData subdataWithRange:NSMakeRange(count, screenNameLength)];
                    count += screenNameLength;
                    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
                    NSString *screenName = [[NSString alloc] initWithData:screenNameData encoding:enc];
                    NSLog(@"screenName = %@", screenName);
                    [tempArray addObject:screenNameData];
                }
                NSData *wallData = [tempArray firstObject];
                [RuntimeData sharedInstance].ScreenNameArray = [tempArray copy];
                
                //调用选择墙接口
                [self.session.socket sendChooseShowWallMessage:wallData];
                
            } else {
                NSString *message = NSLocalizedString(@"screen_fail", nil);
                [self.view makeToast:message];
                
                [self showHomeViewController];
            }
        } 
    }
}

- (void)parseObtainLightModelListData:(NSData *)data
{
    //数据有可能粘连
    NSUInteger count = data.length / 64;
    NSLog(@"获取到:%lu个光学模式", (unsigned long)count);
    for (int i = 0; i < count; i++) {
        NSData *unitData = [data subdataWithRange:NSMakeRange(64 * i, 64)];
        NSData *lightNameData = [unitData subdataWithRange:NSMakeRange(24, unitData.length - 24)];
        if (0 == i) {
            if (1 == count || 11 == count) {
                NSString *menuName = NSLocalizedString(@"default_model", nil);
                NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
                lightNameData = [menuName dataUsingEncoding:enc];
            }
        }
        
        NSData *systemCodeLengthData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
        NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
        NSString *systemCode = [NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength];
        
        NSArray *iconMenuNames = [Icon MR_findByAttribute:@"iconMenuName" withValue:lightNameData];
        NSMutableSet *iconMenuNameSet = [NSMutableSet setWithArray:iconMenuNames];
        NSArray *systemCodes = [Icon MR_findByAttribute:@"systemCode" withValue:systemCode];
        NSSet *systemCodeSet = [NSSet setWithArray:systemCodes];
        [iconMenuNameSet intersectSet:systemCodeSet];
        Icon *icon = [iconMenuNameSet.allObjects firstObject];
        
        if (!icon) {
            icon = [Icon MR_createEntity];
            icon.isStub = NO;
            icon.index = i;
            icon.canRemove = YES;
            icon.stateImageName = @"function_add";
            icon.serialnumber = i + 23;
            icon.isFrequentlyUsed = NO;
            icon.iconImageName = @"light_style_default";
            NSData *systemCodeLengthData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
            NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
            NSString *systemCode = [NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength];
            icon.systemCode = systemCode;
            if (0 == i) {
                if (1 == count || 11 == count) {
                    NSString *menuName = NSLocalizedString(@"default_model", nil);
                    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
                    icon.iconMenuName = [menuName dataUsingEncoding:enc];
                }
            }
        
            icon.iconMenuName = lightNameData;
            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
        }
        NSString *version = NSLocalizedString(@"version", nil);
        icon.version = version;
        icon.functionType = NSLocalizedString(@"light model", nil);
        [self.lightModelList addObject:icon];
    }

    if (self.lightModelList.count == 11) {
        [_lightModeTimer invalidate];
        _lightModeTimer = nil;
         [self removeSavedIconFromSavedArray:self.savedArray receivedArray:self.lightModelList];

        NSMutableArray *lightDatas = [[RuntimeData sharedInstance].lightDataList firstObject];
        [lightDatas removeAllObjects];
        [lightDatas addObjectsFromArray:self.lightModelList];

        [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
        self.isShowHud = NO;

        [self showHomeViewController];
    }
}

- (IBAction)QuickLookRequestDataAction:(UIButton *)sender {
    HWPreviewViewController *previewController = [[HWPreviewViewController alloc] init];
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];

    self.filePath = [path stringByAppendingString:@"/data.txt"];

    QLPreviewController *controller = [[QLPreviewController alloc] init];
    controller.dataSource = self;
    [controller reloadData];

    if (![QLPreviewController canPreviewItem:controller.currentPreviewItem]) {
        [self.view makeToast:@"该文件不支持预览！"];
        [self openInOtherApplication];
        return;
    }

    previewController.filePath = self.filePath;
    previewController.title = @"接口报文";
    previewController.automaticallyAdjustsScrollViewInsets = NO;
    controller.automaticallyAdjustsScrollViewInsets = NO;


    controller.view.frame = CGRectMake(0, 64, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 64);;
    [previewController.view addSubview:controller.view];

    [previewController addChildViewController:controller];
    [self.navigationController pushViewController:previewController animated:YES];
}

#pragma mark - 调用其它App打开
- (void)openInOtherApplication
{
    NSURL *fileUrl = [NSURL fileURLWithPath:self.filePath];
    self.documentController = [UIDocumentInteractionController interactionControllerWithURL:fileUrl];
    CGRect rect = CGRectMake(0, 400, 100, 100);
    if ([self.documentController presentOpenInMenuFromRect:rect inView:self.view animated:YES]) {
        NSLog(@"打开");
    } else {
        NSLog(@"打开失败");
    }
}

#pragma mark - QLPreviewControllerDataSource

- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)controller
{
    return 1;
}

- (id)previewController:(QLPreviewController *)controller previewItemAtIndex:(NSInteger)index
{
    //返回文件路径
    return [NSURL fileURLWithPath:self.filePath];
}

@end
