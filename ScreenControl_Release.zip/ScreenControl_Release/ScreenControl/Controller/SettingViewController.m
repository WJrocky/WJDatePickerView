//
//  SettingViewController.m
//  ScreenControl
//
//  Created by wangjian on 12/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NSData+Vtron.h"
#import "UIView+Toast.h"
#import "RuntimeData.h"
#import "VtronSession.h"
#import "MBProgressHUD.h"
#import "MagicalRecord.h"
#import "PopListController.h"
#import "Icon+CoreDataClass.h"
#import "LoginViewController.h"
#import "VtronSocket+Protocol.h"
#import "SettingViewController.h"
#import "UIButton+EnlargeEdge.h"

typedef NS_ENUM(NSUInteger, serviceType) {
    serviceTypeLightModelName = 2,
    serviceTypeChooseVwasWall,
    serviceTypeQueryVwasWallName
};

@interface SettingViewController ()<UITextFieldDelegate, VtronSessionDelegate, PopListControllerDelegate>

@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) NSMutableArray *walls;
@property (weak, nonatomic) IBOutlet UIButton *systemCodeButton;
@property (weak, nonatomic) IBOutlet UIButton *vwasWallButton;
@property (weak, nonatomic) IBOutlet UITextField *hostTextField;
@property (weak, nonatomic) IBOutlet UILabel *lineLabel;
@property (weak, nonatomic) IBOutlet UILabel *rowLabel;
@property (weak, nonatomic) IBOutlet UITextField *pptHostTextField;
@property (assign, nonatomic) BOOL isServiceBack;
@property (nonatomic, strong) NSArray *savedArray;
@property (nonatomic, strong) NSMutableArray *lightModelList;
@property (nonatomic, assign) serviceType type;
@property (nonatomic, strong) NSTimer *overTimer;
@property (nonatomic, strong) NSIndexPath *selectedIndexPath;
@property (nonatomic, assign) BOOL isShowHud;

@end

@implementation SettingViewController

- (void)dealloc
{
    NSLog(@"controller delloc");
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);
    [myButton setEnlargeEdge:4];
    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;
    
    self.walls = [NSMutableArray array];
    
    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;
    
    self.type = serviceTypeQueryVwasWallName;
    [self.session.socket sendObtainVWASWallNameMessage];

    NSString *host = [RuntimeData sharedInstance].host;

    self.hostTextField.text = host.length == 0 ? @"192.168.1.1":host;

    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

    NSString *pptHost = [userDefaults valueForKey:@"pptHost"];
    if (0 == pptHost.length) {
        pptHost = self.hostTextField.text;
    }
    self.pptHostTextField.text = pptHost;

    NSData *systemCodeLengthData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
    NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
//    NSString *systemCode = sytem
    
    [self.systemCodeButton setTitle:[NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength] forState:UIControlStateNormal];
    
    NSData *lineData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(4, 4)];
    NSUInteger line = [lineData valueOfBigUint32_t];

    NSString *lineString = NSLocalizedString(@"line", nil);
    self.lineLabel.text = [NSString stringWithFormat:@"%@%ld", lineString, (unsigned long)line];
    
    NSData *rowData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(8, 4)];
    NSUInteger row = [rowData valueOfBigUint32_t];
    NSString *rowString = NSLocalizedString(@"row", nil);
    self.rowLabel.text = [NSString stringWithFormat:@"%@%ld", rowString, (unsigned long)row];

    NSLog(@"self = %@", self);
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)popListControllerAction:(UIButton *)sender {
    if (self.walls.count > 0) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle:nil];
        PopListController *popListController = [storyboard instantiateViewControllerWithIdentifier:@"PopListController"];
        popListController.delegate = self;
        if (1024 == sender.tag) {
            NSMutableArray *systemCodeArray = [NSMutableArray array];
            for (NSData *systemCodeData in [RuntimeData sharedInstance].systemDataList) {
                if (systemCodeData.length > 4) {
                    NSData *systemCodeLengthData = [systemCodeData subdataWithRange:NSMakeRange(0, 4)];
                    NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
                    NSString *systemCodeString = [NSString stringWithFormat:@"%lu",(unsigned long)systemCodeLength];
                    [systemCodeArray addObject:systemCodeString];
                }
            }
            if (systemCodeArray.count > 0) {
                [popListController loadData:systemCodeArray type:@"系统号"];
                UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
                popListController.view.frame = [UIScreen mainScreen].bounds;
                
                [keyWindow addSubview:popListController.view];
                [self addChildViewController:popListController];
            }
        } else if (1025 == sender.tag) {
            [popListController loadData:self.walls type:@"Vwas墙"];
            UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
            popListController.view.frame = [UIScreen mainScreen].bounds;
            
            [keyWindow addSubview:popListController.view];
            [self addChildViewController:popListController];
        }
    }
}

- (IBAction)changePPtHostAction:(UIButton *)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                         bundle:nil];
    PopListController *popListController = [storyboard instantiateViewControllerWithIdentifier:@"PopListController"];
    popListController.delegate = self;
    NSString *pptHost = self.pptHostTextField.text;
    NSMutableArray *dataSource = [NSMutableArray arrayWithArray:@[pptHost]];
    [popListController loadData:dataSource type:@"PPT翻页"];
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    popListController.view.frame = [UIScreen mainScreen].bounds;

    [keyWindow addSubview:popListController.view];
    [self addChildViewController:popListController];
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidSendData:(NSData *)data
{
    NSString *message = nil;
    self.isServiceBack = NO;
    switch (self.type) {
        case serviceTypeLightModelName:
            self.isServiceBack = YES;
            message = NSLocalizedString(@"light_model", nil);
            break;
        case serviceTypeChooseVwasWall:
            message = NSLocalizedString(@"screen_select", nil);
            break;
        case serviceTypeQueryVwasWallName:
            message = NSLocalizedString(@"screen_name", nil);
            break;
        default:
            break;
    }

    self.overTimer = [NSTimer scheduledTimerWithTimeInterval:3
                                                      target:self
                                                    selector:@selector(overTimeAction)
                                                    userInfo:nil
                                                     repeats:NO];

    if (!self.isShowHud) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self windowOfApplication] animated:YES];
        self.isShowHud = YES;
        hud.labelText = message;
    } else {
        MBProgressHUD *hud = [MBProgressHUD HUDForView:[self windowOfApplication]];
        hud.labelText = message;
    }
}

- (void)overTimeAction
{
    if (!self.isServiceBack) {
        [self sessionDidReceivedData:nil];

        if (!self.session.isConnected) {

            [self.session.socket close];
            self.session.isConnected = NO;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                                     bundle:nil];
                LoginViewController *loginViewController = [storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
                loginViewController.isReadForWrite = NO;
                [self.navigationController setViewControllers:@[loginViewController]];
            });
        }
    }
}

- (void)lightModelListOverTimerAction
{
    [_overTimer invalidate];
    _overTimer = nil;
    if (self.lightModelList.count != 11) {

        [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
        self.isShowHud = NO;
        NSString *message = NSLocalizedString(@"operation_failed", nil);
        [self.view makeToast:message];
    }
}

- (void)sessionDidReceivedData:(NSData *)data
{
    self.isServiceBack = YES;
    if (data.length >= 12) {

        if (serviceTypeLightModelName == self.type) {
            [self parseObtainLightModelListData:data];
        } else if (serviceTypeChooseVwasWall == self.type) {
            [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
            self.isShowHud = NO;

            return;
        } else if (serviceTypeQueryVwasWallName == self.type) {
            [self parseObtainVwasWallName:data];
        }

    } else {

        [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
        self.isShowHud = NO;
        NSString *message = nil;
        if (self.isServiceBack) {
            message = NSLocalizedString(@"operation_failed", nil);
        } else {
            message = NSLocalizedString(@"connection_failed", nil);
        }
        [self.view makeToast:message];
    }
    [_overTimer invalidate];
    _overTimer = nil;
}

#pragma mark - delegate
- (void)PopListController:(PopListController *)controller didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.session.delegate = self;
    if ([controller.type isEqualToString:@"系统号"]) {
        //选择系统号后需要重新查询光学模式
        self.selectedIndexPath = indexPath;

        if ([[RuntimeData sharedInstance].lightDataList count] > self.selectedIndexPath.row) {
            NSMutableArray *lightDatas = [[RuntimeData sharedInstance].lightDataList objectAtIndex:self.selectedIndexPath.row];
            if (0 == lightDatas.count) {
                
                NSData *systemCodeData = [[RuntimeData sharedInstance].systemDataList objectAtIndex:self.selectedIndexPath.row];
                [RuntimeData sharedInstance].selectedSystemData = systemCodeData;
                
                NSString *light_model = NSLocalizedString(@"light model", nil);

                NSPredicate *predicate = [NSPredicate predicateWithFormat:[NSString stringWithFormat:@"(functionType == '%@') AND (isStub == NO)", light_model]];
                self.savedArray = [Icon MR_findAllWithPredicate:predicate];

                //获取光学模式名称
                for (int i = 0; i < 11; i++) {
                    self.type = serviceTypeLightModelName;
                    [self.session.socket sendObtainLightModelMessage:i];
                }

                self.lightModelList = [NSMutableArray array];
                self.overTimer = [NSTimer scheduledTimerWithTimeInterval:30
                                                                  target:self
                                                                selector:@selector(lightModelListOverTimerAction)
                                                                userInfo:nil
                                                                 repeats:NO];
            } else {
                [self changeSystemCode];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"updateDataSource" object:nil];
            }
        }
    } else if ([controller.type isEqualToString:@"Vwas墙"]) {
        //VWAS墙
        NSData *wallData = [self.walls objectAtIndex:indexPath.row];
        self.type = serviceTypeChooseVwasWall;
        //可以暂时屏蔽
        [self.session.socket sendChooseShowWallMessage:wallData];
        NSString *name = [wallData convertDataToStr];
        [self.vwasWallButton setTitle:name forState:UIControlStateNormal];
    } else if ([controller.type isEqualToString:@"PPT翻页"]) {
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *pptHost = [userDefaults valueForKey:@"pptHost"];
        self.pptHostTextField.text = pptHost;
    }
}

- (void)parseObtainVwasWallName:(NSData *)data
{
    [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
    self.isShowHud = NO;
    self.isServiceBack = YES;

    if (data.length >= 12) {
        if ([[data subdataWithRange:NSMakeRange(10, 2)] isEqualToData:[NSData dataFromHexString:@"0000"]]) {
            NSData *messageBody = [data subdataWithRange:NSMakeRange(10, data.length - 10)];

            //回应号
            NSData *respondCode = [messageBody subdataWithRange:NSMakeRange(14, 1)];
            if ([respondCode isEqualToData:[NSData dataFromHexString:@"15"]]) {
                //结果(可选)
                NSData *result = [messageBody subdataWithRange:NSMakeRange(16, messageBody.length - 16 - 4)];

                NSData *screenCountData = [result subdataWithRange:NSMakeRange(0, 4)];
                NSUInteger screenCount = [screenCountData valueOfUint32_t];

                NSData *screenListData = [result subdataWithRange:NSMakeRange(4, result.length - 4)];
                NSUInteger count = 0;
                for (int i = 0; i < screenCount; i++) {
                    NSData *screenNameLengthData = [screenListData subdataWithRange:NSMakeRange(count, 4)];
                    count += 4;
                    NSUInteger screenNameLength = [screenNameLengthData valueOfUint32_t];
                    NSData *screenNameData = [screenListData subdataWithRange:NSMakeRange(count, screenNameLength)];
                    count += screenNameLength;
                    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
                    NSString *screenName = [[NSString alloc] initWithData:screenNameData encoding:enc];
                    NSLog(@"screenName = %@", screenName);
                    [self.walls addObject:screenNameData];
                }
                NSData *wallData = [self.walls firstObject];
                NSString *name = [wallData convertDataToStr];
                [self.vwasWallButton setTitle:name forState:UIControlStateNormal];
            } else {
                NSString *message = NSLocalizedString(@"screen_fail", nil);
                [self.view makeToast:message];
            }
        } 
    }
}

- (void)parseObtainLightModelListData:(NSData *)data
{
    //数据有可能粘连
    NSUInteger count = data.length / 64;
    for (int i = 0; i < count; i++) {
        NSData *unitData = [data subdataWithRange:NSMakeRange(64 * i, 64)];
        NSData *lightNameData = [unitData subdataWithRange:NSMakeRange(24, unitData.length - 24)];
        if (0 == i) {
            if (1 == count || 11 == count) {
                NSString *menuName = NSLocalizedString(@"default_model", nil);
                NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
                lightNameData = [menuName dataUsingEncoding:enc];
            }
        }
        
        NSData *systemCodeLengthData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
        NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];
        NSString *systemCode = [NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength];
        
        NSArray *iconMenuNames = [Icon MR_findByAttribute:@"iconMenuName" withValue:lightNameData];
        NSMutableSet *iconMenuNameSet = [NSMutableSet setWithArray:iconMenuNames];
        NSArray *systemCodes = [Icon MR_findByAttribute:@"systemCode" withValue:systemCode];
        NSSet *systemCodeSet = [NSSet setWithArray:systemCodes];
        [iconMenuNameSet intersectSet:systemCodeSet];
        Icon *icon = [iconMenuNameSet.allObjects firstObject];
        NSLog(@"saved iconMenuName = %@", [icon.iconMenuName convertDataToStr]);
        if (!icon) {
            icon = [Icon MR_createEntity];
            icon.isStub = NO;
            icon.index = i;
            icon.canRemove = YES;
            icon.stateImageName = @"function_add";
            icon.serialnumber = i + 23;
            icon.isFrequentlyUsed = NO;
            icon.iconImageName = @"light_style_default";

            icon.systemCode = systemCode;
            if (0 == i) {
                if (1 == count || 11 == count) {
                    NSString *menuName = NSLocalizedString(@"default_model", nil);
                    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
                    icon.iconMenuName = [menuName dataUsingEncoding:enc];
                }
            }
            icon.iconMenuName = lightNameData;
            NSLog(@"iconMenuName = %@", [lightNameData convertDataToStr]);
            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
        }
        NSString *version = NSLocalizedString(@"version", nil);
        icon.version = version;
        icon.functionType = NSLocalizedString(@"light model", nil);
        [self.lightModelList addObject:icon];
    }

    if (self.lightModelList.count == 11) {
        [_overTimer invalidate];
        _overTimer = nil;

        if ([[RuntimeData sharedInstance].lightDataList count] > self.selectedIndexPath.row) {
            NSMutableArray *lightDatas = [[RuntimeData sharedInstance].lightDataList objectAtIndex:self.selectedIndexPath.row];
            [lightDatas removeAllObjects];
            [lightDatas addObjectsFromArray:self.lightModelList];
        }
        
        [MBProgressHUD hideHUDForView:[self windowOfApplication] animated:YES];
        self.isShowHud = NO;
        
        [self changeSystemCode];

        [[NSNotificationCenter defaultCenter] postNotificationName:@"updateDataSource" object:nil];
    }
}

- (void)changeSystemCode
{
    NSData *systemCodeData = [[RuntimeData sharedInstance].systemDataList objectAtIndex:self.selectedIndexPath.row];
    [RuntimeData sharedInstance].selectedSystemData = systemCodeData;

    NSData *systemCodeLengthData = [systemCodeData subdataWithRange:NSMakeRange(0, 4)];
    NSUInteger systemCodeLength = [systemCodeLengthData valueOfBigUint32_t];

    [self.systemCodeButton setTitle:[NSString stringWithFormat:@"%lu", (unsigned long)systemCodeLength] forState:UIControlStateNormal];

    NSData *lineData = [systemCodeData subdataWithRange:NSMakeRange(4, 4)];
    NSUInteger line = [lineData valueOfBigUint32_t];

    NSString *lineString = NSLocalizedString(@"line", nil);
    self.lineLabel.text = [NSString stringWithFormat:@"%@%ld", lineString, (unsigned long)line];

    NSData *rowData = [systemCodeData subdataWithRange:NSMakeRange(8, 4)];
    NSUInteger row = [rowData valueOfBigUint32_t];
    NSString *rowString = NSLocalizedString(@"row", nil);
    self.rowLabel.text = [NSString stringWithFormat:@"%@%ld", rowString, (unsigned long)row];
}

- (void)removeSavedIconFromSavedArray:(NSArray *)savedArray
                        receivedArray:(NSArray *)receivedArray
{
    if (receivedArray.count != 0) {
        for (Icon *savedIcon in savedArray) {
            BOOL shouldRemove = YES;
            for (Icon *icon in receivedArray) {
                if ([savedIcon.iconMenuName isEqualToData:icon.iconMenuName]) {
                    shouldRemove = NO;
                    break;
                }
            }
            if (shouldRemove) {
                [savedIcon MR_deleteEntity];
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
            }
        }
    }
}

@end
