//
//  HWPreviewViewController.m
//  GDMobileESOP
//
//  Created by wangjian on 16/6/2.
//  Copyright © 2016年 huawei. All rights reserved.
//

#import "HWPreviewViewController.h"

@interface HWPreviewViewController ()

@property(nonatomic,strong) UIDocumentInteractionController *documentController;

@end

@implementation HWPreviewViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIBarButtonItem *deleteBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"清除" style:UIBarButtonItemStyleDone target:self action:@selector(onOpenInOtherApplicationClick)];
    self.navigationItem.rightBarButtonItem = deleteBarButtonItem;

    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
}

- (void)onOpenInOtherApplicationClick
{
    NSFileManager *manager = [NSFileManager defaultManager];
    [manager removeItemAtPath:self.filePath error:nil];
}

@end
