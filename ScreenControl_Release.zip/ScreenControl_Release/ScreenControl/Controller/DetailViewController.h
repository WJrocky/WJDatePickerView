//
//  DetailViewController.h
//  ScreenControl
//
//  Created by wangjian on 13/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "BaseViewController.h"
#import "Icon+CoreDataClass.h"

@interface DetailViewController : BaseViewController

@property (nonatomic, strong) Icon *model;

@end
