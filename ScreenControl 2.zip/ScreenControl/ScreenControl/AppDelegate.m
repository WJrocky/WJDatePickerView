//
//  AppDelegate.m
//  ScreenControl
//
//  Created by wangjian on 07/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#include <ifaddrs.h>
#include <arpa/inet.h>
#import "AppDelegate.h"
#import "MagicalRecord.h"
#import "AsyncUdpSocket.h"
#import "Icon+CoreDataClass.h"

@interface AppDelegate ()<AsyncUdpSocketDelegate>

@property (nonatomic, strong) AsyncUdpSocket *socket;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    UINavigationController *rootNavigationController = (UINavigationController *)self.window.rootViewController;

    NSDictionary *colorAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    rootNavigationController.navigationBar.titleTextAttributes = colorAttributes;

    [MagicalRecord setupCoreDataStackWithStoreNamed:@"PersistentData.sqlite"];
    
    if (0 == [Icon MR_findAll].count) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"HomeFunction" ofType:@"plist"];
        NSArray *functions = [NSArray arrayWithContentsOfFile:path];
        
        for (NSDictionary *iconDictionary in functions) {
            Icon *icon = [Icon MR_createEntity];
            [icon setValuesForKeysWithDictionary:iconDictionary];
            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
        }
    }
    
    //创建socket(UDP)
    self.socket = [[AsyncUdpSocket alloc] initWithDelegate:self];
    
    //允许广播形式
    [self.socket enableBroadcast:YES error:nil];
    
    [self.socket bindToAddress:[self getIPAddress] port:12000 error:nil];
    
    unsigned char *body = malloc(10);
    memset(body, 0, 10);
    
    body[0] = 0x01;
    body[1] = 0x00;
    body[2] = 0x01;
    body[3] = 0x00;
    
    body[4] = 0x00;
    body[5] = 0x10;
    
    body[6] = 0x00;
    body[7] = 0x00;
    body[8] = 0x00;
    body[9] = 0x00;
    
    NSData *data = [NSData dataWithBytes:body length:10];
    
    //启动接收线程
    [self.socket receiveWithTimeout:-1 tag:0];
    
    [self.socket sendData:data toHost:@"255.255.255.255" port:12000 withTimeout:-1 tag:0];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    /*
     _client = [[AsyncUdpSocket alloc]initWithDelegate:self];
     NSError *err = nil;
     [_client bindToPort:PORT error:&err];
     if (err) {
     NSLog(@"error:%@",err);
     }
     
     [_client enableBroadcast:YES error:&err];
     char send[5] = {0x69,0x68,0x16,0x17};
     
     NSString *msg = [[NSString alloc]initWithUTF8String:&send];
     NSData *senddata = [msg dataUsingEncoding:NSUTF8StringEncoding];
     
     [_client sendData:senddata toHost:IP port:PORT withTimeout:-1 tag:0];
     [_client receiveWithTimeout:-1 tag:0];
    */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    [MagicalRecord cleanUp];
}

-(NSString *)getIPAddress{
    NSString *address = @"error";
    struct ifaddrs *interface = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    
    success = getifaddrs(&interface);
    if(success == 0){
        temp_addr = interface;
        while (temp_addr != NULL) {
            if(temp_addr->ifa_addr->sa_family == AF_INET){
                
                
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en1"]){
                address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                 }
            
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    freeifaddrs(interface);
    return address;
}

#pragma mark - AsyncUdpSocketDelegate
//已接收消息
- (BOOL)onUdpSocket:(AsyncUdpSocket *)sock
     didReceiveData:(NSData *)data
            withTag:(long)tag
           fromHost:(NSString *)host
               port:(UInt16)port
{
    //这里做一下验证，确定命令ID是0110，将host进行持久化
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setValue:host forKey:@"host"];
    [sock close];
    return YES;
}

//没有接受消息
- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotReceiveDataWithTag:(long)tag dueToError:(NSError *)error
{
    
}

//没有发出消息
- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotSendDataWithTag:(long)tag dueToError:(NSError *)error
{
    
}

//已发出消息
- (void)onUdpSocket:(AsyncUdpSocket *)sock didSendDataWithTag:(long)tag
{
    //启动监听下一条消息
//    [self.socket receiveWithTimeout:-1 tag:0];
}

//断开连接
- (void)onUdpSocketDidClose:(AsyncUdpSocket *)sock
{
    
}

@end
