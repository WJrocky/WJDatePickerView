//
//  VtronSocket.m
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <sys/socket.h>
#import "VtronSocket.h"
#import <arpa/inet.h>

@interface VtronSocket ()<NSStreamDelegate>

@property (nonatomic, strong) NSInputStream *inputStream;
@property (nonatomic, strong) NSOutputStream *outputStream;

@end

@implementation VtronSocket

- (void)tcpConnectToHost:(NSString *)host port:(UInt32)port
{
    //输入流,用来读取数据
    CFReadStreamRef readStream;
    //输出流,用来发送数据
    CFWriteStreamRef writeStream;

    //建立socket连接
    CFStreamCreatePairWithSocketToHost(NULL, (__bridge CFStringRef)(host), port, &readStream, &writeStream);

    //注意__bridge_transfer,转移对象的内存管理权
    self.inputStream = (__bridge_transfer NSInputStream *)(readStream);
    self.outputStream = (__bridge_transfer NSOutputStream *)(writeStream);

    self.inputStream.delegate = self;
    self.outputStream.delegate = self;

    [self.outputStream scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    [self.inputStream scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];

    [self.outputStream open];
    [self.inputStream open];
}

- (void)udpConnection:(NSString *)hostText port:(int)port
{
    /**
     参数
     domain:    协议域，AF_INET（IPV4的网络开发）
     type:      Socket 类型，SOCK_STREAM(TCP)/SOCK_DGRAM(UDP，报文)
     protocol:  IPPROTO_TCP，协议，如果输入0，可以根据第二个参数，自动选择协议

     返回值
     socket，如果 > 0 就表示成功
     */
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        NSLog(@"socket create failure");
    }

    //connection 连接到“服务器”
    /**
     参数
     1> 客户端socket
     2> 指向数据结构sockaddr的指针，其中包括目的端口和IP地址
     服务器的"结构体"地址，C语言没有对象
     3> 结构体数据长度
     返回值
     0 成功/其他 错误代号，非0即真
     */
    struct sockaddr_in serverAddress;
    // IPV4 - 协议
    serverAddress.sin_family = AF_INET;
    memset(&serverAddress, 0, sizeof(struct sockaddr_in));
    // inet_addr函数可以把ip地址转换成一个整数
    serverAddress.sin_addr.s_addr = inet_addr(hostText.UTF8String);
    // 端口小端存储
    serverAddress.sin_port = htons(port);

    int result = connect(sock, (const struct sockaddr *)&serverAddress, sizeof(serverAddress));

    if (0 == result) {
        NSLog(@"connect success!");
    }
}

#pragma mark NSStreamDelegate
- (void)stream:(NSStream *)aStream handleEvent:(NSStreamEvent)eventCode
{
    if ([self.delegate respondsToSelector:@selector(VtronSocket:didChangeStatus:)]) {
        [self.delegate VtronSocket:self didChangeStatus:eventCode];
    }
}

- (NSData *)readData
{
    //缓存区设置为4K
    uint8_t buff[4096];

    NSUInteger len = [self.inputStream read:buff maxLength:sizeof(buff)];

    NSData *data = nil;

    if (len < sizeof(buff) && (_outputStream.hasSpaceAvailable)) {
        data = [NSData dataWithBytes:buff length:len];
    }
    NSLog(@"receive data = %@", data);
    return data;
}

- (NSInteger)writeData:(NSData *)data
{
    if (0 == data.length) {
        return 0;
    }

    NSInteger ret = 0;
    if (_outputStream.hasSpaceAvailable) {
        ret = [_outputStream write:data.bytes maxLength:data.length];
    }
    NSLog(@"write data = %@", data);
    return ret;
}

@end
