//
//  VtronSocket+Protocol.m
//  ScreenControl
//
//  Created by wangjian on 25/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "RuntimeData.h"
#import "VtronSocket+Protocol.h"

@implementation VtronSocket (Protocol)

#pragma mark - 手机授权
- (void)sendLoginMessage:(NSString *)message
{
    NSData *sectionID = [self sectionID];

    NSData *orderID = [self dataFromHexString:@"0010"];
    
    NSData *length = [self dataLength:11];

    unsigned char *body = malloc(11);
    memset(body, 0, 11);

    for (int i = 0; i < message.length; i++) {
        int asciiCode = [message characterAtIndex:i];
        body[i] = asciiCode;
    }

    NSMutableData *data = [NSMutableData data];
    [data appendData:sectionID];
    [data appendData:orderID];
    [data appendData:length];
    [data appendBytes:body length:11];

    [self writeData:data];
}

#pragma mark - VWAS中控透传(消息数据小端字节)
#pragma mark - 选择显示墙
- (void)sendChooseShowWallMessage:(NSData *)message
{
    NSData *frameData = [self dataLength:message.length + 1 byteCount:4];
    NSData *ID = [self dataFromHexString:@"01"];
    NSData *parameterData = message;

    NSMutableData *data = [self appendVWASDataWithFrameData:frameData
                                                     IDdata:ID
                                              parameterData:parameterData];

    [self writeData:data];
}

#pragma mark - 打开显示墙所有机芯
- (void)sendOpenAllWatchWallMachineMessage
{
    NSData *frameData = [self dataLength:1 byteCount:4];
    NSData *ID = [self dataFromHexString:@"03"];
    NSData *parameterData = nil;

    NSMutableData *data = [self appendVWASDataWithFrameData:frameData
                                                     IDdata:ID
                                              parameterData:parameterData];

    [self writeData:data];
}

#pragma mark - 关闭显示墙所有机芯
- (void)sendCloseAllWatchWallMachineMessage
{
    NSData *frameData = [self dataLength:1 byteCount:4];
    NSData *ID = [self dataFromHexString:@"05"];
    NSData *parameterData = nil;

    NSMutableData *data = [self appendVWASDataWithFrameData:frameData
                                                     IDdata:ID
                                              parameterData:parameterData];

    [self writeData:data];
}

#pragma mark - 获取VWAS模式列表
- (void)sendObtainVWASModelListMessage
{
    NSData *frameData = [self dataLength:1 byteCount:4];
    NSData *ID = [self dataFromHexString:@"06"];
    NSData *parameterData = nil;

    NSMutableData *data = [self appendVWASDataWithFrameData:frameData
                                                     IDdata:ID
                                              parameterData:parameterData];

    [self writeData:data];
}

#pragma mark - 调用VWAS模式
- (void)sendStartVWASModelMessage:(NSData *)message
{
    NSData *frameData = [self dataLength:message.length + 1 byteCount:4];
    NSData *ID = [self dataFromHexString:@"3e"];
    NSData *parameterData = message;

    NSMutableData *data = [self appendVWASDataWithFrameData:frameData
                                                     IDdata:ID
                                              parameterData:parameterData];

    [self writeData:data];
}

#pragma mark - 枚举显示墙名称
- (void)sendObtainVWASWallNameMessage
{
    NSData *ID = [self dataFromHexString:@"15"];
    NSData *frameData = [self dataLength:ID.length byteCount:4];
    NSData *parameterData = nil;

    NSMutableData *data = [self appendVWASDataWithFrameData:frameData
                                                     IDdata:ID
                                              parameterData:parameterData];

    [self writeData:data];
}

- (NSMutableData *)appendVWASDataWithSectionID:(NSData *)sectionID
                                       orderID:(NSData *)orderID
                                     startData:(NSData *)startData
                                     frameData:(NSData *)frameData
                                        IDdata:(NSData *)IDdata
                                 parameterData:(NSData *)parameterData
                                       endData:(NSData *)endata
{
    NSMutableData *body = [NSMutableData data];
    [body appendData:startData];
    [body appendData:frameData];
    [body appendData:IDdata];
    [body appendData:parameterData];
    [body appendData:endata];

    NSMutableData *header = [NSMutableData data];
    [header appendData:sectionID];
    [header appendData:orderID];
    [header appendData:[self dataLength:body.length]];

    [header appendData:body];

    return header;
}

- (NSMutableData *)appendVWASDataWithFrameData:(NSData *)frameData
                                      IDdata:(NSData *)IDdata
                              parameterData:(NSData *)parameterData
{
    NSMutableData *data = [self appendVWASDataWithSectionID:[self sectionID]
                                                    orderID:[self dataFromHexString:@"0210"]
                                                  startData:[self startData]
                                                  frameData:frameData
                                                     IDdata:IDdata
                                              parameterData:parameterData
                                                    endData:[self endData]];
    return data;
}

#pragma mark - 查询系统配置信息
- (void)sendObtainSystemConfigurationMessage
{
    unsigned char *sectionID = malloc(4);
    memset(sectionID, 0, 4);

    sectionID[0] = 0x00;
    sectionID[1] = 0x01;
    sectionID[2] = 0x00;
    sectionID[3] = 0x01;

    unsigned char *orderID = malloc(2);
    memset(orderID, 0, 2);

    orderID[0] = 0x04;
    orderID[1] = 0x10;

    unsigned char *length = malloc(4);
    memset(length, 0, 4);

    length[0] = 0x00;
    length[1] = 0x00;
    length[2] = 0x00;
    length[3] = 0x00;

    NSMutableData *data = [NSMutableData data];

    [data appendBytes:sectionID length:4];
    [data appendBytes:orderID length:2];
    [data appendBytes:length length:4];

    [self writeData:data];
}

#pragma mark - 指定单元透传命令
#pragma mark - 获取光学模式名称
- (void)sendObtainLightModelMessage:(NSUInteger)index
{
    //系统号
    NSData *systemCodeData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
    NSData *systemCode = systemCodeData;
    NSData *unitCode = [self dataFromHexString:@"0000"];
    NSData *IDdata = [self dataFromHexString:@"c866"];
    NSData *lengthData = [self dataLength:1];
    unsigned char * message = malloc(1);
    memset(message, 0, 1);
    message[0] = index;
    NSData *messageData = [NSData dataWithBytes:message length:1];
    NSMutableData *data = [self appendUnitDataWithSystemCode:systemCode
                                                    unitCode:unitCode
                                                      IDdata:IDdata
                                                  lengthData:lengthData
                                                 messageData:messageData];
    [self writeData:data];
}

#pragma mark - PPT上一页
- (void)sendTurnPPTLastPageMessage
{
    NSData *systemCode = [self dataLength:19];
    NSData *unitCode = [self dataFromHexString:@"0100"];
    NSData *IDdata = [self dataFromHexString:@"8871"];
    NSData *lengthData = [self dataLength:2];
    NSData *messageData = [self dataFromHexString:@"0100"];
    NSMutableData *data = [self appendUnitDataWithSystemCode:systemCode
                                                    unitCode:unitCode
                                                      IDdata:IDdata
                                                  lengthData:lengthData
                                                 messageData:messageData];
    [self writeData:data];
}

#pragma mark - PPT下一页
- (void)sendTurnPPTNextPageMessage
{
    NSData *systemCode = [self dataLength:20];
    NSData *unitCode = [self dataFromHexString:@"0100"];
    NSData *IDdata = [self dataFromHexString:@"8871"];
    NSData *lengthData = [self dataLength:2];
    NSData *messageData = [self dataFromHexString:@"0100"];
    NSMutableData *data = [self appendUnitDataWithSystemCode:systemCode
                                                    unitCode:unitCode
                                                      IDdata:IDdata
                                                  lengthData:lengthData
                                                 messageData:messageData];
    [self writeData:data];
}

- (NSMutableData *)appendUnitDataWithSectionID:(NSData *)sectionID
                                       orderID:(NSData *)orderID
                                    systemCode:(NSData *)systemCode
                                      unitCode:(NSData *)unitCode
                                        IDdata:(NSData *)IDdata
                                    lengthData:(NSData *)lengthData
                                   messageData:(NSData *)messageData
{
    NSMutableData *body = [NSMutableData data];
    [body appendData:systemCode];
    [body appendData:unitCode];
    [body appendData:IDdata];
    [body appendData:lengthData];
    [body appendData:messageData];

    NSMutableData *header = [NSMutableData data];
    [header appendData:sectionID];
    [header appendData:orderID];
    [header appendData:[self dataLength:body.length]];

    [header appendData:body];

    return header;
}

- (NSMutableData *)appendUnitDataWithSystemCode:(NSData *)systemCode
                                      unitCode:(NSData *)unitCode
                                        IDdata:(NSData *)IDdata
                                    lengthData:(NSData *)lengthData
                                   messageData:(NSData *)messageData
{
    NSMutableData *data = [self appendUnitDataWithSectionID:[self sectionID]
                                                    orderID:[self dataFromHexString:@"0610"]
                                                 systemCode:systemCode
                                                   unitCode:unitCode
                                                     IDdata:IDdata
                                                 lengthData:lengthData
                                                messageData:messageData];
    return data;
}

#pragma mark - 开关机
- (void)sendStartOrShutDownMessage:(NSUInteger)type
{
    unsigned char *sectionID = malloc(4);
    memset(sectionID, 0, 4);
    sectionID[0] = 0x00;
    sectionID[1] = 0x01;
    sectionID[2] = 0x00;
    sectionID[3] = 0x01;

    unsigned char *orderID = malloc(2);
    memset(orderID, 0, 2);

    orderID[0] = 0x08;
    orderID[1] = 0x10;

    unsigned char *body = malloc(16);
    memset(body, 0, 16);

    //开关机类型
    body[0] = type;
    body[1] = 0x00;
    body[2] = 0x00;
    body[3] = 0x00;

    //系统号
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];
    if (isReleaseVersion) {
        NSData *systemCodeData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
        memcpy(body + 4, systemCodeData.bytes, 4);
    }

    //单元数量
    body[8] = 0x00;
    body[9] = 0x00;
    body[10] = 0x00;
    body[11] = 0x00;

    //单元号
    body[12] = 0x00;
    body[13] = 0x00;

    //单元号
    body[14] = 0x00;
    body[15] = 0x00;


    unsigned char *length = malloc(4);
    memset(length, 0, 4);

    length[0] = 16 & 0xff;
    length[1] = (16 >> 8) & 0xff;
    length[2] = (16 >> 16) & 0xff;
    length[3] = (16 >> 24) & 0xff;

    NSMutableData *data = [NSMutableData data];
    [data appendBytes:sectionID length:4];
    [data appendBytes:orderID length:2];
    [data appendBytes:length length:4];
    [data appendBytes:body length:16];
    
    [self writeData:data];
}

#pragma mark - 整墙透传指令
#pragma mark - 设置桌面
- (void)sendSettingDesktopMessage:(NSUInteger)number
{
    //系统号
    NSData *systemCodeData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
    NSData *systemCode = systemCodeData;
    NSData *IDdata = [self dataFromHexString:@"1a60"];
    NSData *lengthData = [self dataFromHexString:@"04000000"];
    NSData *messageData = [self dataLength:number];

    NSData *data = [self appendTotalWallDataWithSystemCode:systemCode
                                                    IDdata:IDdata
                                                lengthData:lengthData
                                               messageData:messageData];
    [self writeData:data];
}

#pragma mark - 调用光学模式
- (void)sendStartlightModelMessage:(NSUInteger)index
{
    //系统号
    NSData *systemCodeData = [[RuntimeData sharedInstance].selectedSystemData subdataWithRange:NSMakeRange(0, 4)];
    NSData *systemCode = systemCodeData;
    NSData *IDdata = [self dataFromHexString:@"2a60"];
    NSData *lengthData = [self dataFromHexString:@"01000000"];
    unsigned char * message = malloc(1);
    memset(message, 0, 1);
    message[0] = index;
    NSData *messageData = [NSData dataWithBytes:message length:1];

    NSData *data = [self appendTotalWallDataWithSystemCode:systemCode
                                                    IDdata:IDdata
                                                lengthData:lengthData
                                               messageData:messageData];
    [self writeData:data];
}

- (NSMutableData *)appendTotalWallDataWithSystemCode:(NSData *)systemCode
                                             IDdata:(NSData *)IDdata
                                         lengthData:(NSData *)lengthData
                                        messageData:(NSData *)messageData
{
    NSMutableData *data = [self appendTotalWallDataWithSectionID:[self sectionID]
                                                         orderID:[self dataFromHexString:@"0a10"]
                                                      systemCode:systemCode
                                                          IDdata:IDdata
                                                      lengthData:lengthData
                                                     messageData:messageData];
    return data;
}

- (NSMutableData *)appendTotalWallDataWithSectionID:(NSData *)sectionID
                                       orderID:(NSData *)orderID
                                    systemCode:(NSData *)systemCode
                                        IDdata:(NSData *)IDdata
                                    lengthData:(NSData *)lengthData
                                   messageData:(NSData *)messageData
{
    NSMutableData *body = [NSMutableData data];
    [body appendData:systemCode];
    [body appendData:IDdata];
    [body appendData:lengthData];
    [body appendData:messageData];

    NSMutableData *header = [NSMutableData data];
    [header appendData:sectionID];
    [header appendData:orderID];
    [header appendData:[self dataLength:body.length]];

    [header appendData:body];

    return header;
}

- (void)parseRespondData
{
    NSData *data = [self readData];

    Data_Header header;
    uint8_t *bytes = (uint8_t *)data.bytes;
    memcpy(&header, bytes, sizeof(header));

    NSUInteger length = data.length;
    NSData *body = [data subdataWithRange:NSMakeRange(sizeof(header), length - sizeof(header))];

    switch (header.orderID & 0xff) {
        //手机授权
        case OrderID_Login:
            [self parseRespondBody:body];
            break;
        //VWAS透传
        case OrderID_VWAS:
            break;
        //查询系统配置信息
        case OrderID_ObtainSystemConfiguration:
            [self parseObtainSystemConfigurationRespondBody:body];
            break;
        //单元透传
        case OrderID_Unit:
            break;
        //开关机
        case OrderID_StartOrShutDown:
            [self parseRespondBody:body];
            break;
        //整墙透传
        case OrderID_Wall:
            break;
        default:
            break;
    }
}

- (void)parseRespondBody:(NSData *)body
{
    uint16_t result = (uint16_t )body.bytes;

    if ((result & 0xffff) == 0x0000) {
        NSLog(@"操作成功！");
    } else {
        NSLog(@"操作失败！");
    }
}

- (void)parseObtainSystemConfigurationRespondBody:(NSData *)body
{
    uint16_t result = (uint16_t)[body subdataWithRange:NSMakeRange(0, 2)].bytes;
    if ((result & 0xffff) == 0x0000) {
        NSLog(@"操作成功！");
    } else {
        NSLog(@"操作失败！");
    }

    uint32_t count = (uint32_t)[body subdataWithRange:NSMakeRange(2, 4)].bytes;
    NSUInteger loc = 6;
    NSUInteger len = 4;
    for (uint32_t i = 0; i < count; i++) {
        //系统号
        uint32_t system = (uint32_t)[body subdataWithRange:NSMakeRange(loc, len)].bytes;
        loc = loc + len;
        NSLog(@"系统号：%u", system);

        //行数
        uint32_t line = (uint32_t)[body subdataWithRange:NSMakeRange(loc, len)].bytes;
        loc = loc + len;
        NSLog(@"行数：%u", line);

        //列数
        uint32_t row = (uint32_t)[body subdataWithRange:NSMakeRange(loc, len)].bytes;
        loc = loc + len;
        NSLog(@"列数：%u", row);
    }
}

- (NSData *)dataFromHexString:(NSString *)str {
    const char *chars = [str UTF8String];
    NSUInteger i = 0, len = str.length;

    NSMutableData *data = [NSMutableData dataWithCapacity:len / 2];
    char byteChars[3] = {'\0','\0','\0'};
    unsigned long wholeByte;

    while (i < len) {
        byteChars[0] = chars[i++];
        byteChars[1] = chars[i++];
        wholeByte = strtoul(byteChars, NULL, 16);
        [data appendBytes:&wholeByte length:1];
    }

    return data;
}

- (NSData *)sectionID
{
    unsigned char *sectionID = malloc(4);
    memset(sectionID, 0, 4);

    sectionID[0] = 0x00;
    sectionID[1] = 0x01;
    sectionID[2] = 0x00;
    sectionID[3] = 0x01;

    NSData *data = [NSData dataWithBytes:sectionID length:4];
    return data;
}

//小端字节
- (NSData *)dataLength:(NSUInteger)length byteCount:(NSUInteger)count
{
    unsigned char *body = malloc(count);
    memset(body, 0, count);
    
    body[0] = (length >> 24) & 0xff;
    body[1] = (length >> 16) & 0xff;
    body[2] = (length >> 8) & 0xff;
    body[3] = length & 0xff;
    
    NSData *data = [NSData dataWithBytes:body length:count];
    return data;
}

//大端字节
- (NSData *)dataLength:(NSUInteger)length
{
    unsigned char *body = malloc(4);
    memset(body, 0, 4);
    
    body[0] = length & 0xff;
    body[1] = (length >> 8) & 0xff;
    body[2] = (length >> 16) & 0xff;
    body[3] = (length >> 24) & 0xff;
    
    NSData *data = [NSData dataWithBytes:body length:4];
    return data;
}

- (NSData *)startData
{
    unsigned char *body = malloc(4);
    //起始符
    body[0] = 0xBB;
    body[1] = 0xBB;
    body[2] = 0xBB;
    body[3] = 0xBB;

    NSData *data = [NSData dataWithBytes:body length:4];
    return data;
}

- (NSData *)endData
{
    unsigned char *body = malloc(4);
    //结束符
    body[0] = 0xDD;
    body[1] = 0xDD;
    body[2] = 0xDD;
    body[3] = 0xDD;

    NSData *data = [NSData dataWithBytes:body length:4];
    return data;
}

@end
