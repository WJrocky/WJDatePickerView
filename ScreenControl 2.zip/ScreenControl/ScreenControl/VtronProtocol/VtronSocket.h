//
//  VtronSocket.h
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VtronSocket : NSObject

- (void)connectToHost:(NSString *)host port:(UInt32)port;
- (NSData *)readData;
- (NSInteger)writeData:(NSData *)data;

@end
