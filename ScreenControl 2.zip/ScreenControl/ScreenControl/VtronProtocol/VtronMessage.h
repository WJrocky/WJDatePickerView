//
//  VtronMessage.h
//  ScreenControl
//
//  Created by 王健 on 2017/9/27.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#ifndef VtronMessage_h
#define VtronMessage_h

#pragma pack(push, 1) //字节对齐 为1

typedef struct {
    uint
    
}VWASBODY;

#pragma pack(pop)//恢复字节对齐

#endif /* VtronMessage_h */
