//
//  VtronSession.h
//  ScreenControl
//
//  Created by wangjian on 25/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol VtronSessionDelegate <NSObject>

@optional
- (void)sessionPreparedForWrite;
- (void)sessionDidReceivedData:(NSData *)data;
- (void)sessionDidReceivedData:(NSData *)data messageBody:(NSData *)body;

@end

@class VtronSocket;
@interface VtronSession : NSObject

@property (nonatomic, strong) NSString *mobile;
@property (nonatomic, assign) id<VtronSessionDelegate>delegate;
@property (nonatomic, strong,readonly) VtronSocket *socket;

+ (instancetype)sharedInstance;

@end
