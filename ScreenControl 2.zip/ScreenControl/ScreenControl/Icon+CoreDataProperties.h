//
//  Icon+CoreDataProperties.h
//  ScreenControl
//
//  Created by 王健 on 2017/9/23.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "Icon+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Icon (CoreDataProperties)

+ (NSFetchRequest<Icon *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *segueIdentifier;
@property (nullable, nonatomic, copy) NSString *iconImageName;
@property (nullable, nonatomic, copy) NSString *iconMenuName;
@property (nullable, nonatomic, copy) NSString *functionType;
@property (nonatomic) BOOL isFrequentlyUsed;

@end

NS_ASSUME_NONNULL_END
