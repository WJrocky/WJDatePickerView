//
//  LoginViewController.m
//  ScreenControl
//
//  Created by wangjian on 07/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "VtronSocket.h"
#import "HomeViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD/MBProgressHUD.h"

@interface LoginViewController ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *accountTextField;
@property (weak, nonatomic) IBOutlet UITextField *mobileTextField;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIButton *savePasswordButton;

@property (nonatomic, strong) NSUserDefaults *userDefaults;
@property (nonatomic, strong) VtronSocket *socket;

@end

@implementation LoginViewController

- (void)customizeAppearance
{
    NSDictionary *colorAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};

    NSAttributedString *accountPlaceholder = [[NSAttributedString alloc] initWithString:@"账号" attributes:colorAttributes];
    self.accountTextField.attributedPlaceholder = accountPlaceholder;

    NSAttributedString *mobilePlaceholder = [[NSAttributedString alloc] initWithString:@"手机" attributes:colorAttributes];
    self.mobileTextField.attributedPlaceholder = mobilePlaceholder;

    self.userDefaults = [NSUserDefaults standardUserDefaults];

    BOOL isSavedPassword = [self.userDefaults boolForKey:@"isSavedPassword"];
    NSString *username = [self.userDefaults valueForKey:@"username"];
    NSString *password = [self.userDefaults valueForKey:@"password"];
    if (10 == password.length) {
        self.loginButton.backgroundColor = [UIColor colorWithRed:190.0 / 255.0
                                                           green:58.0 / 255.0
                                                            blue:58.0 / 255.0
                                                           alpha:1.0];
    }

    [self.savePasswordButton setSelected:isSavedPassword];
    self.accountTextField.text = username;
    self.mobileTextField.text = password;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self customizeAppearance];
    
//    self.socket = [[VtronSocket alloc] init];
//    [self.socket connectToHost:@"172.16.129.100" port:12001];
}


#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (10 == textField.text.length) {
        //改变button颜色
        self.loginButton.backgroundColor = [UIColor colorWithRed:190.0 / 255.0
                                                           green:58.0 / 255.0
                                                            blue:58.0 / 255.0
                                                           alpha:1.0];
    } else if (textField.text.length > 10) {
        //这里可以做一个toast
        NSLog(@"手机号长度不能超出11位！");
        return NO;
    }
    return YES;
}

- (IBAction)savePasswordButtonAction:(UIButton *)sender {
    sender.selected = !sender.selected;
    [self.userDefaults setBool:sender.selected forKey:@"isSavedPassword"];
}

- (IBAction)loginButtonAction:(UIButton *)sender {

    [self.userDefaults setValue:self.accountTextField.text forKey:@"username"];

    BOOL isSavedPassword = [self.userDefaults boolForKey:@"isSavedPassword"];

    if (isSavedPassword) {
        [self.userDefaults setValue:self.mobileTextField.text forKey:@"password"];
    } else {
        [self.userDefaults setValue:@"" forKey:@"password"];
    }

    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"loading";

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle:nil];
        HomeViewController *homeViewController = [storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [self.navigationController setViewControllers:@[homeViewController]];
    });
}

- (IBAction)changePasswordStateAction:(UIButton *)sender {
    self.mobileTextField.secureTextEntry = !self.mobileTextField.secureTextEntry;
    sender.selected = !sender.selected;
}

@end
