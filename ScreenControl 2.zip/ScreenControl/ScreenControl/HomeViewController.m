//
//  HomeViewController.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "HomeItemCell.h"
#import "FoldItemsCell.h"
#import "MagicalRecord.h"
#import "PresentationView.h"
#import "PopViewController.h"
#import "Icon+CoreDataClass.h"
#import "HomeViewController.h"
#import "MoreViewController.h"
#import "DetailViewController.h"
#import "PresentationController.h"
#import "BlurContainerController.h"

@interface HomeViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;

@property (nonatomic, assign) BOOL isPop;
@property (nonatomic, assign) CGPoint center;
@property (nonatomic, assign) CGPoint startPoint;
@property (nonatomic, weak) HomeItemCell *selectedCell;
@property (nonatomic, strong) NSMutableArray *iconDataArray;
@property (nonatomic, assign) BOOL isContain;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.isContain = NO;

    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
    [self.functionCollectionView addGestureRecognizer:longPressGesture];

    self.iconDataArray = [[Icon MR_findByAttribute:@"functionType" withValue:@"常用功能"] mutableCopy];
    
    Icon *moreIcon = [[Icon MR_findByAttribute:@"functionType" withValue:@"更多"] firstObject];
    
    [self.iconDataArray addObject:moreIcon];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    //追加一个常用功能
    return self.iconDataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    id model = [self.iconDataArray objectAtIndex:indexPath.item];
    if ([model isKindOfClass:[Icon class]]) {
        HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
        [cell loadData:model];
        return cell;
    } else  {
        FoldItemsCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"FoldItemsCell" forIndexPath:indexPath];
        [cell loadData:model];
        return cell;
    }
}

- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{
    [self.iconDataArray exchangeObjectAtIndex:sourceIndexPath.item withObjectAtIndex:destinationIndexPath.item];
}

#pragma mark - UICollectionViewDelegateFlowLayout

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    id model = [self.iconDataArray objectAtIndex:indexPath.item];
    if ([model isKindOfClass:[Icon class]]) {
        if (((Icon *)model).segueIdentifier.length != 0) {
            [self performSegueWithIdentifier:((Icon *)model).segueIdentifier sender:model];
        }
    } else {

        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle:nil];
        PopViewController *popViewController = [storyboard instantiateViewControllerWithIdentifier:@"PopViewController"];

        [popViewController view];

        UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
        
        [keyWindow addSubview:popViewController.view];
        [self addChildViewController:popViewController];

        [popViewController setCellRemovedBlock:^{
            self.isContain = NO;
            self.isPop = NO;
            [self.functionCollectionView reloadData];
        }];

        popViewController.view.alpha = 0.0;

        [popViewController loadData:model];

        [UIView animateWithDuration:0.3 animations:^{
            popViewController.view.alpha = 1.0;
        }];
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    Icon *model = sender;
    UIViewController *controller = segue.destinationViewController;
    if ([controller isKindOfClass:[DetailViewController class]]) {
        ((DetailViewController *)controller).model = model;
    }
}

- (void)longPressAction:(UILongPressGestureRecognizer *)gesture
{
    CGPoint point = [gesture locationInView:self.functionCollectionView];

    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            if (!indexPath) {
                break;
            }
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];
            self.center = cell.center;
            self.startPoint = point;
            point = cell.center;
            [self.functionCollectionView beginInteractiveMovementForItemAtIndexPath:indexPath];
            self.selectedCell = cell;
        }
            break;

        case UIGestureRecognizerStateChanged:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];

            point = CGPointMake(self.center.x + point.x - self.startPoint.x, self.center.y + point.y - self.startPoint.y);
            CGRect rect = CGRectMake(cell.center.x - 8, cell.center.y - 8, 16, 16);
            if (CGRectContainsPoint(rect, point) && (self.selectedCell != cell)) {
                //弹出遮幕
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (CGRectContainsPoint(rect, point)) {
                        if (!self.isPop && self.isContain) {
                            self.isPop = YES;

                            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                                                 bundle:nil];
                            PopViewController *popViewController = [storyboard instantiateViewControllerWithIdentifier:@"PopViewController"];

                            [popViewController view];

                            UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];

                            [keyWindow addSubview:popViewController.view];
                            [self addChildViewController:popViewController];

                            [popViewController setCellRemovedBlock:^{
                                self.isPop = NO;
                                self.isContain = NO;

                                [self.functionCollectionView reloadData];
                            }];

                            popViewController.view.alpha = 0.0;

                            [UIView animateWithDuration:0.3 animations:^{
                                popViewController.view.alpha = 1.0;
                            }];

                            NSIndexPath *selectedIndexPath = [self.functionCollectionView indexPathForCell:self.selectedCell];

                            id model = [self.iconDataArray objectAtIndex:indexPath.row];
                            if ([model isKindOfClass:[Icon class]]) {

                                NSMutableDictionary *multipleModel = [NSMutableDictionary dictionary];

                                NSMutableArray *models = [NSMutableArray array];
                                Icon *selectedModel = [self.iconDataArray objectAtIndex:selectedIndexPath.row];
                                [models addObject:selectedModel];
                                [models addObject:[self.iconDataArray objectAtIndex:indexPath.row]];

                                [multipleModel setValue:models forKey:selectedModel.iconMenuName];

                                [popViewController loadData:multipleModel];

                                [self.iconDataArray replaceObjectAtIndex:indexPath.row withObject:multipleModel];
                            } else {
                                NSArray *keys = [model allKeys];
                                NSMutableArray *models = [model valueForKey:[keys firstObject]];

                                [models addObject:[self.iconDataArray objectAtIndex:selectedIndexPath.row]];

                                [popViewController loadData:model];

                                [self.iconDataArray replaceObjectAtIndex:indexPath.row withObject:model];

                            }

                            [self.iconDataArray removeObjectAtIndex:selectedIndexPath.row];
                            [self.functionCollectionView deleteItemsAtIndexPaths:@[selectedIndexPath]];

                            [self.functionCollectionView reloadItemsAtIndexPaths:@[indexPath]];
                        }
                    }
                });
            }
            [self.functionCollectionView updateInteractiveMovementTargetPosition:point];
        }
            break;
        case UIGestureRecognizerStateEnded:
            [self.functionCollectionView endInteractiveMovement];
            break;
        default:
            [self.functionCollectionView cancelInteractiveMovement];
            break;
    }
}

- (NSIndexPath *)collectionView:(UICollectionView *)collectionView targetIndexPathForMoveFromItemAtIndexPath:(NSIndexPath *)originalIndexPath toProposedIndexPath:(NSIndexPath *)proposedIndexPath
{
    UICollectionViewCell *originalCell = [collectionView cellForItemAtIndexPath:originalIndexPath];
    UICollectionViewCell *proposedCell = [collectionView cellForItemAtIndexPath:proposedIndexPath];

    if (originalIndexPath != proposedIndexPath) {
        CGRect rect = CGRectMake(proposedCell.center.x - 6, proposedCell.center.y - 6, 12, 12);
        if (CGRectContainsPoint(rect, originalCell.center)) {
            self.isContain = YES;
        }

        if (self.isContain && !CGRectContainsPoint(rect, originalCell.center)) {
            self.isContain = NO;
            //可以移动
            return proposedIndexPath;
        }
    }
    //不可以移动
    return  originalIndexPath;
}

- (IBAction)moreBarButtonItemAction:(UIBarButtonItem *)sender {
    [self performSegueWithIdentifier:@"ShowMoreViewController" sender:nil];
}

@end
