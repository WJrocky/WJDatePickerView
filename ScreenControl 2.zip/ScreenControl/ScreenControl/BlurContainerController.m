//
//  BlurContainerController.m
//  ScreenControl
//
//  Created by wangjian on 11/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "HomeItemCell.h"
#import "BlurContainerController.h"

@interface BlurContainerController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UIGestureRecognizerDelegate, CAAnimationDelegate>

@property (weak, nonatomic) IBOutlet UIVisualEffectView *blurContainerView;
@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;

@property (nonatomic, assign) CGPoint center;
@property (nonatomic, assign) CGPoint startPoint;
@property (nonatomic, weak) HomeItemCell *selectedCell;
@property (nonatomic, copy) cellRemovedBlock cellRemovedBlock;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, assign) CGRect originalFrame;

@end

@implementation BlurContainerController

- (void)viewDidLoad {
    [super viewDidLoad];

    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
    longPressGesture.delegate = self;
    [self.functionCollectionView addGestureRecognizer:longPressGesture];
}

- (void)setBlurContainerViewOriginalFrame:(CGRect)frame
                           originalCenter:(CGPoint)originalCenter
{
    self.originalFrame = frame;
    self.blurContainerView.frame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, frame.size.width);
    self.functionCollectionView.frame = self.blurContainerView.bounds;

    CABasicAnimation *moveAnimation = [CABasicAnimation animationWithKeyPath:@"position"];
    moveAnimation.fromValue = [NSValue valueWithCGPoint:CGPointMake(frame.origin.x + frame.size.width / 2.0, frame.origin.y + frame.size.height / 2.0)];
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    moveAnimation.toValue = [NSValue valueWithCGPoint:CGPointMake(screenSize.width / 2.0, screenSize.height / 2.0)];

    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAnimation.fromValue = [NSNumber numberWithFloat:1.0];
    scaleAnimation.toValue = [NSNumber numberWithFloat:4.0];
    scaleAnimation.duration = 0.2f;

    CAAnimationGroup *animationGroup = [CAAnimationGroup animation];
    animationGroup.duration = 0.2f;
    animationGroup.autoreverses = NO;
    animationGroup.repeatCount = 1;
    animationGroup.removedOnCompletion = NO;
    animationGroup.fillMode = kCAFillModeForwards;
    animationGroup.delegate = self;
    [animationGroup setAnimations:@[moveAnimation,scaleAnimation]];

    [self.blurContainerView.layer addAnimation:animationGroup forKey:@"animationAppear"];
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    CAAnimation *animation = [self.blurContainerView.layer animationForKey:@"animationAppear"];
    if (animation) {
        CGSize screenSize = [UIScreen mainScreen].bounds.size;
        CGPoint screenCenter = CGPointMake(screenSize.width / 2.0, screenSize.height / 2.0);
        self.blurContainerView.frame = CGRectMake(screenCenter.x - 140, screenCenter.y - 140, 280, 280);
        self.functionCollectionView.frame = self.blurContainerView.bounds;

        self.dataArray = [NSMutableArray arrayWithObjects:@"1", @"2", @"3", nil];
        [self.functionCollectionView reloadData];
    } else {
        self.blurContainerView.frame = self.originalFrame;
        self.functionCollectionView.frame = self.blurContainerView.bounds;

        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }
     [self.blurContainerView.layer removeAllAnimations];
}


#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{

}

#pragma mark - UICollectionViewDelegateFlowLayout

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0.0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 10.0;
}

- (void)longPressAction:(UILongPressGestureRecognizer *)gesture
{
    CGPoint point = [gesture locationInView:self.functionCollectionView];

    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            if (!indexPath) {
                break;
            }
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];
            self.center = cell.center;
            self.startPoint = point;
            point = cell.center;
            [self.functionCollectionView beginInteractiveMovementForItemAtIndexPath:indexPath];
            self.selectedCell = cell;
        }
            break;

        case UIGestureRecognizerStateChanged:
        {
            point = CGPointMake(self.center.x + point.x - self.startPoint.x, self.center.y + point.y - self.startPoint.y);
            //先把坐标换算到同一坐标系中，nil默认为window，下面集中方法等效
            //[self.blurContainerView.superview convertRect:self.blurContainerView.frame toView:nil];
            //[Window convertRect:self.blurContainerView.frame fromView:self.blurContainerView.superview];
            //[Window convertRect:self.blurContainerView.bounds fromView:self.blurContainerView];
            CGRect containerViewRect = [self.blurContainerView convertRect:self.blurContainerView.bounds toView:nil];
            CGRect selectedCellRect = [self.selectedCell convertRect:self.selectedCell.bounds toView:nil];
            if (CGRectIntersectsRect(containerViewRect, selectedCellRect)) {
                [self.functionCollectionView updateInteractiveMovementTargetPosition:point];
            } else {
                NSLog(@"已经移除视图！");
                [self.view removeFromSuperview];
                [self removeFromParentViewController];
                if (self.cellRemovedBlock) {
                    self.cellRemovedBlock();
                }
            }
        }
            break;
        case UIGestureRecognizerStateEnded:
            [self.functionCollectionView endInteractiveMovement];
            break;
        default:
            [self.functionCollectionView cancelInteractiveMovement];
            break;
    }
}

- (IBAction)backgroundViewTapGesture:(UITapGestureRecognizer *)sender {
    self.blurBackgroundView.effect = nil;
    [self.dataArray removeAllObjects];
    [self.functionCollectionView reloadData];

    CABasicAnimation *moveAnimation = [CABasicAnimation animationWithKeyPath:@"position"];
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    moveAnimation.fromValue = [NSValue valueWithCGPoint:CGPointMake(screenSize.width / 2.0, screenSize.height / 2.0)];
    moveAnimation.toValue = [NSValue valueWithCGPoint:CGPointMake(self.originalFrame.origin.x + self.originalFrame.size.width / 2.0, self.originalFrame.origin.y + self.originalFrame.size.height / 2.0)];

    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAnimation.fromValue = [NSNumber numberWithFloat:1.0];
    scaleAnimation.toValue = [NSNumber numberWithFloat:0.25];
    scaleAnimation.duration = 0.2f;

    CAAnimationGroup *animationGroup = [CAAnimationGroup animation];
    animationGroup.duration = 0.2f;
    animationGroup.autoreverses = NO;
    animationGroup.repeatCount = 1;
    animationGroup.removedOnCompletion = NO;
    animationGroup.fillMode = kCAFillModeForwards;
    animationGroup.delegate = self;
    [animationGroup setAnimations:@[moveAnimation,scaleAnimation]];

    [self.blurContainerView.layer addAnimation:animationGroup forKey:@"animationDisappear"];

    if (self.cellRemovedBlock) {
        self.cellRemovedBlock();
    }
}

@end
