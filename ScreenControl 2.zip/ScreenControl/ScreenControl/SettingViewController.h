//
//  SettingViewController.h
//  ScreenControl
//
//  Created by wangjian on 12/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController

@end
