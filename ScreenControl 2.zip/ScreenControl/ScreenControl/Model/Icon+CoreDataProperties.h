//
//  Icon+CoreDataProperties.h
//  ScreenControl
//
//  Created by 王健 on 2017/9/28.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "Icon+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Icon (CoreDataProperties)

+ (NSFetchRequest<Icon *> *)fetchRequest;

@property (nonatomic) BOOL canRemove;
@property (nullable, nonatomic, copy) NSString *fileName;
@property (nullable, nonatomic, copy) NSString *functionType;
@property (nullable, nonatomic, copy) NSString *iconImageName;
@property (nullable, nonatomic, retain) NSData *iconMenuName;
@property (nonatomic) BOOL isFrequentlyUsed;
@property (nullable, nonatomic, copy) NSString *segueIdentifier;
@property (nonatomic) int16_t serialnumber;
@property (nullable, nonatomic, copy) NSString *stateImageName;
@property (nonatomic) int16_t index;

@end

NS_ASSUME_NONNULL_END
