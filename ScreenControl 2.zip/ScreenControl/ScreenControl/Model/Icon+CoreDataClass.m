//
//  Icon+CoreDataClass.m
//  ScreenControl
//
//  Created by wangjian on 26/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "Icon+CoreDataClass.h"

@implementation Icon

@end
