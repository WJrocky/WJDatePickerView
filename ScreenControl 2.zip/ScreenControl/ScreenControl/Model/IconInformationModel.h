//
//  IconInformationModel.h
//  ScreenControl
//
//  Created by wangjian on 12/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IconInformationModel : NSObject

@property (nonatomic, copy) NSString *iconClassName;
@property (nonatomic, copy) NSString *iconImageName;
@property (nonatomic, copy) NSString *iconMenuName;
@property (nonatomic, copy) NSString *segueIdentifier;
@property (nonatomic, strong) NSMutableArray *subIconModels;

@end
