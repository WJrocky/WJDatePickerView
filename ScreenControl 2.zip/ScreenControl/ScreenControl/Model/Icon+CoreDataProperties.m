//
//  Icon+CoreDataProperties.m
//  ScreenControl
//
//  Created by wangjian on 26/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "Icon+CoreDataProperties.h"

@implementation Icon (CoreDataProperties)

+ (NSFetchRequest<Icon *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Icon"];
}

@dynamic functionType;
@dynamic iconImageName;
@dynamic iconMenuName;
@dynamic isFrequentlyUsed;
@dynamic segueIdentifier;
@dynamic serialnumber;
@dynamic stateImageName;
@dynamic fileName;

@end
