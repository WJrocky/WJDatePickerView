//
//  RuntimeData.m
//  ScreenControl
//
//  Created by 王健 on 2017/9/23.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "RuntimeData.h"

@interface RuntimeData ()

@end

@implementation RuntimeData

+ (instancetype)sharedInstance
{
    static RuntimeData *sharedData = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedData = [[self alloc] init];
    });
    return sharedData;
}

- (void)initAllFunctionArray
{
    self.allFunctions = [[self loadPlistArrayWithName:@"MoreFunction" type:@"plist"] mutableCopy];
}

- (void)initFrequentlyFunctions
{
    self.frequentlyFunctions = [[self loadPlistArrayWithName:@"HomeFunction" type:@"plist"] mutableCopy];
}

- (NSArray *)loadPlistArrayWithName:(NSString *)name type:(NSString *)type
{
    NSString *path = [[NSBundle mainBundle] pathForResource:name ofType:type];
    NSArray *tempArray = [NSArray arrayWithContentsOfFile:path];
    return tempArray;
}

@end
