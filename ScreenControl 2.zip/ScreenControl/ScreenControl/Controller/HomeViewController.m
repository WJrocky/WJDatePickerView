//
//  HomeViewController.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "RuntimeData.h"
#import "VtronSession.h"
#import "HomeItemCell.h"
#import "MBProgressHUD.h"
#import "FoldItemsCell.h"
#import "MagicalRecord.h"
#import "PresentationView.h"
#import "PopViewController.h"
#import "Icon+CoreDataClass.h"
#import "HomeViewController.h"
#import "MoreViewController.h"
#import "VtronSocket+Protocol.h"
#import "DetailViewController.h"

@interface HomeViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, VtronSessionDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;

@property (nonatomic, assign) BOOL isPop;
@property (nonatomic, assign) CGPoint center;
@property (nonatomic, assign) CGPoint startPoint;
@property (nonatomic, weak) HomeItemCell *selectedCell;
@property (nonatomic, strong) NSMutableArray *iconDataArray;
@property (nonatomic, assign) BOOL isContain;
@property (nonatomic, strong) NSUserDefaults *userDefaults;
@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, assign) BOOL canExchange;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.isContain = NO;
    self.canExchange = YES;

    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
    [self.functionCollectionView addGestureRecognizer:longPressGesture];

    self.userDefaults = [NSUserDefaults standardUserDefaults];

    [self initDataSourece];

    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;

    [self.session.socket sendObtainSystemConfigurationMessage];;
}

- (void)initDataSourece
{
    self.iconDataArray = [[Icon MR_findByAttribute:@"isFrequentlyUsed" withValue:[NSNumber numberWithBool:YES]]mutableCopy];
    [self.iconDataArray sortUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"serialnumber" ascending:YES]]];

    NSString *fileName = [self.userDefaults valueForKey:@"filename"];
    NSArray *fileNames = [fileName componentsSeparatedByString:@"-"];
    for (NSString *name in fileNames) {
        NSMutableArray *files = [[Icon MR_findByAttribute:@"fileName" withValue:name] mutableCopy];
        NSMutableDictionary *dictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:files, name, nil];
        [self.iconDataArray removeObjectsInArray:files];
        Icon *model = [files firstObject];
        [self.iconDataArray insertObject:dictionary atIndex:model.serialnumber];
    }

    Icon *moreIcon = [[Icon MR_findByAttribute:@"functionType" withValue:@"更多"] firstObject];

    [self.iconDataArray addObject:moreIcon];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    //追加一个常用功能
    return self.iconDataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    id model = [self.iconDataArray objectAtIndex:indexPath.item];
    if ([model isKindOfClass:[Icon class]]) {
        HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
        [cell loadData:model];
        return cell;
    } else  {
        FoldItemsCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"FoldItemsCell" forIndexPath:indexPath];
        [cell loadData:model];
        return cell;
    }
}

- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{
    if (self.canExchange) {
        if (sourceIndexPath.row < self.iconDataArray.count && destinationIndexPath.row < self.iconDataArray.count) {
            id sourceModel = [self.iconDataArray objectAtIndex:sourceIndexPath.row];
            id destinationModel = [self.iconDataArray objectAtIndex:destinationIndexPath.row];
            NSInteger sourceRow = sourceIndexPath.row;
            NSInteger destinationRow = destinationIndexPath.row;
            if ([sourceModel isKindOfClass:[Icon class]]) {

                if ([destinationModel isKindOfClass:[NSDictionary class]]) {
                    NSArray *destinationkeys = [destinationModel allKeys];
                    NSArray *destinationicons = [destinationModel objectForKey:[destinationkeys firstObject]];
                    for (Icon *icon in destinationicons) {
                        icon.serialnumber = sourceRow;
                    }
                } else {
                    ((Icon *)destinationModel).serialnumber = sourceRow;
                }
                ((Icon *)sourceModel).serialnumber = destinationRow;
            } else {
                NSArray *sourcekeys = [sourceModel allKeys];
                NSArray *sourceIcons = [sourceModel objectForKey:[sourcekeys firstObject]];

                if ([destinationModel isKindOfClass:[NSDictionary class]]) {
                    NSArray *destinationKeys = [destinationModel allKeys];
                    NSArray *destinationIcons = [destinationModel objectForKey:[destinationKeys firstObject]];
                    for (Icon *icon in destinationIcons) {
                        icon.serialnumber = sourceRow;
                    }
                } else {
                    ((Icon *)destinationModel).serialnumber = sourceRow;
                }

                for (Icon *icon in sourceIcons) {
                    icon.serialnumber = destinationRow;
                }
            }

            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
            [self.iconDataArray exchangeObjectAtIndex:sourceIndexPath.item withObjectAtIndex:destinationIndexPath.item];
        }
    }
    self.canExchange = YES;
}

#pragma mark - UICollectionViewDelegateFlowLayout

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    id model = [self.iconDataArray objectAtIndex:indexPath.item];
    if ([model isKindOfClass:[Icon class]]) {
        if (((Icon *)model).segueIdentifier.length != 0) {
            [self performSegueWithIdentifier:((Icon *)model).segueIdentifier sender:model];
        } else if ([((Icon *)model).iconMenuName isEqualToData:[self dataFromHexString:@"bfaabbfa"]]) {

            //开机
            [self.session.socket sendStartOrShutDownMessage:1];

        } else if ([((Icon *)model).iconMenuName isEqualToData:[self dataFromHexString:@"b9d8bbfa"]]) {

            //关机
            [PresentationView popAlertViewFinishedBlock:nil WithConfirmBlock:^{
                [self.session.socket sendStartOrShutDownMessage:0];
            } cancelBlock:nil];
        } else if ([((Icon *)model).functionType isEqualToString:@"VWAS模式"]) {
            
            //VWAS模式传名称
            [self.session.socket sendStartVWASModelMessage:((Icon *)model).iconMenuName];
            
        } else if ([((Icon *)model).functionType isEqualToString:@"光学模式"]) {
            
            //光学模式传编号
            [self.session.socket sendStartlightModelMessage:((Icon *)model).index];
            
        } else if ([((Icon *)model).functionType isEqualToString:@"设置桌面"]) {
            //设置桌面传编号
            [self.session.socket sendSettingDesktopMessage:((Icon *)model).index];
        }
    } else {
        PopViewController *popViewController = [self addPopViewController:indexPath];

        [popViewController loadData:model];
    }
}

- (PopViewController *)addPopViewController:(NSIndexPath *)indexPath
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                         bundle:nil];
    PopViewController *popViewController = [storyboard instantiateViewControllerWithIdentifier:@"PopViewController"];

    [popViewController view];

    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];

    [keyWindow addSubview:popViewController.view];
    [self addChildViewController:popViewController];

    [popViewController setCellRemovedBlock:^(Icon *removedModel, NSMutableDictionary *dictionary) {
        self.isPop = NO;
        self.isContain = NO;

        NSArray *keys = [dictionary allKeys];

        if (removedModel) {
            NSArray *models = [dictionary valueForKey:[keys firstObject]];
            if (0 == models.count) {
                [self.userDefaults removeObjectForKey:@"filename"];
                [self.iconDataArray removeObjectAtIndex:indexPath.row];
            }
            removedModel.fileName = nil;
            [self.iconDataArray insertObject:removedModel atIndex:self.iconDataArray.count - 1];
        }

        [UIView performWithoutAnimation:^{
            [self.functionCollectionView reloadData];
        }];
    }];

    popViewController.view.alpha = 0.0;

    [UIView animateWithDuration:0.3 animations:^{
        popViewController.view.alpha = 1.0;
    }];

    return popViewController;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    Icon *model = sender;
    UIViewController *controller = segue.destinationViewController;
    if ([controller isKindOfClass:[DetailViewController class]]) {
        ((DetailViewController *)controller).model = model;
    } else if ([controller isKindOfClass:[MoreViewController class]]) {
        [((MoreViewController *)controller) setFunctionChangeSuccess:^{
            //更新数据源
            [self initDataSourece];
            [self.functionCollectionView reloadData];
        }];
    }
}

- (void)longPressAction:(UILongPressGestureRecognizer *)gesture
{
    CGPoint point = [gesture locationInView:self.functionCollectionView];

    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            if (!indexPath || (indexPath.row == self.iconDataArray.count - 1)) {
                break;
            }
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];
            //创建动画
            CAKeyframeAnimation * keyAnimaion = [CAKeyframeAnimation animation];
            keyAnimaion.keyPath = @"transform.rotation";
            keyAnimaion.values = @[@(-10 / 180.0 * M_PI),@(10 /180.0 * M_PI),@(-10/ 180.0 * M_PI)];//度数转弧度
            
            keyAnimaion.removedOnCompletion = NO;
            keyAnimaion.fillMode = kCAFillModeForwards;
            keyAnimaion.duration = 0.2;
            keyAnimaion.repeatCount = MAXFLOAT;
            [cell.layer addAnimation:keyAnimaion forKey:@"rotation"];
 
            self.center = cell.center;
            self.startPoint = point;
            point = cell.center;
            [self.functionCollectionView beginInteractiveMovementForItemAtIndexPath:indexPath];
            self.selectedCell = cell;
        }
            break;

        case UIGestureRecognizerStateChanged:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];

            point = CGPointMake(self.center.x + point.x - self.startPoint.x, self.center.y + point.y - self.startPoint.y);
            CGRect rect = CGRectMake(cell.center.x - 8, cell.center.y - 8, 16, 16);
            if (CGRectContainsPoint(rect, point) && (self.selectedCell != cell)) {
                //弹出遮幕
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (CGRectContainsPoint(rect, point)) {
                        if (!self.isPop && self.isContain) {
                            self.isPop = YES;
                            self.canExchange = NO;
                            PopViewController *popViewController = [self addPopViewController:indexPath];

                            NSIndexPath *selectedIndexPath = [self.functionCollectionView indexPathForCell:self.selectedCell];

                            id model = [self.iconDataArray objectAtIndex:indexPath.row];
                            if ([model isKindOfClass:[Icon class]]) {

                                NSMutableDictionary *multipleModel = [NSMutableDictionary dictionary];

                                NSMutableArray *models = [NSMutableArray array];
                                Icon *selectedModel = [self.iconDataArray objectAtIndex:selectedIndexPath.row];
                                Icon *model = [self.iconDataArray objectAtIndex:indexPath.row];
                                if (0 == model.fileName.length) {
                                    model.fileName = model.iconMenuName;
                                }
                                selectedModel.fileName = model.fileName;
                                model.serialnumber = indexPath.row;
                                selectedModel.serialnumber = indexPath.row;

                                [models addObject:selectedModel];
                                [models addObject:[self.iconDataArray objectAtIndex:indexPath.row]];

                                [multipleModel setValue:models forKey:model.fileName];

                                NSString *fileName = [self.userDefaults valueForKey:@"filename"];

                                if (fileName.length != 0) {
                                    fileName = [NSString stringWithFormat:@"%@-%@",fileName,model.fileName];
                                } else {
                                    fileName = model.fileName;
                                }
                                [self.userDefaults setValue:fileName forKey:@"filename"];

                                [popViewController loadData:multipleModel];

                                [self.iconDataArray replaceObjectAtIndex:indexPath.row withObject:multipleModel];

                                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                            } else {
                                NSArray *keys = [model allKeys];
                                NSString *fileName = [keys firstObject];
                                NSMutableArray *models = [model valueForKey:fileName];

                                Icon *selectedModel = [self.iconDataArray objectAtIndex:selectedIndexPath.row];

                                selectedModel.fileName = fileName;
                                selectedModel.serialnumber = indexPath.row;

                                [models addObject:selectedModel];

                                [popViewController loadData:model];

                                [self.iconDataArray replaceObjectAtIndex:indexPath.row withObject:model];

                                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                            }

                            [self.iconDataArray removeObjectAtIndex:selectedIndexPath.row];
                            [self.functionCollectionView deleteItemsAtIndexPaths:@[selectedIndexPath]];

                            [self.functionCollectionView reloadItemsAtIndexPaths:@[indexPath]];
                        }
                    }
                });
            }
            [self.functionCollectionView updateInteractiveMovementTargetPosition:point];
        }
            break;
        case UIGestureRecognizerStateEnded:
            [self.selectedCell.layer removeAnimationForKey:@"rotation"];
            [self.functionCollectionView endInteractiveMovement];
            break;
        default:
            [self.selectedCell.layer removeAnimationForKey:@"rotation"];
            [self.functionCollectionView cancelInteractiveMovement];
            break;
    }
}

- (NSIndexPath *)collectionView:(UICollectionView *)collectionView targetIndexPathForMoveFromItemAtIndexPath:(NSIndexPath *)originalIndexPath toProposedIndexPath:(NSIndexPath *)proposedIndexPath
{
    UICollectionViewCell *originalCell = [collectionView cellForItemAtIndexPath:originalIndexPath];
    UICollectionViewCell *proposedCell = [collectionView cellForItemAtIndexPath:proposedIndexPath];

    if (originalIndexPath != proposedIndexPath) {
        CGRect rect = CGRectMake(proposedCell.center.x - 6, proposedCell.center.y - 6, 12, 12);
        if (CGRectContainsPoint(rect, originalCell.center)) {
            self.isContain = YES;
        }

        if (self.isContain && !CGRectContainsPoint(rect, originalCell.center)) {
            self.isContain = NO;
            //可以移动
            return proposedIndexPath;
        }
    }
    //不可以移动
    return  originalIndexPath;
}

- (IBAction)moreBarButtonItemAction:(UIBarButtonItem *)sender {
    [self performSegueWithIdentifier:@"ShowMoreViewController" sender:nil];
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidReceivedData:(NSData *)data
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
    if ([orderData isEqualToData:[self dataFromHexString:@"0510"]]) {
        NSData *messageData = [data subdataWithRange:NSMakeRange(10, data.length - 10)];
        NSData *systemCountData = [messageData subdataWithRange:NSMakeRange(2, 4)];
        NSData *systemListData = [messageData subdataWithRange:NSMakeRange(6, messageData.length - 6)];
        NSUInteger systemCount = [self valueOfBigUint32_t:(uint8_t *)systemCountData.bytes];
        NSUInteger index = 0;
        NSMutableArray *tempArray = [NSMutableArray array];
        for (int i = 0; i < systemCount; i++) {
            NSData *systemInformationData = [systemListData subdataWithRange:NSMakeRange(index, 12)];
            [tempArray addObject:systemInformationData];
            NSData *systemCodeData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
            NSLog(@"systemCode = %d", [self valueOfBigUint32_t:(uint8_t *)systemCodeData.bytes]);
            index += 4;
            NSData *lineData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
            NSLog(@"line = %d", [self valueOfBigUint32_t:(uint8_t *)lineData.bytes]);
            index += 4;
            NSData *rowData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
            NSLog(@"row = %d", [self valueOfBigUint32_t:(uint8_t *)rowData.bytes]);
            index += 4;
        }
        [RuntimeData sharedInstance].systemDataList = [tempArray copy];
        [RuntimeData sharedInstance].selectedSystemData = [tempArray firstObject];
    }
}

- (void)sessionDidSendData:(NSData *)data
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"loading";
}

@end
