//
//  DetailViewController.m
//  ScreenControl
//
//  Created by wangjian on 13/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "VtronSession.h"
#import "HomeItemCell.h"
#import "MagicalRecord.h"
#import "DetailViewController.h"
#import "VtronSocket+Protocol.h"

@interface DetailViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, VtronSessionDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (nonatomic, strong) NSArray *icons;
@property (nonatomic, strong) VtronSession *session;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);

    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;

    self.title = self.model.iconMenuName;
    
    self.icons = [Icon MR_findByAttribute:@"functionType" withValue:self.model.iconMenuName];
    
    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;
    
    if ([self.model.iconMenuName isEqualToString:@"VWAS模式"]) {
        [self.session.socket sendObtainVWASModelListMessage];
    } else if ([self.model.iconMenuName isEqualToString:@"光学模式"]) {
        for (int i = 0; i < 1; i++) {
            [self.session.socket sendObtainLightModelMessage:i];
        }
    }
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.icons.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];
    [cell loadData:[self.icons objectAtIndex:indexPath.item]];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [self.session.socket sendSettingDesktopMessage:indexPath.row];
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidReceivedData:(NSData *)data
{
    NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
    if ([orderData isEqualToData:[self dataFromHexString:@"0210"]]) {
        NSData *messageBody = [data subdataWithRange:NSMakeRange(10, data.length - 10)];
        
        //结果(可选)
        NSData *result = [messageBody subdataWithRange:NSMakeRange(16, messageBody.length - 16 - 4)];
        
        NSData *screenCountData = [result subdataWithRange:NSMakeRange(0, 4)];
        NSUInteger screenCount = [self valueOfUint32_t:(uint8_t *)screenCountData.bytes];
        
        NSData *screenListData = [result subdataWithRange:NSMakeRange(4, result.length - 4)];
        NSUInteger count = 0;
        
        NSMutableArray *tempArray = [NSMutableArray array];
        //VWAS_DEFAULT_CLEARWALL,VWAS_DEFAULT_POWEROFF,VWAS_DEFAULT_POWERON需排除
        for (int i = 0; i < screenCount; i++) {
            NSData *screenNameLengthData = [screenListData subdataWithRange:NSMakeRange(count, 4)];
            count += 4;
            NSUInteger screenNameLength = [self valueOfUint32_t:(uint8_t *)screenNameLengthData.bytes];
            NSData *screenNameData = [screenListData subdataWithRange:NSMakeRange(count, screenNameLength)];
            count += screenNameLength;
            NSString *vwasName = [[NSString alloc] initWithData:screenNameData encoding:NSUTF8StringEncoding];
            NSLog(@"vwasName = %@", vwasName);
            [tempArray addObject:screenNameData];
        }
        
        [self.session.socket sendStartVWASModelMessage:[tempArray objectAtIndex:4]];
    } else if ([orderData isEqualToData:[self dataFromHexString:@"0b10"]]) {
        NSLog(@"桌面设置成功!");
    } else if ([orderData isEqualToData:[self dataFromHexString:@"0710"]]) {
        NSLog(@"获取光学模式成功!");
        [self.session.socket sendStartlightModelMessage:0];
    }
}

- (int)valueOfUint32_t:(uint8_t *)value
{
    return ((value[0] & 0xff) << 24) | ((value[1] & 0xff) << 16) | ((value[2] & 0xff) << 8) | (value[3] & 0xff);
}

- (NSData *)dataFromHexString:(NSString *)str {
    const char *chars = [str UTF8String];
    NSUInteger i = 0, len = str.length;
    
    NSMutableData *data = [NSMutableData dataWithCapacity:len / 2];
    char byteChars[3] = {'\0','\0','\0'};
    unsigned long wholeByte;
    
    while (i < len) {
        byteChars[0] = chars[i++];
        byteChars[1] = chars[i++];
        wholeByte = strtoul(byteChars, NULL, 16);
        [data appendBytes:&wholeByte length:1];
    }
    
    return data;
}

@end
