//
//  MoreViewController.h
//  ScreenControl
//
//  Created by wangjian on 11/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^FunctionsChangeSuccess)();
@interface MoreViewController : UIViewController

- (void)setFunctionChangeSuccess:(FunctionsChangeSuccess)functionChangeSuccess;

@end
