//
//  PopListController.h
//  ScreenControl
//
//  Created by 王健 on 2017/9/27.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopListController : UIViewController

- (void)loadData:(NSMutableArray *)data;

@end
