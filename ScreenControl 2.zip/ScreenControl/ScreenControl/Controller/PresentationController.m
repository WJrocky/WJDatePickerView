//
//  PresentationController.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "PresentationController.h"

@interface PresentationController ()

@property (nonatomic, strong) UIVisualEffectView *visualView;

@end

@implementation PresentationController

- (void)presentationTransitionWillBegin
{
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    self.visualView = [[UIVisualEffectView alloc] initWithEffect:blur];
    self.visualView.frame = self.containerView.bounds;

    self.visualView.alpha = 0.4;
    self.visualView.backgroundColor = [UIColor blackColor];

    [self.containerView addSubview:self.visualView];
}

- (void)presentationTransitionDidEnd:(BOOL)completed
{
    if (!completed) {
        [self.visualView removeFromSuperview];
    }
}

- (void)dismissalTransitionWillBegin
{
    self.visualView.alpha = 0.0;
}

- (void)dismissalTransitionDidEnd:(BOOL)completed
{
    if (!completed) {
        [self.visualView removeFromSuperview];
    }
}



@end
