//
//  NavigationController.m
//  ScreenControl
//
//  Created by wangjian on 14/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "NavigationController.h"

@interface NavigationController ()

@end

@implementation NavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    NSDictionary *colorAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
//    self.navigationController.navigationBar.titleTextAttributes = colorAttributes;
//
//    UIImage *backIndicatorImage = [UIImage imageNamed:@"navigationbar_back"];
//    [self.navigationBar setBackIndicatorImage:backIndicatorImage];
//    [self.navigationBar setBackIndicatorTransitionMaskImage:backIndicatorImage];
//    self.navigationBar.tintColor = [UIColor whiteColor];
//
//    UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
//    [rightButton setImage:backIndicatorImage forState:UIControlStateNormal];
//    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
//    self.navigationItem.rightBarButtonItem = rightItem;


}

- (void)backAction
{

}

@end
