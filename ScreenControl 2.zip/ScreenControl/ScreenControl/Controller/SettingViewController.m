//
//  SettingViewController.m
//  ScreenControl
//
//  Created by wangjian on 12/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "VtronSession.h"
#import "PopListController.h"
#import "VtronSocket+Protocol.h"
#import "SettingViewController.h"

@interface SettingViewController ()<UITextFieldDelegate, VtronSessionDelegate>

@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) NSMutableArray *walls;

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);
    
    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;
    
    self.walls = [NSMutableArray array];
    
    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;
    
    //    [self.session.socket sendObtainVWASWallNameMessage];
    //    [self.session.socket sendCloseAllWatchWallMachineMessage];
    //    [self.session.socket sendOpenAllWatchWallMachineMessage];
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)popListControllerAction:(UIButton *)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                         bundle:nil];
    PopListController *popListController = [storyboard instantiateViewControllerWithIdentifier:@"PopListController"];
    [popListController loadData:self.walls];
    
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    popListController.view.frame = [UIScreen mainScreen].bounds;
    
    [keyWindow addSubview:popListController.view];
    [self addChildViewController:popListController];
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidReceivedData:(NSData *)data
{
    NSData *messageBody = [data subdataWithRange:NSMakeRange(10, data.length - 10)];

    //结果(可选)
    NSData *result = [messageBody subdataWithRange:NSMakeRange(16, messageBody.length - 16 - 4)];

    NSData *screenCountData = [result subdataWithRange:NSMakeRange(0, 4)];
    NSUInteger screenCount = [self valueOfUint32_t:(uint8_t *)screenCountData.bytes];

    NSData *screenListData = [result subdataWithRange:NSMakeRange(4, result.length - 4)];
    NSUInteger count = 0;
    for (int i = 0; i < screenCount; i++) {
        NSData *screenNameLengthData = [screenListData subdataWithRange:NSMakeRange(count, 4)];
        count += 4;
        NSUInteger screenNameLength = [self valueOfUint32_t:(uint8_t *)screenNameLengthData.bytes];
        NSData *screenNameData = [screenListData subdataWithRange:NSMakeRange(count, screenNameLength)];
        count += screenNameLength;
        NSString *screenName = [[NSString alloc] initWithData:screenNameData encoding:NSUTF8StringEncoding];
        NSLog(@"screenName = %@", screenName);
        [self.walls addObject:screenNameData];
    }
}

//小端字节
- (int)valueOfUint32_t:(uint8_t *)value
{
    return ((value[0] & 0xff) << 24) | ((value[1] & 0xff) << 16) | ((value[2] & 0xff) << 8) | (value[3] & 0xff);
}

@end
