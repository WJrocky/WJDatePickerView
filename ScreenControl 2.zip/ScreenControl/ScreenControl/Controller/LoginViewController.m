//
//  LoginViewController.m
//  ScreenControl
//
//  Created by wangjian on 07/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "MagicalRecord.h"
#import "Icon+CoreDataClass.h"
#import "UIView+Toast.h"
#import "RuntimeData.h"
#import "VtronSocket.h"
#import "VtronSession.h"
#import "MBProgressHUD.h"
#import "HomeViewController.h"
#import "LoginViewController.h"
#import "VtronSocket+Protocol.h"

@interface LoginViewController ()<UITextFieldDelegate, VtronSessionDelegate>

@property (weak, nonatomic) IBOutlet UITextField *accountTextField;
@property (weak, nonatomic) IBOutlet UITextField *mobileTextField;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIButton *savePasswordButton;
@property (weak, nonatomic) IBOutlet UIButton *isStubButton;

@property (nonatomic, strong) NSUserDefaults *userDefaults;
@property (nonatomic, strong) VtronSocket *socket;
@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) NSMutableArray *lightModelList;

@end

@implementation LoginViewController

- (void)customizeAppearance
{
    NSDictionary *colorAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};

    NSAttributedString *accountPlaceholder = [[NSAttributedString alloc] initWithString:@"账号" attributes:colorAttributes];
    self.accountTextField.attributedPlaceholder = accountPlaceholder;

    NSAttributedString *mobilePlaceholder = [[NSAttributedString alloc] initWithString:@"手机" attributes:colorAttributes];
    self.mobileTextField.attributedPlaceholder = mobilePlaceholder;

    self.userDefaults = [NSUserDefaults standardUserDefaults];

    BOOL isSavedPassword = [self.userDefaults boolForKey:@"isSavedPassword"];
    NSString *username = [self.userDefaults valueForKey:@"username"];
    NSString *password = [self.userDefaults valueForKey:@"password"];
    if (10 == password.length) {
        self.loginButton.backgroundColor = [UIColor colorWithRed:190.0 / 255.0
                                                           green:58.0 / 255.0
                                                            blue:58.0 / 255.0
                                                           alpha:1.0];
    }

    [self.savePasswordButton setSelected:isSavedPassword];
    self.accountTextField.text = username;
    self.mobileTextField.text = password;

    BOOL isReleaseVersion = [self.userDefaults boolForKey:@"isReleaseVersion"];
    [self.isStubButton setSelected:isReleaseVersion];
    
    self.lightModelList = [NSMutableArray array];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self customizeAppearance];

    self.session = [VtronSession sharedInstance];
    self.session.delegate = self;
}


#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (10 == textField.text.length) {
        //改变button颜色
        self.loginButton.backgroundColor = [UIColor colorWithRed:190.0 / 255.0
                                                           green:58.0 / 255.0
                                                            blue:58.0 / 255.0
                                                           alpha:1.0];
    } else if (textField.text.length > 10) {
        //这里可以做一个toast
        NSLog(@"手机号长度不能超出11位！");
        return NO;
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)savePasswordButtonAction:(UIButton *)sender {
    sender.selected = !sender.selected;
    [self.userDefaults setBool:sender.selected forKey:@"isSavedPassword"];
}

- (IBAction)loginButtonAction:(UIButton *)sender {

    [self.userDefaults setValue:self.accountTextField.text forKey:@"username"];

    BOOL isSavedPassword = [self.userDefaults boolForKey:@"isSavedPassword"];

    if (isSavedPassword) {
        [self.userDefaults setValue:self.mobileTextField.text forKey:@"password"];
    } else {
        [self.userDefaults setValue:@"" forKey:@"password"];
    }

    [self.session.socket sendLoginMessage:self.mobileTextField.text];
}

- (IBAction)changePasswordStateAction:(UIButton *)sender {
    self.mobileTextField.secureTextEntry = !self.mobileTextField.secureTextEntry;
    sender.selected = !sender.selected;
}

- (IBAction)changeVersionAction:(UIButton *)sender {
    sender.selected = !sender.selected;
    [self.userDefaults setBool:sender.selected forKey:@"isReleaseVersion"];
}

#pragma mark - VtronSessionDelegate
- (void)sessionDidReceivedData:(NSData *)data
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    if (data.length >= 12) {
        NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
        //授权返回报文
        if ([orderData isEqualToData:[self dataFromHexString:@"0110"]]) {

            NSData *result = [data subdataWithRange:NSMakeRange(10, 2)];
            if ([result isEqualToData:[self dataFromHexString:@"0000"]]) {
                //查询系统配置
                [self.session.socket sendObtainSystemConfigurationMessage];
            } else {
                [self.view makeToast:@"手机授权失败！"];
            }

        //查询系统配置返回报文
        } else if ([orderData isEqualToData:[self dataFromHexString:@"0510"]]) {

            [self parseObtainSystemConfigurationRespondData:data];
            
        //获取VWAS模式列表返回报文
        } else if ([orderData isEqualToData:[self dataFromHexString:@"0310"]]) {

            [self parseObtainVWASModelListData:data];

        //获取光学模式名称返回报文
        } else if ([orderData isEqualToData:[self dataFromHexString:@"0710"]]) {

            [self parseObtainLightModelListData:data];
        }
    }

    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isReleaseVersion = [userDefaults boolForKey:@"isReleaseVersion"];

    if (!isReleaseVersion) {
        [self showHomeViewController];
    }
}

- (void)sessionDidSendData:(NSData *)data
{
    NSString *message = nil;
    if (data.length >= 6) {
        NSData *orderData = [data subdataWithRange:NSMakeRange(4, 2)];
        if ([orderData isEqualToData:[self dataFromHexString:@"0010"]]) {
            message = @"手机授权";
        } else if ([orderData isEqualToData:[self dataFromHexString:@"0410"]]) {
            message = @"查询系统配置";
        } else if ([orderData isEqualToData:[self dataFromHexString:@"0210"]]) {
            message = @"获取VWAS模式列表";
        }else if ([orderData isEqualToData:[self dataFromHexString:@"0610"]]) {
            message = @"获取光学模式名称";
        }
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = message;
}

- (void)showHomeViewController
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                         bundle:nil];
    HomeViewController *homeViewController = [storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    [self.navigationController setViewControllers:@[homeViewController]];
}

#pragma mark - 数据解析
- (void)parseObtainSystemConfigurationRespondData:(NSData *)data
{
    NSData *messageData = [data subdataWithRange:NSMakeRange(10, data.length - 10)];
    if ([[messageData subdataWithRange:NSMakeRange(0, 2)] isEqualToData:[self dataFromHexString:@"0000"]]) {
        NSData *systemCountData = [messageData subdataWithRange:NSMakeRange(2, 4)];
        NSData *systemListData = [messageData subdataWithRange:NSMakeRange(6, messageData.length - 6)];
        NSUInteger systemCount = [self valueOfBigUint32_t:(uint8_t *)systemCountData.bytes];
        NSUInteger index = 0;
        NSMutableArray *tempArray = [NSMutableArray array];
        for (int i = 0; i < systemCount; i++) {
            NSData *systemInformationData = [systemListData subdataWithRange:NSMakeRange(index, 12)];
            [tempArray addObject:systemInformationData];
            NSData *systemCodeData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
            NSLog(@"systemCode = %d", [self valueOfBigUint32_t:(uint8_t *)systemCodeData.bytes]);
            index += 4;
            NSData *lineData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
            NSLog(@"line = %d", [self valueOfBigUint32_t:(uint8_t *)lineData.bytes]);
            index += 4;
            NSData *rowData = [systemListData subdataWithRange:NSMakeRange(index, 4)];
            NSLog(@"row = %d", [self valueOfBigUint32_t:(uint8_t *)rowData.bytes]);
            index += 4;
        }
        [RuntimeData sharedInstance].systemDataList = [tempArray copy];
        [RuntimeData sharedInstance].selectedSystemData = [tempArray firstObject];

        //获取VWAS模式列表
        [self.session.socket sendObtainVWASModelListMessage];
    } else {
        [self.view makeToast:@"获取系统配置信息失败！"];
    }
}

- (void)parseObtainVWASModelListData:(NSData *)data
{
    if ([[data subdataWithRange:NSMakeRange(10, 2)] isEqualToData:[self dataFromHexString:@"0000"]]) {
        NSData *messageBody = [data subdataWithRange:NSMakeRange(10, data.length - 10)];

        //结果(可选)
        NSData *result = [messageBody subdataWithRange:NSMakeRange(16, messageBody.length - 16 - 4)];

        NSData *listCountData = [result subdataWithRange:NSMakeRange(0, 4)];
        NSUInteger listCount = [self valueOfUint32_t:(uint8_t *)listCountData.bytes];

        NSData *modelListData = [result subdataWithRange:NSMakeRange(4, result.length - 4)];
        NSUInteger count = 0;

        NSMutableArray *tempArray = [NSMutableArray array];
        //VWAS_DEFAULT_CLEARWALL,VWAS_DEFAULT_POWEROFF,VWAS_DEFAULT_POWERON需排除
        for (int i = 0; i < listCount; i++) {
            NSData *modelNameLengthData = [modelListData subdataWithRange:NSMakeRange(count, 4)];
            count += 4;
            NSUInteger modelNameLength = [self valueOfUint32_t:(uint8_t *)modelNameLengthData.bytes];
            NSData *modelNameData = [modelListData subdataWithRange:NSMakeRange(count, modelNameLength)];
            count += modelNameLength;
            NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
            NSString *vwasName = [[NSString alloc] initWithData:modelNameData encoding:enc];
            NSLog(@"vwasName = %@", vwasName);
            if ([vwasName isEqualToString:@"VWAS_DEFAULT_CLEARWALL"]||
                [vwasName isEqualToString:@"VWAS_DEFAULT_POWEROFF"]||
                [vwasName isEqualToString:@"VWAS_DEFAULT_POWERON"]) {
                continue;
            }
            
            Icon *icon = [Icon MR_createEntity];
            icon.index = i;
            icon.canRemove = YES;
            icon.stateImageName = @"function_add";
            icon.serialnumber = i + 34;
            icon.isFrequentlyUsed = NO;
            icon.functionType = @"VWAS模式";
            icon.iconImageName = @"awsa_cnime";
            icon.iconMenuName = modelNameData;
            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
            
            [tempArray addObject:modelNameData];
        }
        
        [RuntimeData sharedInstance].VWASList = [tempArray copy];

        //获取光学模式名称
        for (int i = 0; i < 11; i++) {
            [self.session.socket sendObtainLightModelMessage:i];
        }
    } else {
        [self.view makeToast:@"获取VWAS模式列表失败！"];
    }
}

- (void)parseObtainLightModelListData:(NSData *)data
{
    //数据有可能粘连
    NSUInteger count = data.length / 64;
    for (int i = 0; i < count; i++) {
        NSData *unitData = [data subdataWithRange:NSMakeRange(0 * i, 64)];
        NSData *lightNameData = [unitData subdataWithRange:NSMakeRange(24, unitData.length - 24)];
        Icon *icon = [Icon MR_createEntity];
        icon.index = i;
        icon.canRemove = YES;
        icon.stateImageName = @"function_add";
        icon.serialnumber = i + 23;
        icon.isFrequentlyUsed = NO;
        icon.functionType = @"光学模式";
        icon.iconImageName = @"light_style_default";
        icon.iconMenuName = lightNameData;
        [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
        [self.lightModelList addObject:lightNameData];
    }
    if (self.lightModelList.count == 10) {
        [RuntimeData sharedInstance].lightDataList = [self.lightModelList copy];
        [self showHomeViewController];
    }
}

@end
