//
//  NavigationController.h
//  ScreenControl
//
//  Created by wangjian on 14/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationController : UINavigationController

@end
