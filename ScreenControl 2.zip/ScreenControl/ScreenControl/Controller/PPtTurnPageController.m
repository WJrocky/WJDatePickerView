//
//  PPtTurnPageController.m
//  ScreenControl
//
//  Created by wangjian on 19/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "VtronSession.h"
#import "VtronSocket+Protocol.h"
#import "PPtTurnPageController.h"

@interface PPtTurnPageController ()<VtronSocketDelegate>

@property (nonatomic, strong) VtronSession *session;
@property (nonatomic, strong) VtronSocket *socket;

@end

@implementation PPtTurnPageController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIImage *myImage = [UIImage imageNamed:@"navigationbar_back"];
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myButton setImage:myImage forState:UIControlStateNormal];
    myButton.frame = CGRectMake(0.0, 0.0, myImage.size.width, myImage.size.height);

    [myButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:myButton];
    self.navigationItem.leftBarButtonItem = rightButton;
    
//    self.session = [VtronSession sharedInstance];
//    self.session.delegate = self;
    self.socket = [[VtronSocket alloc] init];
    self.socket.delegate = self;
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *host = [userDefaults valueForKey:@"host"];
    [self.socket tcpConnectToHost:host port:12008];
}

- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)turnLastPageAction:(UIButton *)sender {
    [self.socket sendTurnPPTLastPageMessage];
}

- (IBAction)turnNextPageAction:(UIButton *)sender {
    [self.socket sendTurnPPTNextPageMessage];
}

#pragma mark - VtronSessionDelegate
- (void)VtronSocket:(VtronSocket *)socket didChangeStatus:(NSStreamEvent)streamStatus
{
    if (NSStreamEventHasBytesAvailable == streamStatus) {
        NSData *data = [socket readData];
    }
}

@end
