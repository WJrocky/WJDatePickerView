//
//  PopViewController.m
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "HomeItemCell.h"
#import "PopViewController.h"
#import "Icon+CoreDataClass.h"

@interface PopViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *functionCollectionView;
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (nonatomic, copy) cellRemovedBlock cellRemovedBlock;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableDictionary *dataDictionary;
@property (nonatomic, assign) CGPoint center;
@property (nonatomic, assign) CGPoint startPoint;
@property (nonatomic, weak) HomeItemCell *selectedCell;
@property (nonatomic, strong) Icon *selectedModel;

@end

@implementation PopViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
    longPressGesture.delegate = self;
    [self.functionCollectionView addGestureRecognizer:longPressGesture];
}

- (void)loadData:(NSMutableDictionary *)dataDictionary
{
    self.dataDictionary = dataDictionary;
    NSArray *keys = [dataDictionary allKeys];
    self.dataArray = [dataDictionary valueForKey:[keys firstObject]];
    self.nameTextField.text = [keys firstObject];
    [self.functionCollectionView reloadData];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HomeItemCell" forIndexPath:indexPath];

    [cell loadData:[self.dataArray objectAtIndex:indexPath.row]];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{

}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{

}

- (void)longPressAction:(UILongPressGestureRecognizer *)gesture
{
    CGPoint point = [gesture locationInView:self.functionCollectionView];

    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
        {
            NSIndexPath *indexPath = [self.functionCollectionView indexPathForItemAtPoint:point];
            if (!indexPath) {
                break;
            }
            HomeItemCell *cell = (HomeItemCell *)[self.functionCollectionView cellForItemAtIndexPath:indexPath];
            self.center = cell.center;
            self.startPoint = point;
            point = cell.center;
            [self.functionCollectionView beginInteractiveMovementForItemAtIndexPath:indexPath];
            self.selectedCell = cell;
            self.selectedModel = [self.dataArray objectAtIndex:indexPath.row];
        }
            break;

        case UIGestureRecognizerStateChanged:
        {
            point = CGPointMake(self.center.x + point.x - self.startPoint.x, self.center.y + point.y - self.startPoint.y);
            //先把坐标换算到同一坐标系中，nil默认为window，下面集中方法等效
            //[self.blurContainerView.superview convertRect:self.blurContainerView.frame toView:nil];
            //[Window convertRect:self.blurContainerView.frame fromView:self.blurContainerView.superview];
            //[Window convertRect:self.blurContainerView.bounds fromView:self.blurContainerView];
            CGRect containerViewRect = [self.functionCollectionView convertRect:self.functionCollectionView.bounds toView:nil];
            CGRect selectedCellRect = [self.selectedCell convertRect:self.selectedCell.bounds toView:nil];
            if (CGRectIntersectsRect(containerViewRect, selectedCellRect)) {
                [self.functionCollectionView updateInteractiveMovementTargetPosition:point];
            } else {
                if ([self.dataArray containsObject:self.selectedModel]) {
                    NSLog(@"已经移除视图！");
                    [self.dataArray removeObject:self.selectedModel];
                    [self dismissSelf];
                }
            }
        }
            break;
        case UIGestureRecognizerStateEnded:
            [self.functionCollectionView endInteractiveMovement];
            break;
        default:
            [self.functionCollectionView cancelInteractiveMovement];
            break;
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([gestureRecognizer isKindOfClass:[UITapGestureRecognizer class]]) {
        if ([touch.view isKindOfClass:[UICollectionView class]] || (touch.view.frame.size.width == 70)) {
            return NO;
        }
    }
    return YES;
}

- (IBAction)backgroundViewTapGesture:(UITapGestureRecognizer *)sender {
    if (self.nameTextField.text.length != 0) {
        NSArray *keys = [self.dataDictionary allKeys];
        NSArray *models = [self.dataDictionary valueForKey:[keys firstObject]];
        [self.dataDictionary removeAllObjects];
        [self.dataDictionary setValue:models forKey:self.nameTextField.text];
    }
    [self dismissSelf];
}

- (IBAction)clearNameTextFieldAction:(UIButton *)sender {
    self.nameTextField.text = @"";
}

- (void)dismissSelf
{
    [UIView animateWithDuration:0.3 animations:^{
        self.view.alpha = 0.0;
    } completion:^(BOOL finished) {
        if (self.cellRemovedBlock) {
            self.cellRemovedBlock(self.selectedModel, self.dataDictionary);
        }
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}

@end
