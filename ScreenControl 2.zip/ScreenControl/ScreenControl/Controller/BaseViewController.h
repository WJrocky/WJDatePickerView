//
//  BaseViewController.h
//  ScreenControl
//
//  Created by wangjian on 28/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

//大端字节
- (int)valueOfBigUint32_t:(uint8_t *)value;

//小端字节
- (int)valueOfUint32_t:(uint8_t *)value;

//将字符串转化为data
- (NSData *)dataFromHexString:(NSString *)str;

- (NSString *)convertDataToHexStr:(NSData *)data;

@end
