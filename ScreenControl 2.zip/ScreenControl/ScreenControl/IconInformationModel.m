//
//  IconInformationModel.m
//  ScreenControl
//
//  Created by wangjian on 12/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "IconInformationModel.h"

@implementation IconInformationModel

- (instancetype)init
{
    if (self = [super init]) {
        self.subIconModels = [NSMutableArray array];
    }
    return self;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{

}

@end
