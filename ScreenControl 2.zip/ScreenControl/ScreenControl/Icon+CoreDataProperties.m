//
//  Icon+CoreDataProperties.m
//  ScreenControl
//
//  Created by 王健 on 2017/9/23.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "Icon+CoreDataProperties.h"

@implementation Icon (CoreDataProperties)

+ (NSFetchRequest<Icon *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Icon"];
}

@dynamic segueIdentifier;
@dynamic iconImageName;
@dynamic iconMenuName;
@dynamic functionType;
@dynamic isFrequentlyUsed;

@end
