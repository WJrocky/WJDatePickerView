//
//  Icon+CoreDataClass.h
//  ScreenControl
//
//  Created by 王健 on 2017/9/23.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Icon : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Icon+CoreDataProperties.h"
