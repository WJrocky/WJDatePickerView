//
//  PresentationView.h
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^confirmBlock)();
typedef void(^cancelBlock)();
typedef void (^finishedBlock)();
@interface PresentationView : UIView

+ (void)popAlertViewFinishedBlock:(finishedBlock)finish
                 WithConfirmBlock:(confirmBlock)confirm
                      cancelBlock:(cancelBlock)cancel;

@end
