//
//  PresentationView.m
//  ScreenControl
//
//  Created by wangjian on 08/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import "PresentationView.h"

@interface PresentationView ()<UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UIView *containerView;
@property (nonatomic, copy) confirmBlock confirmBlock;
@property (nonatomic, copy) cancelBlock cancelBlock;

@end

@implementation PresentationView

+ (void)popAlertViewFinishedBlock:(finishedBlock)finish
                 WithConfirmBlock:(confirmBlock)confirm
                      cancelBlock:(cancelBlock)cancel
{
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    if ([[[keyWindow subviews] lastObject] isKindOfClass:[self class]]) {
        return;
    }

    PresentationView *presentationView = [[[NSBundle mainBundle] loadNibNamed:@"PresentationView"
                                                                        owner:nil
                                                                      options:nil] firstObject];

    presentationView.confirmBlock = confirm;
    presentationView.cancelBlock = cancel;

    presentationView.frame = [UIScreen mainScreen].bounds;

    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:presentationView action:@selector(dismissSelf)];
    tapGesture.delegate = presentationView;
    [presentationView addGestureRecognizer:tapGesture];

    [keyWindow addSubview:presentationView];
    if (finish) {
        finish();
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isEqual:self.containerView]) {
        return NO;
    }
    return YES;
}

- (void)dismissSelf
{
    [self removeFromSuperview];
}

- (IBAction)cancelButtonAction:(UIButton *)sender {
    if (self.cancelBlock) {
        self.cancelBlock();
    }
    [self removeFromSuperview];
}

- (IBAction)confirmButtonAction:(UIButton *)sender {
    if (self.confirmBlock) {
        self.confirmBlock();
    }
    [self removeFromSuperview];
}

@end
