//
//  SmallItemCell.h
//  ScreenControl
//
//  Created by wangjian on 20/09/2017.
//  Copyright © 2017 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IconInformationModel;
@interface SmallItemCell : UICollectionViewCell

- (void)loadData:(IconInformationModel *)data;

@end
