//
//  Icon+CoreDataClass.m
//  ScreenControl
//
//  Created by 王健 on 2017/9/23.
//  Copyright © 2017年 wangjian. All rights reserved.
//

#import "Icon+CoreDataClass.h"

@implementation Icon

@end
